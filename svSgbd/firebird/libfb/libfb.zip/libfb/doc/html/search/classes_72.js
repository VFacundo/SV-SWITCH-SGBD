var searchData=
[
  ['rquery',['rquery',['../structrquery.html',1,'']]]
];
