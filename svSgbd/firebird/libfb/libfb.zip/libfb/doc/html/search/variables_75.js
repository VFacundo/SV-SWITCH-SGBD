var searchData=
[
  ['user',['user',['../structfb__db__info.html#a1d3e3355bf9df38419896f8e115255f4',1,'fb_db_info']]]
];
