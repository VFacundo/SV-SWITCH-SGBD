var searchData=
[
  ['fb_5ferror',['fb_error',['../structfb__query__info.html#abee466361ace1015180d2c2a47215294',1,'fb_query_info::fb_error()'],['../structquery.html#a810db6b7660da4a4a938dfd56f4da904',1,'query::fb_error()']]],
  ['fb_5fnum_5fbuffers',['fb_num_buffers',['../structfb__db__info.html#a29fb9b3afdd6ae5ee01e6604ef7b760b',1,'fb_db_info']]],
  ['fb_5fpage_5fsize',['fb_page_size',['../structfb__db__info.html#a2cdd8c0203b109fef4cf78e12937263a',1,'fb_db_info']]],
  ['fb_5fread_5fonly',['fb_read_only',['../structfb__db__info.html#ae959dce387e2048ea073a06d7f335e6f',1,'fb_db_info']]],
  ['fb_5fshow_5fmessages',['FB_SHOW_MESSAGES',['../libfb_8c.html#a36890c020da5d4e6671354dc4a6cb257',1,'libfb.c']]],
  ['fb_5fsql_5fdialect',['fb_sql_dialect',['../structfb__db__info.html#a2da1f9c545d16acd6ddeec45b79bc853',1,'fb_db_info']]],
  ['fb_5fstream_5fmessages',['FB_STREAM_MESSAGES',['../libfb_8c.html#a4c457c7658bd96582e2648fdf7590f65',1,'libfb.c']]],
  ['fb_5fversion',['fb_version',['../structfb__db__info.html#a4724b87c32158c39bcab3f141c8844af',1,'fb_db_info']]],
  ['fetchcode',['FETCHCODE',['../structfb__query__info.html#ae3b93038a6989b4728499e0cdf5ee74a',1,'fb_query_info::FETCHCODE()'],['../structquery.html#a6f733ee9c197a560a8af9f96dc6f5b82',1,'query::FETCHCODE()']]]
];
