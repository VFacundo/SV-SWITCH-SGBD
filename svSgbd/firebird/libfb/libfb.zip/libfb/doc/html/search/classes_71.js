var searchData=
[
  ['query',['query',['../structquery.html',1,'']]]
];
