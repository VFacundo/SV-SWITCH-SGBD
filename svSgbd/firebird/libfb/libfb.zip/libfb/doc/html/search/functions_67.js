var searchData=
[
  ['get_5fdata',['get_data',['../libfb_8c.html#ab32f6b74987b46951e5c7313cb69b1b8',1,'get_data(XSQLDA *out_sqlda, int pos):&#160;libfb.c'],['../libfb_8h.html#ab32f6b74987b46951e5c7313cb69b1b8',1,'get_data(XSQLDA *out_sqlda, int pos):&#160;libfb.c']]]
];
