var searchData=
[
  ['role',['role',['../structfb__db__info.html#acd5bfb87e693c04b14cd946ef810988c',1,'fb_db_info']]],
  ['rows',['rows',['../structquery.html#a8a80154687ba587cb9eb4683af2291ef',1,'query']]],
  ['rows_5fdeleted',['rows_deleted',['../structfb__query__info.html#ab45278f4edd508db9866cae48f23af4b',1,'fb_query_info::rows_deleted()'],['../structquery.html#a292e99242a638841762573afd96e0eed',1,'query::rows_deleted()']]],
  ['rows_5ffetched',['rows_fetched',['../structfb__query__info.html#ad3fdd0bd1cba67565f0c5ce3ad2a3d8f',1,'fb_query_info::rows_fetched()'],['../structquery.html#a6b970da93dd0f47375ac936ca011bb4d',1,'query::rows_fetched()']]],
  ['rows_5finserted',['rows_inserted',['../structfb__query__info.html#a7f8f37018e90f873167719b02bc9ac2d',1,'fb_query_info::rows_inserted()'],['../structquery.html#aade198f3d628c8a4945e88a563a39d8c',1,'query::rows_inserted()']]],
  ['rows_5fselected',['rows_selected',['../structfb__query__info.html#aa60bde8f9fd3276320d4a612856cc4a4',1,'fb_query_info::rows_selected()'],['../structquery.html#a07d9dc7e0a69338de4fd68ce3bc88522',1,'query::rows_selected()']]],
  ['rows_5fupdated',['rows_updated',['../structfb__query__info.html#a96ac3cbef01e5ccd18d3676c06119c9c',1,'fb_query_info::rows_updated()'],['../structquery.html#a42318e13109b142e72cb9dc3eab488a8',1,'query::rows_updated()']]],
  ['rquery',['rquery',['../structrquery.html',1,'']]]
];
