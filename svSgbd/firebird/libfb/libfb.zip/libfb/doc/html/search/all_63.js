var searchData=
[
  ['col',['col',['../structrquery.html#a85882b4193b55e891af5a2fdb1639663',1,'rquery']]],
  ['colname',['colname',['../structquery.html#a3582c31903602f56b9f158839560d20e',1,'query']]],
  ['cols',['cols',['../structquery.html#acfe07b277d4bbf955b79a4ad6c5865ad',1,'query']]],
  ['cursor',['cursor',['../structfb__query__info.html#a91ec7e0c25b3c06aa30f50022bca5bed',1,'fb_query_info']]]
];
