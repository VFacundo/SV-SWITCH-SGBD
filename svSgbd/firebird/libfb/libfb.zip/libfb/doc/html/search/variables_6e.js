var searchData=
[
  ['next',['next',['../structrquery.html#aff68308448c89e7b0150df346ad6addb',1,'rquery']]],
  ['num_5fsegments',['num_segments',['../structfb__blob__info.html#a8f128a24657c1dc3b5a8722fbb919a3d',1,'fb_blob_info']]]
];
