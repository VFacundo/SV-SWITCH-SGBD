var searchData=
[
  ['errmsg',['errmsg',['../structfb__query__info.html#af205a473947878bfc3a53940db03225b',1,'fb_query_info::errmsg()'],['../structquery.html#a1f3fcbb4eb25f8e12e9ae280c5447ba5',1,'query::errmsg()']]],
  ['event_5fflag',['event_flag',['../libfb_8c.html#a7cf390eccb5be6d98eaf4fe03e64e2af',1,'libfb.c']]]
];
