var searchData=
[
  ['ondogenericquery',['onDoGenericQuery',['../libfb_8c.html#a766173e9632c21ece4610f6f0c32d229',1,'onDoGenericQuery(int eventType, fb_query_info *qi, void *buffer):&#160;libfb.c'],['../libfb_8h.html#afc25e0f941381b65c7557043d67c0b9c',1,'onDoGenericQuery(int eventType, fb_query_info *dbinfo, void *buffer):&#160;libfb.c']]]
];
