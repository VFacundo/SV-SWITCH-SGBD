var searchData=
[
  ['vary_5flength',['vary_length',['../structVARY.html#a277ed5175b50b0b6f3a5bdb1445f861d',1,'VARY']]],
  ['vary_5fstring',['vary_string',['../structVARY.html#a63f1ad81d27f5c1cff3ed4e6f1e66db0',1,'VARY']]]
];
