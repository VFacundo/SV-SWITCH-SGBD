/**
* @file libfb.c  
* Implementacion libreria libfb wrapper de la api C de Firebird SQL Database
* Permite conexion y ejecucucion de queries sobre base de datos Firebird
* a traves del lenguaje ANSI C
*
*

FB Events:
 -Control de eventos en forma sincronica no puede ser usado en Ms Windows
 -Pueden hacerse multiples llamadas (con diferentes EPB's) a isc_event_block() para alocar EPB's que luego seran
  usados para que la aplicacion registre interes en estos FB eventos

 * 
 *
 * Copyright 2012 grchere 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * @author Guillermo Cherencio
 * 
 * @example cgi4.c
 * @example cgi5.c
 * @example cgi6.c
 * @example cgi7.c
 * @example cgi7.dhtml
 * @example cgi8.c
 * @example cgi8.dhtml
 * 
 * @example fbquery1.c
 * @example fbquery2.c
 * @example fbquery3.c
 * 
*/
#include <stdio.h>
#include <stdlib.h>
#define __USE_GNU   // para que incorpore funciones tales como strcasestr() y demas
#include <string.h>
#include <search.h>
#include <time.h>
#include <dlfcn.h>
//#define WIN32
#include <libfb.h>

// variables globales a esta libreria
static int event_flag=0;
//static int event_count=0;

/**********************************************************************
show message trace? 1 show messages   0 no messages
***********************************************************************/
int FB_SHOW_MESSAGES =          1;
/**********************************************************************
FILE *   stream to send libfb messages
***********************************************************************/
FILE *FB_STREAM_MESSAGES =   NULL;


/** bloqueo el proceso actual, permitiendo la ejecucion de otros procesos
 * sin consumir tiempo de cpu
 * 
 * @param nanosec cantidad de nanosegundo a bloquear proceso
 * @author Guillermo Cherencio
 */
void fb_sleep(int nanosec);


//================================================================================================================

/** 
 * Funcion para indicar el interes de la aplicacion en la espera de un determinado 
 * evento a ocurrir en la base de datos, indica la funcion de callback local usada
 * para controlar la ocurrencia de los eventos de la base de datos
 * 
 * @param dbinfo info conexion base de datos
 * @param events arreglo con los nombres de los eventos en los cuales tiene interes y que se 
 * supone van a ser posteados desde la base de datos
 * @param flag que se inicializa en uno y controla el loop interno de la funcion
 * @param onDoEvent puntero a funcion de callback a ser llamada cuando ocurra alguno
 * de los eventos de interes declarado en events
 * 
 * @author Guillermo Cherencio
 */
void fb_wait_events(fb_db_info *dbinfo,char *events[],int *flag,int (*onDoEvent)(fb_db_info *dbinfo,char *eventName,int count)) {
   int i = 0;
   while (events[i]!=NULL) { 
	   if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"events[%d] = [%s]\n",i,events[i]);
	   i++;
   }
   if ( i == 0 ) return;

   unsigned char *event_buffer[i], *result_buffer[i];
   short length[i];
   ISC_LONG event_id[i];
   ISC_STATUS status_vector[i][32];
   int event_posted[i];
   int rf = FB_CONTINUE;

if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"wait 1\n");
   int w;
   for(w=0;w<i;w++) {
      event_posted[i]=0;
      length[w] = (short) isc_event_block(&event_buffer[w],&result_buffer[w],1,events[w],0);
if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"wait 1.0 length=%d\n",length[w]);
//      memcpy(&status_vector[w][0],&dbinfo->status_vector[0],sizeof(dbinfo->status_vector));
      isc_que_events(&status_vector[w][0],&dbinfo->db1,&event_id[w],length[w],event_buffer[w],(ISC_EVENT_CALLBACK) fb_event_function,result_buffer[w]);
if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"wait 1.1\n");
      if (status_vector[w][0] == 1 && status_vector[w][1]) {
         if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_wait_events():Error, queue event [%s]\n",events[w]);
      }
if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"wait 2.0\n");
   }

if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"wait 2\n");
   *flag=1;
   while (rf == FB_CONTINUE && *flag) {
      if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_wait_events():continue waiting=%d\n",*flag);
      if (!event_flag) {
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_wait_events(): hago algo!\n");
         fb_sleep(5000);
      } else { 
         event_flag=0;
         for(w=0;w<i;w++) {
            isc_event_counts((ISC_ULONG *) &status_vector[w][0],length[w],event_buffer[w],result_buffer[w]);
            if (status_vector[w][0] == 1 && status_vector[w][1]) {
               if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_wait_events():Error, counts event [%s]\n",events[w]);
            }
         }
         for(w=0;rf == FB_CONTINUE && w<i;w++) {
            if (status_vector[w][0]) {
            /* The event has been posted. Do whatever is appropriate,
               such as initiating a buy or sell order.
               Note: event_names[i] tells the name of the event
               corresponding to status_vector[i]. */
               event_posted[w]+=1;
               rf = (*onDoEvent)(dbinfo,events[w],event_posted[w]);
            }
         }
         for(w=0;rf == FB_CONTINUE && w<i;w++) {
            isc_que_events(&status_vector[w][0],&dbinfo->db1,&event_id[w],length[w],event_buffer[w],(ISC_EVENT_CALLBACK) fb_event_function,result_buffer[w]);
            if (status_vector[w][0] == 1 && status_vector[w][1]) {
               if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_wait_events():Error, queue event [%s](2)\n",events[w]);
            }
         }
      } // fin else de if(!event_flag) ...
   } /* End of while. */

   if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_wait_events():Cancelling event listening\n");
   /* Let InterBase know you no longer want to wait asynchronously. */

   for(w=0;w<i;w++) {
      isc_cancel_events(&status_vector[w][0],&dbinfo->db1,&event_id[w]);
      if (status_vector[w][0] == 1 && status_vector[w][1]) {
         if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_wait_events():Error, cancelling event [%s]\n",events[w]);
      }
   }

}

/** 
 * Funcion de callback generica para el manejo de eventos
 * 
 * @param result 
 * @param length
 * @param updated
 * 
 * @author Guillermo Cherencio
 */
isc_callback fb_event_function(char *result, short length, char *updated) {
   /* Set the global event flag. */
   //event_count++;
   event_flag++;
   /* Copy the temporary updated buffer to the result buffer. */
if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"inicio fb_event_function() length=%d\n",length);
   while (length--) *result++ = *updated++;
if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fin fb_event_function()!\n");
   return 0;
}


/** 
 * Recupera el valor de un parametro de salida de tipo string.
 * @warning El valor devuelto fue asignado dinamicamente y debe liberarse su memoria, en caso 
 * de error devuelve NULL
 * 
 * @param qi query sobre el cual se va a obtener un parametro de salida
 * @param param numero de parametro a obtener
 * @return valor del parametro de salida obtenido
 * 
 * @author Guillermo Cherencio
 */
char *fb_get_strpar(fb_query_info *qi,int param) {
   if ( qi == NULL || param < 0 ) return NULL;
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_get_strpar():Hay declarados %d de %d parametros\n",qi->out_sqlda->sqld,qi->out_sqlda->sqln);
   if ( param < qi->out_sqlda->sqld ) {
      char *str = (char *) malloc(qi->out_sqlda->sqlvar[param].sqllen+2);
      if ( str != NULL ) {
		 // printf("fb_get_strpar(): copio param de salida %d\n",param);
		 // printf("fb_get_strpar(): sqldata=[%s]\n",qi->out_sqlda->sqlvar[param].sqldata);
         strcpy(str,qi->out_sqlda->sqlvar[param].sqldata);
         return str;
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_strpar():Error, en asignacion de memoria\n");
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_strpar():Error, parametro %d no existe, solo hay %d parametros\n",param,qi->out_sqlda->sqld);
   return NULL;
}

/** 
 * Recupera el valor de un parametro de salida de tipo entero.
 * 
 * @warning En caso de error devuelve -1
 * 
 * @param qi query sobre el cual se va a obtener un parametro de salida
 * @param param numero de parametro a obtener
 * @return valor del parametro de salida obtenido o -9999 si hay error
 * 
 * @author Guillermo Cherencio
 */
int  fb_get_intpar(fb_query_info *qi,int param) {
   if ( qi == NULL || param < 0 ) return -9999;
//if ( FB_SHOW_MESSAGES ) (FB_STREAM_MESSAGES,"fb_get_intpar():Hay declarados %d de %d parametros\n",qi->out_sqlda->sqld,qi->out_sqlda->sqln);
   if ( param < qi->out_sqlda->sqld ) {
      int pint=0;
	  memcpy(&pint,qi->out_sqlda->sqlvar[param].sqldata,sizeof(int));
	  return pint;
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_get_intpar():Error, parametro %d no existe, solo hay %d parametros\n",param,qi->out_sqlda->sqld);
   return -9999;
}
/** 
 * Recupera el valor de un parametro de salida de tipo entero largo.
 * 
 * @warning En caso de error devuelve -1L
 * 
 * @param qi query sobre el cual se va a obtener un parametro de salida
 * @param param numero de parametro a obtener
 * @return valor del parametro de salida obtenido o -9999 si hay error
 * 
 * @author Guillermo Cherencio
 */
long fb_get_longpar(fb_query_info *qi,int param) {
   if ( qi == NULL || param < 0 ) return -9999L;
//if ( FB_SHOW_MESSAGES ) (FB_STREAM_MESSAGES,"fb_get_longpar():Hay declarados %d de %d parametros\n",qi->out_sqlda->sqld,qi->out_sqlda->sqln);
   if ( param < qi->out_sqlda->sqld ) {
      long pint=0L;
	  memcpy(&pint,qi->out_sqlda->sqlvar[param].sqldata,sizeof(long));
	  return pint;
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_get_intpar():Error, parametro %d no existe, solo hay %d parametros\n",param,qi->out_sqlda->sqld);
   return -9999L;
}

/** 
 * Asigna memoria para parametro numero param y setea parametro de entrada de tipo string (strpar)
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param strpar valor del parametro a asignar
 * 
 * @author Guillermo Cherencio
 */
void fb_set_strpar(fb_query_info *qi,int param,char *strpar) {
   if ( qi == NULL || strpar == NULL || param < 0 ) return;
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_set_strpar():Hay declarados %d de %d parametros\n",qi->in_sqlda->sqld,qi->in_sqlda->sqln);
   if ( param < qi->in_sqlda->sqld ) {
      char *str = (char *) malloc(strlen(strpar)+2);
      if ( str != NULL ) {
         strcpy(str,strpar);
         if ( qi->in_sqlda->sqlvar[param].sqldata != NULL ) free(qi->in_sqlda->sqlvar[param].sqldata);
         qi->in_sqlda->sqlvar[param].sqldata = str;
         qi->in_sqlda->sqlvar[param].sqltype = SQL_TEXT;
         qi->in_sqlda->sqlvar[param].sqllen  = strlen(strpar)+2;
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_strpar():Error, en asignacion de memoria\n");
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_strpar():Error, parametro %d no existe, solo hay %d parametros\n",param,qi->in_sqlda->sqld);
}

/** 
 * Idem fb_set_strpar(), para valores enteros
 * Asigna memoria para parametro numero param y setea parametro de entrada de tipo int (intpar)
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param intpar valor entero del parametro a asignar
 * 
 * @author Guillermo Cherencio
 */
void fb_set_intpar(fb_query_info *qi,int param,int intpar) {
   if ( qi == NULL || param < 0 ) return;
//if ( FB_SHOW_MESSAGES ) (FB_STREAM_MESSAGES,"fb_set_strpar():Hay declarados %d de %d parametros\n",qi->in_sqlda->sqld,qi->in_sqlda->sqln);
   if ( param < qi->in_sqlda->sqld ) {
         if ( qi->in_sqlda->sqlvar[param].sqldata != NULL ) free(qi->in_sqlda->sqlvar[param].sqldata);
		 qi->in_sqlda->sqlvar[param].sqldata = (char *) malloc(sizeof(int));
		 if (qi->in_sqlda->sqlvar[param].sqldata != NULL ) {
			 memset(qi->in_sqlda->sqlvar[param].sqldata,0,sizeof(int));
			 memcpy(qi->in_sqlda->sqlvar[param].sqldata,&intpar,sizeof(int));
			 //*(int *) (qi->in_sqlda->sqlvar[param].sqldata) = intpar;
			 qi->in_sqlda->sqlvar[param].sqltype = SQL_SHORT;
			 qi->in_sqlda->sqlvar[param].sqllen  = sizeof(int);
		 } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_intpar():Error, asignando memoria para parametro %d\n",param);
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_intpar():Error, parametro %d no existe, solo hay %d parametros\n",param,qi->in_sqlda->sqld);
}

/** 
 * Idem fb_set_strpar(), para valores long
 * Asigna memoria para parametro numero param y setea parametro de entrada de tipo long (longpar)
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param longpar valor long del parametro a asignar
 * 
 * @author Guillermo Cherencio
 */
void fb_set_longpar(fb_query_info *qi,int param,long longpar) {
   if ( qi == NULL || param < 0 ) return;
//if ( FB_SHOW_MESSAGES ) printf(FB_STREAM_MESSAGES,"fb_set_longpar():Hay declarados %d de %d parametros\n",qi->in_sqlda->sqld,qi->in_sqlda->sqln);
   if ( param < qi->in_sqlda->sqld ) {
      long *plong = (long *) malloc(sizeof(long));
      if ( plong != NULL ) {
         *plong = longpar;
         if ( qi->in_sqlda->sqlvar[param].sqldata != NULL ) free(qi->in_sqlda->sqlvar[param].sqldata);
         qi->in_sqlda->sqlvar[param].sqldata = (char *) plong;
         qi->in_sqlda->sqlvar[param].sqltype = SQL_LONG;
         qi->in_sqlda->sqlvar[param].sqllen  = sizeof(long);
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_longpar():Error, en asignacion de memoria\n");
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_longpar():Error, parametro %d no existe, solo hay %d parametros\n",param,qi->in_sqlda->sqld);
}

/** 
 * Importa el archivo input_file en parametro param de tipo blob con un segmento de segment_size
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param input_file archivo de donde importar blob
 * @param segment_size tamano, largo del archivo input_file
 * 
 * @author Guillermo Cherencio
 */
void fb_import_fblbpar(fb_query_info *qi,int  param,char *input_file,int segment_size) {
   if ( qi == NULL || param < 0 ) return;
   isc_blob_handle blob_handle;
   memset(&blob_handle,0,sizeof(isc_blob_handle));
   char blob_segment[segment_size]; // no debe superar el indicado para este atributo en la tabla
   ISC_QUAD blob_id;
   memset(&blob_id,0,sizeof(ISC_QUAD));
   isc_create_blob2(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,&blob_handle,&blob_id,0,NULL);
   if (!fb_error(qi->dbinfo,qi)) {
      FILE *fp = fopen(input_file,"rb");
      if ( fp != NULL ) {
         size_t nread;
         int fberr=0;
         while( !fberr && (nread=fread(blob_segment,1,segment_size,fp)) ) {
            isc_put_segment(&qi->dbinfo->status_vector[0],&blob_handle,nread,blob_segment);
            fberr = fb_error(qi->dbinfo,qi);
         }
         fclose(fp);
         if ( fberr ) if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_fblbpar():Error, importando archivo [%s]\n%s",input_file,qi->errmsg);
         isc_close_blob(&qi->dbinfo->status_vector[0],&blob_handle);
         memcpy(qi->in_sqlda->sqlvar[param].sqldata,&blob_id,sizeof(ISC_QUAD));
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_fblbpar():Error, en apertura de archivo [%s]\n",input_file);
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_set_fblbpar():Error, creado blob para importar archivo [%s]\n%s",input_file,qi->errmsg);
}

/**
 * Idem fb_import_fblbpar(), pero importa blob a partir de buffer
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param buffer buffer de memoria de donde importar blob
 * @param buffer_size tamano, largo del buffer en memoria
 * @param segment_size tamano segmento del blob
 * 
 * @author Guillermo Cherencio
 */
void fb_import_bblbpar(fb_query_info *qi,int  param,void *buffer,long buffer_size,int segment_size) {
   if ( qi == NULL || param < 0 ) return;
   isc_blob_handle blob_handle;
   memset(&blob_handle,0,sizeof(isc_blob_handle));
   ISC_QUAD blob_id;
   memset(&blob_id,0,sizeof(ISC_QUAD));
   isc_create_blob2(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,&blob_handle,&blob_id,0,NULL);
   if (!fb_error(qi->dbinfo,qi)) {
      int n = buffer_size / segment_size,i;
      int resto = buffer_size % segment_size;
      int fberr=0;
      char *strbuffer = (char *) buffer;
      for(i=0;!fberr && i<n;i++) {
         isc_put_segment(&qi->dbinfo->status_vector[0],&blob_handle,segment_size,strbuffer);
         fberr = fb_error(qi->dbinfo,qi);
         strbuffer+=segment_size;
      }
      if ( !fberr ) {
         isc_put_segment(&qi->dbinfo->status_vector[0],&blob_handle,resto,strbuffer);
         fberr = fb_error(qi->dbinfo,qi);
      }
      if ( fberr ) if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_import_bblbpar():Error, importing blob from buffer\n%s",qi->errmsg);
      isc_close_blob(&qi->dbinfo->status_vector[0],&blob_handle);
      memcpy(qi->in_sqlda->sqlvar[param].sqldata,&blob_id,sizeof(ISC_QUAD));
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_import_bblbpar():Error, creating blob from buffer\n%s",qi->errmsg);
}

/**
 * Importa el contenido del arreglo buffer de tamano size a la base de datos
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param buffer buffer de memoria de donde importar arreglo
 * @param size tamano, largo del buffer en memoria
 * 
 * @author Guillermo Cherencio
 */
void fb_import_arraypar(fb_query_info *qi,int  param,void *buffer,int size) {
   if ( qi == NULL || param < 0 ) return;
   ISC_ARRAY_DESC desc;
   // termino con nulos el nombre de la columna y de la relacion
   qi->in_sqlda->sqlvar[param].sqlname[qi->in_sqlda->sqlvar[param].sqlname_length]='\0';
   qi->in_sqlda->sqlvar[param].relname[qi->in_sqlda->sqlvar[param].relname_length]='\0';
if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_import_arraypar(): recupero vector [%s][%s]\n",qi->in_sqlda->sqlvar[param].relname,qi->in_sqlda->sqlvar[param].sqlname);
   isc_array_lookup_bounds(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,qi->in_sqlda->sqlvar[param].relname,qi->in_sqlda->sqlvar[param].sqlname,&desc);
   if (!fb_error(qi->dbinfo,qi)) {
      ISC_QUAD array_id;
      memset(&array_id,0,sizeof(ISC_QUAD));
      //long len = (long) size;
      ISC_LONG len = (ISC_LONG) size;
      isc_array_put_slice(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,&array_id,&desc,buffer,&len);
      if (!fb_error(qi->dbinfo,qi)) {
         memcpy(qi->in_sqlda->sqlvar[param].sqldata,&array_id,sizeof(ISC_QUAD));
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_import_arraypar():Error, slicing array into buffer\n%s",qi->errmsg);
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_import_arraypar():Error, looking bound of array to import into buffer\n%s",qi->errmsg);
}

/**
 * Lo contrario de  fb_import_fblbpar(). 
 * Exporta el archivo output_file del parametro param de tipo blob 
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param output_file archivo en donde queda exportado el parametro en cuestion
 * 
 * @author Guillermo Cherencio
 */
void fb_export_fblbpar(fb_query_info *qi,int param,char *output_file) {
   if ( qi == NULL || param < 0 ) return;
   fb_fetch(qi);
   if (!fb_error(qi->dbinfo,qi)) {
      fb_blob_info bi;
      fb_info_blbpar(qi,param,&bi);
      int segment_size = bi.max_segment;
      isc_blob_handle blob_handle;
	  memset(&blob_handle,0,sizeof(isc_blob_handle));
      char blob_segment[segment_size]; // no debe superar el indicado para este atributo en la tabla
      ISC_QUAD *blob_id = (ISC_QUAD *) qi->out_sqlda->sqlvar[param].sqldata; // blob id en parametro output
      unsigned short actual_seg_len;
      ISC_STATUS blob_stat;
      isc_open_blob2(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,&blob_handle,blob_id,0,NULL);
      if (!fb_error(qi->dbinfo,qi)) {
         FILE *fp = fopen(output_file,"wb");
         if ( fp != NULL ) {
            blob_stat = isc_get_segment(&qi->dbinfo->status_vector[0],&blob_handle,&actual_seg_len,segment_size,blob_segment);
            int fberr = fb_error(qi->dbinfo,qi);
            while (!fberr && (blob_stat == 0 || qi->dbinfo->status_vector[1] == isc_segment)) {
               fwrite(blob_segment,1,actual_seg_len,fp);
               blob_stat = isc_get_segment(&qi->dbinfo->status_vector[0],&blob_handle,&actual_seg_len,segment_size,blob_segment);
               fberr = fb_error(qi->dbinfo,qi);
            }
            fclose(fp);
            isc_close_blob(&qi->dbinfo->status_vector[0],&blob_handle);
         } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_fblbpar():Error, abriendo archivo [%s]\n",output_file);
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_fblbpar():Error, opening blob para exportar archivo [%s]\n%s",output_file,qi->errmsg);
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_fblbpar():Error, en fetch de blob para exportar archivo [%s]\n%s",output_file,qi->errmsg);
}

/**
 * Lo contrario de  fb_import_bblbpar()
 * Idem anterior, pero exporta blob en un buffer, no hace fetch()
 * buffer debe contar con suficiente espacio
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param buffer area de memoria en donde quedara el parametro blob exportado
 * 
 * @author Guillermo Cherencio
 */
void fb_export_bblbpar(fb_query_info *qi,int  param,void *buffer) {
   if ( qi == NULL || buffer == NULL || param < 0 ) return;
   fb_fetch(qi);
   if (!fb_error(qi->dbinfo,qi)) {
      fb_blob_info bi;
      fb_info_blbpar(qi,param,&bi);
      int segment_size = bi.max_segment;
      isc_blob_handle blob_handle;
      memset(&blob_handle,0,sizeof(isc_blob_handle));
      ISC_QUAD *blob_id = (ISC_QUAD *) qi->out_sqlda->sqlvar[param].sqldata; // blob id en parametro output
      unsigned short actual_seg_len;
      ISC_STATUS blob_stat;
      isc_open_blob2(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,&blob_handle,blob_id,0,NULL);
      if (!fb_error(qi->dbinfo,qi)) {
         char *strbuffer = (char *) buffer;
         int fberr;
         do {
            blob_stat = isc_get_segment(&qi->dbinfo->status_vector[0],&blob_handle,&actual_seg_len,segment_size,strbuffer);
            fberr = fb_error(qi->dbinfo,qi);
            strbuffer+=actual_seg_len;
         } while(!fberr && (blob_stat == 0 || qi->dbinfo->status_vector[1] == isc_segment));
         isc_close_blob(&qi->dbinfo->status_vector[0],&blob_handle);
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_bblbpar():Error, opening blob to export into buffer\n%s",qi->errmsg);
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_bblbpar():Error, fetching blob to export into buffer\n%s",qi->errmsg);
}

/**
 * Idem fb_export_bblbpar(), pero exporta a partir de una posicion (position) (de base 0) del blob, size bytes en buffer
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param buffer area de memoria en donde quedara el parametro blob exportado
 * @param position posicion de base 0 a partir de donde exportar blob
 * @param size cantidad de bytes a exportar
 * 
 * @author Guillermo Cherencio
 */
void fb_export_sblbpar(fb_query_info *qi,int  param,void *buffer,long position,long size) {
   if ( qi == NULL || buffer == NULL || param < 0 ) return;
   fb_fetch(qi);
   if (!fb_error(qi->dbinfo,qi)) {
      fb_blob_info bi;
      fb_info_blbpar(qi,param,&bi);
      if ( position > bi.size || position < 0L) {
         if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_sblbpar():Error, trying to get blob data after the end or out of scope!\n");
         return;
      }
      int segment_size = bi.max_segment;
      char blob_content[bi.size];
      isc_blob_handle blob_handle;
      memset(&blob_handle,0,sizeof(isc_blob_handle));
      ISC_QUAD *blob_id = (ISC_QUAD *) qi->out_sqlda->sqlvar[param].sqldata; // blob id en parametro output
      unsigned short actual_seg_len;
      ISC_STATUS blob_stat;
      isc_open_blob2(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,&blob_handle,blob_id,0,NULL);
      if (!fb_error(qi->dbinfo,qi)) {
         char *p = blob_content;
         int fberr = 0;
         long curr_pos = 0L;
         while ( curr_pos < (position+size) && !fberr ) {
            blob_stat = isc_get_segment(&qi->dbinfo->status_vector[0],&blob_handle,&actual_seg_len,segment_size,p);
            fberr = fb_error(qi->dbinfo,qi);
            if (!(blob_stat == 0 || qi->dbinfo->status_vector[1] == isc_segment)) fberr = 1;
            p+=actual_seg_len;
            curr_pos+=actual_seg_len;
         }
         if ( curr_pos >= (position+size) ) {
            if ( (position+size) <= bi.size ) memcpy(buffer,blob_content+position,size);
            else                              memcpy(buffer,blob_content+position,bi.size-position);
         } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_sblbpar():Error, exporting blob into buffer at position %ld\n%s",position,qi->errmsg);
         isc_close_blob(&qi->dbinfo->status_vector[0],&blob_handle);
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_sblbpar():Error, opening blob to export into buffer\n%s",qi->errmsg);
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_sblbpar():Error, fetching blob to export into buffer\n%s",qi->errmsg);
}

/**
 * Idem fb_export_* para exportar array
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param buffer area de memoria en donde quedara el parametro array exportado
 * @param size cantidad de bytes a exportar
 * 
 * @author Guillermo Cherencio
 */
void fb_export_arraypar(fb_query_info *qi,int  param,void *buffer,int size) {
   if ( qi == NULL || buffer == NULL || param < 0 ) return;
   fb_fetch(qi);
   if (!fb_error(qi->dbinfo,qi)) {
      ISC_ARRAY_DESC desc;
      // termino con nulos el nombre de la columna y de la relacion
      qi->out_sqlda->sqlvar[param].sqlname[qi->out_sqlda->sqlvar[param].sqlname_length]='\0';
      qi->out_sqlda->sqlvar[param].relname[qi->out_sqlda->sqlvar[param].relname_length]='\0';
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_export_arraypar(): recupero vector [%s][%s]\n",qi->out_sqlda->sqlvar[param].relname,qi->out_sqlda->sqlvar[param].sqlname);
      isc_array_lookup_bounds(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,qi->out_sqlda->sqlvar[param].relname,qi->out_sqlda->sqlvar[param].sqlname,&desc);
      if (!fb_error(qi->dbinfo,qi)) {
         ISC_QUAD *array_id = (ISC_QUAD *) qi->out_sqlda->sqlvar[param].sqldata; // array id en parametro output
         //long len = (long) size;
         ISC_LONG len = (ISC_LONG) size;
         isc_array_get_slice(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,array_id,&desc,buffer,&len);
         if (fb_error(qi->dbinfo,qi)) if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_arraypar():Error, slicing array into buffer\n%s",qi->errmsg);
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_arraypar():Error, looking bound of array to export into buffer\n%s",qi->errmsg);
   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_export_arraypar():Error, fetching array to export into buffer\n%s",qi->errmsg);
}

/**
 * En info deja toda la informacion del blob accedido en la fila actual y en la columna indicada
 * no hace fetch()
 * 
 * @param qi query sobre el cual se va a asignar un parametro
 * @param param numero de parametro a asignar
 * @param info asigna datos del blob param
 * 
 * @author Guillermo Cherencio
 */
void fb_info_blbpar(fb_query_info *qi,int param,fb_blob_info *info) {
   if ( qi == NULL || info == NULL || param < 0 ) return;
   char blob_items[] = { isc_info_blob_num_segments, isc_info_blob_max_segment, isc_info_blob_total_length, isc_info_blob_type };
   char res_buffer[60], *p, item;
   short length;
//   fb_fetch(qi);
//   if (!fb_error(qi->dbinfo,qi)) {
      isc_blob_handle blob_handle;
      memset(&blob_handle,0,sizeof(isc_blob_handle));
      ISC_QUAD *blob_id = (ISC_QUAD *) qi->out_sqlda->sqlvar[param].sqldata; // blob id en parametro output
      isc_open_blob2(&qi->dbinfo->status_vector[0],&qi->dbinfo->db1,qi->tr1,&blob_handle,blob_id,0,NULL);
      if (!fb_error(qi->dbinfo,qi)) {
         isc_blob_info(&qi->dbinfo->status_vector[0],&blob_handle,sizeof(blob_items),blob_items,sizeof(res_buffer),res_buffer);
         if (!fb_error(qi->dbinfo,qi)) {
            /* Extract the values returned in the result buffer. */
            memset(info,0,sizeof(fb_blob_info));
            for (p = res_buffer; *p != isc_info_end ;) {
               item = *p++;
               length = (short) isc_vax_integer(p, 2);
               p += 2;
               switch (item) {
                  case isc_info_blob_max_segment:
                     info->max_segment = isc_vax_integer(p, length);
                     break;
                  case isc_info_blob_num_segments:
                     info->num_segments = isc_vax_integer(p, length);
                     break;
                  case isc_info_blob_total_length:
                     info->size = isc_vax_integer(p, length);
                     break;
                  case isc_info_blob_type:
                     info->type = isc_vax_integer(p, length);
                     break;
                  case isc_info_end:
                     break;
                  case isc_info_error:
                  case isc_info_truncated:
                     if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_info_blbpar():Error, parsing blob information, column id %d\n%s",param,qi->errmsg);
                     break;
                  default:
                     break;
               }
               p += length;
            }
         } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_info_blbpar():Error, requesting blob information, column id %d\n%s",param,qi->errmsg);
         isc_close_blob(&qi->dbinfo->status_vector[0],&blob_handle);
      } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_info_blbpar():Error, opening blob column id %d\n%s",param,qi->errmsg);
//   } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_info_blbpar():Error, fetching blob info column id %d\n%s",param,qi->errmsg);
}

/**
 * Permite establecer una conexion con una base de datos Firebird
 * devuelve true si logro hacerlo, sino indica error
 * 
 * 
 * @code
	fb_db_info dbinfo;
	strcpy(dbinfo.user,"sysdba");
	strcpy(dbinfo.passw,"masterkey");
	strcpy(dbinfo.dbname,"localhost:/var/lib/firebird/2.5/data/isft.fdb");
	strcpy(dbinfo.role,"sysdb");
	if (fb_do_connect(&dbinfo)) {  
		// me conecte!
	}  
 * @endcode
 * @param dbinfo contiene todos los datos necesarios para establecer la conexion,
 * esta area tambien es asignada con datos provenientes de Firebird una vez establecida
 * la conexion
 * 
 * @author Guillermo Cherencio
 */
int fb_do_connect(fb_db_info *dbinfo) { 
   int ret=0;
   char dpb_buffer[256], *dpb, *p;
   short dpb_length;
   if ( FB_STREAM_MESSAGES == NULL ) FB_STREAM_MESSAGES = stdout;
   // Construct a database parameter buffer.
   dpb = dpb_buffer;
   *dpb++ = isc_dpb_version1;
   // Add user name and password to DPB. 
   *dpb++ = isc_dpb_user_name;
   *dpb++ = strlen(dbinfo->user);
   for (p = dbinfo->user; *p;) *dpb++ = *p++;
   *dpb++ = isc_dpb_password;
   *dpb++ = strlen(dbinfo->passw);
   for (p = dbinfo->passw; *p;) *dpb++ = *p++;
   *dpb++ = isc_dpb_sql_role_name;
   *dpb++ = strlen(dbinfo->role);
   for (p = dbinfo->role; *p;) *dpb++ = *p++;
   dpb_length = dpb - dpb_buffer;
   dpb = dpb_buffer;
   dbinfo->db1 = 0L;
   fb_query_info qi;
   fb_init_query_info(&qi);
   isc_attach_database(&dbinfo->status_vector[0], 0, dbinfo->dbname, &dbinfo->db1, dpb_length, dpb_buffer);
   if (fb_error(dbinfo,&qi)) {
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_connect():Error, Attaching database [%s]\nSQLCODE=%ld\n%s",dbinfo->dbname,qi.SQLCODE,qi.errmsg);
   } else {
      ret=1;
      // obtengo datos adicionales de la b.d.   
      char db_items[] = { isc_info_page_size, isc_info_num_buffers, isc_info_db_sql_dialect, isc_info_db_read_only, isc_info_end };
      char cmd[4]; // comandos de informacion solicitados a b.d.
      int  val[4]; // valores de dichos comandos
      //char db_info2[] = { isc_info_firebird_version, isc_info_end };
      char db_info2[] = { isc_info_isc_version, isc_info_end };
      char cmd2[1];
      char val2[50];
      char res_buffer[80];
      char res_buffer2[80];
      memset(res_buffer,0,80);
      memset(res_buffer2,0,80);
      isc_database_info(&dbinfo->status_vector[0],&dbinfo->db1,sizeof(db_items),db_items,sizeof(res_buffer),res_buffer);
      if (!fb_error(dbinfo,&qi)) {
         fb_parse_cmd(res_buffer,4,&cmd[0],&val[0]);
         dbinfo->fb_page_size = val[0];
         dbinfo->fb_num_buffers = val[1];
         dbinfo->fb_read_only = val[3];
         dbinfo->fb_sql_dialect = val[2];
      } else {
         dbinfo->fb_page_size = 0;
         dbinfo->fb_num_buffers = 0;
         dbinfo->fb_read_only = 0;
         dbinfo->fb_sql_dialect = 3;
         if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_connect():Error, no se puedo obtener propiedades numericas de b.d.\nSe asume sql dialect 3\nSQLCODE=%ld\n%s",qi.SQLCODE,qi.errmsg);
      }
      isc_database_info(&dbinfo->status_vector[0],&dbinfo->db1,sizeof(db_info2),db_info2,sizeof(res_buffer2),res_buffer2);
      if (!fb_error(dbinfo,&qi)) {
         if ( fb_parse_scmd(res_buffer2,&cmd2[0],&val2[0]) ) {
            strcpy(dbinfo->fb_version,val2+2); // primeros dos caracteres devueltos son de control, luego viene el string con la version
         } else memset(dbinfo->fb_version,0,sizeof(dbinfo->fb_version));
      } else {
         memset(dbinfo->fb_version,0,sizeof(dbinfo->fb_version));
      }
      if ( FB_SHOW_MESSAGES ) fb_print_db_info(dbinfo);
   }
   fb_end_query_info(&qi);
   return ret;
}

/**
 * Permite establecer una conexion con una base de datos Firebird
 * ejecutar un query y cerrar la conexion
 * devuelve true si logro hacerlo, sino indica error en conexion o
 * en ejecucion de query
 * Utiliza fb_pre_connect(), fb_do_connect(), fb_do_single_query()
 * Devuelve un puntero de tipo query o NULL en caso de error
 * Luego de recuperar las tuplas, llamar a funcion fb_free()
 * 
 * @param dbname base de datos firebird a conectar
 * @param user   usuario firebird con el cual me conecto
 * @param passwd contrasenia usuario firebird con el cual me conecto
 * @param role   rol del usuario firebird con el cual me conecto
 * @param sql_stmt consulta sql a ejecutar (sin parametros) o nombre de tabla,select procedure o vista
 * 
 * @author Guillermo Cherencio
 */
query *fb_do_connect_squery(char *dbname,char *user,char *passwd,char *role,char *sql_stmt) {
	fb_db_info dbinfo;
	query *myquery = NULL;
	fb_pre_connect(&dbinfo,dbname,user,passwd,role);
	if (fb_do_connect(&dbinfo)) {  // me conecte!
		myquery=fb_do_single_query(&dbinfo,sql_stmt);
		fb_do_disconnect(&dbinfo);
	}
	return myquery;
}

/**
 * Desconecta una base de datos Firebird previamente conectada.
 * Devuelve true si logro hacerlo, sino indica error
 * 
 * @param dbinfo contiene todos los datos de la conexion actual que se pretende desconectar
 * 
 * @author Guillermo Cherencio
 */
int fb_do_disconnect(fb_db_info *dbinfo) { 
   int ret=0;
   fb_query_info qi;
   fb_init_query_info(&qi);
   isc_detach_database(&dbinfo->status_vector[0], &dbinfo->db1);
   if (fb_error(dbinfo,&qi)) {
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_disconnect():Error, Disconnecting database [%s]\nSQLCODE=%ld\n%s",dbinfo->dbname,qi.SQLCODE,qi.errmsg);
   } else ret=1;
   fb_end_query_info(&qi);
   return ret;
}

/**
 * Ejecuta sql_stmt (que no devuelve filas y no tiene parametros) dentro de una transaccion
 * Devuelve true si logro hacerlo, sino indica error
 * 
 * @param dbinfo contiene todos los datos de la conexion actual
 * @param sql_stmt sentencia SQL a ejecutar (que no devuelve filas y no tiene parametros)
 * 
 * @author Guillermo Cherencio
 */
int fb_do_cmd(fb_db_info *dbinfo,char *sql_stmt) {
   int ret = 0;
   int method=fb_dsql_method(sql_stmt);
   if ( method != 1 ) { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error, Utilice fb_do_query() en vez de esta funcion\n");return ret; }
   isc_tr_handle tr1 = 0L;
   fb_query_info info;
   fb_init_query_info(&info);
   //static char isc_tpb[] = {isc_tpb_version3,isc_tpb_write,isc_tpb_concurrency,isc_tpb_wait};
   //isc_start_transaction(&dbinfo->status_vector[0],&tr1,1,&dbinfo->db1,(unsigned short) sizeof(isc_tpb),isc_tpb);
   isc_start_transaction(&dbinfo->status_vector[0],&tr1,1,&dbinfo->db1,0,NULL);
   if (fb_error(dbinfo,&info)) {
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_cmd():Error, Transaccion no iniciada SQLCODE=%ld\n%s",info.SQLCODE,info.errmsg);
   } else {
      isc_stmt_handle stmt; /* Declare a statement handle. */
      memset(&stmt,0,sizeof(isc_stmt_handle)); /* Set handle to NULL before allocation. */
      // tambien puede usarse isc_dsql_execute_immediate() para no usar allocate, prepare and execute    
      /* Allocate the SQL statement handle. */
      isc_dsql_allocate_statement(&dbinfo->status_vector[0], &dbinfo->db1, &stmt);
      if (fb_error(dbinfo,&info)) {
         if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_cmd():Error, Allocate statemet failed SQLCODE=%ld\n%s",info.SQLCODE,info.errmsg);
         isc_rollback_transaction(&dbinfo->status_vector[0], &tr1);
      } else {
         isc_dsql_prepare(&dbinfo->status_vector[0], &tr1, &stmt, 0, sql_stmt, dbinfo->fb_sql_dialect, NULL); 
         if (fb_error(dbinfo,&info)) {
            if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_cmd():Error, Prepare SQL failed SQLCODE=%ld\n%s",info.SQLCODE,info.errmsg);
            isc_rollback_transaction(&dbinfo->status_vector[0], &tr1);
         } else {
  		    isc_dsql_execute(&dbinfo->status_vector[0], &tr1, &stmt, 1, NULL);
            if (fb_error(dbinfo,&info)) {
               if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_cmd():Error, Executing SQL statement SQLCODE=%ld\n%s",info.SQLCODE,info.errmsg);
               isc_rollback_transaction(&dbinfo->status_vector[0], &tr1);
            } else {
               fb_analyze_query(&dbinfo->status_vector[0],&stmt,&info);
               isc_commit_transaction(&dbinfo->status_vector[0], &tr1);
               if (fb_error(dbinfo,&info)) {
                  if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_cmd():Error in Commit Transaction SQLCODE=%ld\n%s",info.SQLCODE,info.errmsg);
                  isc_rollback_transaction(&dbinfo->status_vector[0], &tr1);
               } else {
                  ret = 1;
               }
            }
         }
         isc_dsql_free_statement(&dbinfo->status_vector[0],&stmt,DSQL_drop);
      }
   }
   fb_end_query_info(&info);
   return ret;
}

/**
 * Analiza el resultado d ejecucion de un query y en base a ello actualiza estructura fb_query_info
 * Devuelve true si logro hacerlo, sino indica error
 * 
 * @param status_vector vector de status interno Firebird del query ejecutado
 * @param stmt handle de instruccion sql a ser analizada
 * @param info query info a ser actualizada
 * 
 * @author Guillermo Cherencio
 */
int fb_analyze_query(ISC_STATUS ISC_FAR *status_vector,isc_stmt_handle *stmt,fb_query_info *info) {
   char cnt_info[] = { isc_info_sql_records, isc_info_end };
   char cmd[4]; // isc_info_sql_records devuelve info acerca de 4 cmd's
   int  val[4]; // valores de cada uno de los comandos
   char buffer[256];
   int ret=0,n=0;
   isc_dsql_sql_info(status_vector, stmt, sizeof(cnt_info), cnt_info, sizeof(buffer),buffer);
   //
   info->rows_updated=0;
   info->rows_inserted=0;
   info->rows_deleted=0;
   info->rows_selected=0;
   //
   if ( buffer[0] == isc_info_sql_records ) {
      short rec_len = (short) *(buffer+1);
      if ( rec_len > 0 ) {
         if (fb_parse_cmd(buffer+3,4,cmd,&val[0])) {
            ret=1;
            for(n=0;n<4;n++) {
               switch (cmd[n])   {
                  case isc_info_req_update_count:
                     info->rows_updated=val[n];
                     break;
                  case isc_info_req_delete_count:
                     info->rows_deleted=val[n];
                     break;
                  case isc_info_req_select_count:
                     info->rows_selected=val[n];
                     break;
                  case isc_info_req_insert_count:
                     info->rows_inserted=val[n];
                     break;
               } // end switch()
            } // end for()
         } else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_analyze_query():Error parsing query result\n");
      } else  if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_analyze_query():Error in buffer returned by isc_dsql_sql_info()(1)\n");
   } else  if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_analyze_query():Error in buffer returned by isc_dsql_sql_info()(2)\n");
   return ret;
}


/**
 * Ejecuta queries que no retornan tuplas, ejemplo: EXECUTE PROCEDURE ...
 * Utiliza funcion de callback  (onDoQuery()) para controlar la ejecucion del query, esta funcion sera local a cada proceso
 * que invoque a esta funcion.
 * El query puede tener parametros de entrada y parametros de salida.
 * Solo se ejecuta una vez el query.
 * Se puede obtener los parametros de salida una vez ejecutado el query.
 * 
 * @param dbinfo identifica la conexion actual a la base de dato
 * @param sql_stmt query SQL a ejecutar (con o sin parametros, que no devuelva filas, si puede devolver parametros de salida)
 * @param pinput cantidad de parametros de entrada
 * @param poutput cantidad de parametros de salida
 * @param onDoQuery puntero a funcion de callback a ser ejecutada en cada etapa de la ejecucion del query para que &eacute;sta tome
 * las decisiones que correspondan a cada etapa
 * @param buffer es una area de memoria que ser&aacute; pasada como ultimo argumento a la funcion de callback y puede ser un medio 
 * para comunicar la funcion de callback con el programa que ejecuto fb_do_query() y la paso como argumento de la misma
 * 
 * @author Guillermo Cherencio
 */
int fb_do_exec_query(fb_db_info *dbinfo,char *sql_stmt,int pinput,int poutput,int (*onDoQuery)(int eventType,fb_query_info *qi,void *buffer2),void *buffer) {
   int input_param = pinput;
   int output_param = poutput;
   int rf;
   fb_query_info query_info;
   fb_init_query_info(&query_info);
   query_info.dbinfo = dbinfo;
   query_info.sql = sql_stmt;
   query_info.queryId = 1;
   query_info.set_time = 0;
   query_info.set_maxtimes = 1;
   query_info.tr1 = (isc_tr_handle *) malloc(sizeof(isc_tr_handle));
   if ( query_info.tr1 == NULL ) {
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para transaccion\n");
      rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
      return 0;
   }
   query_info.stmt = (isc_stmt_handle *) malloc(sizeof(isc_stmt_handle));
   if ( query_info.stmt == NULL ) { 
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para statement\n");
      rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
      free(query_info.tr1);
      return 0;
   }
   *query_info.tr1 = 0L;
   memset(query_info.stmt,0,sizeof(isc_stmt_handle));

//printf("uno\n");
   isc_start_transaction(&dbinfo->status_vector[0],query_info.tr1,1,&dbinfo->db1,0,0);
   if (fb_error(dbinfo,&query_info)) {
      rf = (*onDoQuery)(FB_START_QUERY_ERROR,&query_info,buffer);
      free(query_info.tr1);
      return 0;
   }
//printf("dos\n");
   query_info.out_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(output_param));
   if ( query_info.out_sqlda == NULL ) { // error en asignacion de memoria
      isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
	  if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA\n");
	  rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
      return 0;
   }
   memset(query_info.out_sqlda,0,XSQLDA_LENGTH(output_param));
   query_info.out_sqlda->version = SQLDA_VERSION1;
   query_info.out_sqlda->sqln = output_param; // cantidad de parametros alocados

//printf("tres\n");   
   query_info.in_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(input_param));
   if ( query_info.in_sqlda == NULL ) { // error en asignacion de memoria
      isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
	  if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA\n");
	  rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
   }
   memset(query_info.in_sqlda,0,XSQLDA_LENGTH(input_param));
   query_info.in_sqlda->version = SQLDA_VERSION1;
   query_info.in_sqlda->sqln = input_param; // cantidad de parametros alocados
//printf("tres.1\n");   
   isc_dsql_allocate_statement(&dbinfo->status_vector[0], &dbinfo->db1, query_info.stmt);
//printf("tres.2\n");   
   isc_dsql_prepare(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 0, sql_stmt, dbinfo->fb_sql_dialect, query_info.out_sqlda); 
   if (fb_error(dbinfo,&query_info)) {
      isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
      rf = (*onDoQuery)(FB_START_QUERY_ERROR,&query_info,buffer);
      free(query_info.tr1);
      return 0;
   }
//printf("cuatro\n");   
   isc_dsql_describe_bind(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.in_sqlda);
   if (fb_error(dbinfo,&query_info)) {
      isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
      rf = (*onDoQuery)(FB_START_QUERY_ERROR,&query_info,buffer);
      free(query_info.tr1);
      return 0;
   }
   fb_dsql_setvars(query_info.in_sqlda);
   rf = (*onDoQuery)(FB_SET_QUERY_INPUT,&query_info,buffer);
   if ( rf == FB_ABORT_ALL || rf == FB_ABORT ) {
      isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
      fb_end_dsql_vars(query_info.in_sqlda);
      free(query_info.tr1);
      return 0;
   }
//printf("cinco\n");   
   fb_dsql_setvars(query_info.out_sqlda);
   rf = (*onDoQuery)(FB_SET_QUERY_OUTPUT,&query_info,buffer);
   if ( rf == FB_ABORT_ALL || rf == FB_ABORT ) {
      isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
      fb_end_dsql_vars(query_info.out_sqlda);
      fb_end_dsql_vars(query_info.in_sqlda);
      free(query_info.tr1);
      return 0;
   }

   isc_dsql_execute2(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 1, query_info.in_sqlda, query_info.out_sqlda);
   if (fb_error(dbinfo,&query_info)) {
      isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
      rf = (*onDoQuery)(FB_EXECUTE_QUERY_ERROR,&query_info,buffer);
      free(query_info.tr1);
      return 0;
   } else {
	  rf = (*onDoQuery)(FB_EXECUTE_QUERY_OK,&query_info,buffer);
   }
   if ( rf == FB_ABORT_ALL || rf == FB_ABORT ) {
      isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
      fb_end_dsql_vars(query_info.out_sqlda);
      fb_end_dsql_vars(query_info.in_sqlda);
      free(query_info.tr1);
      return 0;
   }
   
   fb_end_dsql_vars(query_info.out_sqlda);   
   fb_end_dsql_vars(query_info.in_sqlda);   
   isc_dsql_free_statement(&dbinfo->status_vector[0], query_info.stmt, DSQL_close);
   isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);   
   free(query_info.out_sqlda);   
   free(query_info.in_sqlda);   
   free(query_info.tr1);
   free(query_info.stmt);
   fb_end_query_info(&query_info);
   return 1;
}


/**
 * Ejecuta todo tipo de queries firebird (select,update,insert,delete,etc.) con o sin parametros
 * Utiliza funcion de callback  (onDoQuery()) para controlar la ejecucion del query, esta funcion sera local a cada proceso
 * que invoque a esta funcion.
 * queryId es un numero arbitrario y unico por aplicacion para luego ser usado desde funcion de callback para su identificacion, puesto
 * que una misma funcion callback puede servir para muchos queries
 * Es un query?   Tiene parametros?     Metodo
 * No                    No                1 se ejecuta una sola vez
 * No                    Si                2
 * Si                    No                3 se ejecuta una sola vez, devolver estructura con toda la info para iterar, retornar antes de fetch
 * Si                    Si                4 idem
 * 
 * @param dbinfo identifica la conexion actual a la base de dato
 * @param queryId numero arbitrario y unico por aplicacion para luego ser usado desde funcion de callback para su identificacion, puesto
 * que una misma funcion callback puede servir para muchos queries
 * @param sql query SQL a ejecutar (con o sin parametros, que devuelva o no filas)
 * @param onDoQuery puntero a funcion de callback a ser ejecutada en cada etapa de la ejecucion del query para que &eacute;sta tome
 * las decisiones que correspondan a cada etapa
 * @param buffer es una area de memoria que ser&aacute; pasada como ultimo argumento a la funcion de callback y puede ser un medio 
 * para comunicar la funcion de callback con el programa que ejecuto fb_do_query() y la paso como argumento de la misma
 * 
 * @author Guillermo Cherencio
 */
int fb_do_query(fb_db_info *dbinfo,int queryId,char *sql,int (*onDoQuery)(int eventType,fb_query_info *qi,void *buffer2),void *buffer) {
   if ( sql == NULL || dbinfo == NULL ) return 0;
   int len_sql_stmt = strlen(sql)+1,expand=0;
   if ( strcasestr(sql,"SELECT ") == NULL && strcasestr(sql,"INSERT ") == NULL && 
		strcasestr(sql,"UPDATE ") == NULL && strcasestr(sql,"DELETE ") == NULL && 
		strcasestr(sql,"EXECUTE ") == NULL ) {
		expand=1;
		len_sql_stmt+=20;
   }
   char sql_stmt[len_sql_stmt];
   if (!expand) strcpy(sql_stmt,sql);
   else         snprintf(sql_stmt,len_sql_stmt,"SELECT * FROM %s",sql);
   int ret = 0,rf,salir=0,input_param=10,output_param=10;
   int method=fb_dsql_method(sql_stmt);
   int bStartFlag=0;

if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"do_query() method=%d query:[%s]\n",method,sql_stmt);
//   ISC_STATUS fetch_stat;

// ATENCION !!! VERIFICAR LIBERACION DE MEMORIA DE QUERIES Y ESTRUCTURAS ADICIONALES antes de salir de esta funcion

   // inicializo query_info data
   fb_query_info query_info;
   fb_init_query_info(&query_info);
   query_info.dbinfo = dbinfo;
   query_info.sql = sql_stmt;
   query_info.queryId = queryId;
   query_info.set_time = 0;
   query_info.set_maxtimes = 1;
   query_info.tr1 = (isc_tr_handle *) malloc(sizeof(isc_tr_handle));
   if ( query_info.tr1 == NULL ) {
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para transaccion\n");
      rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
      return 0;
   }
   query_info.stmt = (isc_stmt_handle *) malloc(sizeof(isc_stmt_handle));
   if ( query_info.stmt == NULL ) { 
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para statement\n");
      rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
      free(query_info.tr1);
      return 0;
   }
   *query_info.tr1 = 0L;
   memset(query_info.stmt,0,sizeof(isc_stmt_handle));

   char isc_tpb[] = {isc_tpb_version3,isc_tpb_write,isc_tpb_concurrency,isc_tpb_wait};
   //char isc_tpb2[] = {isc_tpb_version3,isc_tpb_read,isc_tpb_wait};
   if ( method == 3 || method == 4 ) { // select
      //isc_start_transaction(&dbinfo->status_vector[0],query_info.tr1,1,&dbinfo->db1,(unsigned short) sizeof(isc_tpb2),isc_tpb2);
      isc_start_transaction(&dbinfo->status_vector[0],query_info.tr1,1,&dbinfo->db1,0,0);
   } else { // insert,update,delete,execute procedure...
      isc_start_transaction(&dbinfo->status_vector[0],query_info.tr1,1,&dbinfo->db1,(unsigned short) sizeof(isc_tpb),isc_tpb);
   }

   if (fb_error(dbinfo,&query_info)) {
      rf = (*onDoQuery)(FB_START_QUERY_ERROR,&query_info,buffer);
      free(query_info.tr1);
      free(query_info.stmt);
      return 0;
   }
   
   bStartFlag=1;  // se hizo start transaction

//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"6 ");
   switch(method) {
      case 1: // no query no parameters
         isc_dsql_execute_immediate(&dbinfo->status_vector[0], &dbinfo->db1, query_info.tr1,0, sql_stmt, dbinfo->fb_sql_dialect, NULL);
         if (fb_error(dbinfo,&query_info)) {
            rf = (*onDoQuery)(FB_EXECUTE_QUERY_ERROR,&query_info,buffer);
         } else {
            rf = (*onDoQuery)(FB_EXECUTE_QUERY_OK,&query_info,buffer);
         }
         switch(rf) {
            case FB_ABORT_ALL:
            case FB_ABORT:
               isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
               bStartFlag=0;  // se hizo fin start transaction
               break;
            case FB_CONTINUE:
            default:
               //isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);
               //bStartFlag=0;  // se hizo fin start transaction
               ret = 1;
               break;
         }
         if ( bStartFlag ) { isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);bStartFlag=0; }
         break;               
      case 2: // no query with input parameters
         query_info.in_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(input_param)); // aloco espacio para 10 parametros de entrada
         if ( query_info.in_sqlda == NULL ) { // error en asignacion de memoria
           isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
           if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA\n");
           rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
           bStartFlag=0;  // se hizo fin start transaction
           break;
         }
         memset(query_info.in_sqlda,0,XSQLDA_LENGTH(input_param));
         query_info.in_sqlda->version = SQLDA_VERSION1;
         query_info.in_sqlda->sqln = input_param; // cantidad de parametros alocados
         isc_dsql_allocate_statement(&dbinfo->status_vector[0], &dbinfo->db1, query_info.stmt);
         if ( !fb_error(dbinfo,&query_info) ) {
            isc_dsql_prepare(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 0, sql_stmt, dbinfo->fb_sql_dialect, query_info.in_sqlda); 
            if ( !fb_error(dbinfo,&query_info) ) {
               isc_dsql_describe_bind(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.in_sqlda);
               if ( !fb_error(dbinfo,&query_info) ) {
                  // si hay mas de 10 parametros de entrada, debo ajustar el espacio previamete alocado
                  if (query_info.in_sqlda->sqld > query_info.in_sqlda->sqln) {
                     input_param = query_info.in_sqlda->sqld;
                     free(query_info.in_sqlda);
                     query_info.in_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(input_param));
                     if ( query_info.in_sqlda == NULL ) { // error en asignacion de memoria
                        isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                        if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA(2)\n");
                        rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
                        bStartFlag=0;  // se hizo fin start transaction
                        break;
                     }
                     memset(query_info.in_sqlda,0,XSQLDA_LENGTH(input_param));
                     query_info.in_sqlda->sqln = input_param;
                     query_info.in_sqlda->version = SQLDA_VERSION1;
                     isc_dsql_describe_bind(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.in_sqlda);
                  }
                  while(!salir && query_info.set_time < query_info.set_maxtimes) {
                     fb_dsql_setvars(query_info.in_sqlda);
                     rf = (*onDoQuery)(FB_SET_QUERY_INPUT,&query_info,buffer);
                     switch(rf) {
                        case FB_ABORT_ALL:
                           salir=1;
                        case FB_ABORT:
                           if (query_info.set_time == 0) { isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);bStartFlag=0;}
                           break;
                        case FB_CONTINUE:
                        default:
                           // la primera vez, ya hizo start transaction
                           if ( query_info.set_time > 0 ) {
                              isc_start_transaction(&dbinfo->status_vector[0],query_info.tr1,1,&dbinfo->db1,(unsigned short) sizeof(isc_tpb),isc_tpb);
                           }
                           isc_dsql_execute(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 1, query_info.in_sqlda);
                           if (fb_error(dbinfo,&query_info)) {
                              rf = (*onDoQuery)(FB_EXECUTE_QUERY_ERROR,&query_info,buffer);
                           } else {
                              rf = (*onDoQuery)(FB_EXECUTE_QUERY_OK,&query_info,buffer);
                           }
                           switch(rf) {
                              case FB_ABORT_ALL:
                                 salir=1;
                              case FB_ABORT:
                                 isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                                 bStartFlag=0;  // se hizo fin start transaction
                                 break;
                              case FB_CONTINUE:
                              default:
                                 isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);
                                 bStartFlag=0;  // se hizo fin start transaction
                                 break;
                           } // switch
                           break;
                     } // switch
                     if ( !salir ) query_info.set_time++;
                     fb_end_dsql_vars(query_info.in_sqlda);
                  } // while
                  ret = 1;
               } // error en describe bind
            } // error en sql prepare
            isc_dsql_free_statement(&dbinfo->status_vector[0],query_info.stmt,DSQL_drop);
         } // error en allocate statement
         if ( bStartFlag ) { isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);bStartFlag=0; }
         if (!ret) {
            query_info.SQLCODE = isc_sqlcode(&dbinfo->status_vector[0]);
            rf = (*onDoQuery)(FB_START_QUERY_ERROR,&query_info,buffer);
         }
         free(query_info.in_sqlda);
         break;
      case 3: // query with output parameters only
         query_info.out_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(output_param));
         if ( query_info.out_sqlda == NULL ) { // error en asignacion de memoria
           isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
           bStartFlag=0;  // se hizo fin start transaction
           if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA(3)\n");
           rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
           break;
         }
         memset(query_info.out_sqlda,0,XSQLDA_LENGTH(output_param));
         query_info.out_sqlda->version = SQLDA_VERSION1;
         query_info.out_sqlda->sqln = output_param;
         isc_dsql_allocate_statement(&dbinfo->status_vector[0], &dbinfo->db1, query_info.stmt);
         if ( !fb_error(dbinfo,&query_info) ) {
            isc_dsql_prepare(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 0, sql_stmt, dbinfo->fb_sql_dialect, 0);
            if ( !fb_error(dbinfo,&query_info) ) {
               isc_dsql_describe(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.out_sqlda);
               if ( !fb_error(dbinfo,&query_info) ) {
                  // si hay mas de 10 parametros de salida, debo ajustar el espacio previamete alocado
                  if (query_info.out_sqlda->sqld > query_info.out_sqlda->sqln) {
                     output_param = query_info.out_sqlda->sqld;
                     free(query_info.out_sqlda);
                     query_info.out_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(output_param));
                     if ( query_info.out_sqlda == NULL ) { // error en asignacion de memoria
                        isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                        if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA(4)\n");
                        rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
                        bStartFlag=0;  // se hizo fin start transaction
                        break;
                     }
                     memset(query_info.out_sqlda,0,XSQLDA_LENGTH(output_param));
                     query_info.out_sqlda->sqln = output_param;
                     query_info.out_sqlda->version = SQLDA_VERSION1;
                     isc_dsql_describe(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.out_sqlda);
                  }
                  while(!salir && query_info.set_time < query_info.set_maxtimes) {
                     if (query_info.set_time > 0) { // la primera vez ya hizo describe()
                        isc_dsql_describe(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.out_sqlda);
                     }
                     fb_dsql_setvars(query_info.out_sqlda);
                     rf = (*onDoQuery)(FB_SET_QUERY_OUTPUT,&query_info,buffer);
                     switch(rf) {
                        case FB_ABORT_ALL:
                           salir=1;
                        case FB_ABORT:
                           if (query_info.set_time == 0) { isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);bStartFlag=0;}  // se hizo fin start transaction
                           break;
                        case FB_CONTINUE:
                        default:
                           // la primera vez, ya hizo start transaction
                           if ( query_info.set_time > 0 ) {
                              isc_start_transaction(&dbinfo->status_vector[0],query_info.tr1,1,&dbinfo->db1,0,0);
                           }
                           // decido que usar? si _execute() o _execute2()
                           if ( strncasecmp(sql_stmt,"SELECT",6) == 0 ) {
							  isc_dsql_execute(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 1, NULL);
						   } else {
							  isc_dsql_execute2(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 1, query_info.in_sqlda, query_info.out_sqlda);							   
						   }
                           if (fb_error(dbinfo,&query_info)) {
                              rf = (*onDoQuery)(FB_EXECUTE_QUERY_ERROR,&query_info,buffer);
                           } else {
                              rf = (*onDoQuery)(FB_EXECUTE_QUERY_OK,&query_info,buffer);
                           }
                           switch(rf) {
                              case FB_ABORT_ALL:
                                 salir=1;
                              case FB_ABORT:
                                 isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                                 bStartFlag=0;  // se hizo fin start transaction
                                 break;
                              case FB_CONTINUE:
                              default:
// no es necesario cursor        isc_dsql_set_cursor_name(&dbinfo->status_vector[0],query_info.stmt,"dyn_cursor", 0);
                                 fb_analyze_query(&dbinfo->status_vector[0],query_info.stmt,&query_info);
                                 // fetch records
                                 query_info.rows_fetched=0;
                                 rf = (*onDoQuery)(FB_FETCH_RECORDS,&query_info,buffer);
                                 switch(rf) {
                                    case FB_ABORT_ALL:
                                       salir=1;
                                    case FB_ABORT:
                                       isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                                       bStartFlag=0;  // se hizo fin start transaction
                                       break;
                                    case FB_CONTINUE:
                                    default:
                                       isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);
                                       bStartFlag=0;  // se hizo fin start transaction
                                       break;
                                 } // switch
                                 // 
                                 //isc_dsql_free_statement(&dbinfo->status_vector[0], query_info.stmt, DSQL_close);
                                 break;
                           } // switch
                           break;
                     } // switch
/*********************************
                     while ((fetch_stat = isc_dsql_fetch(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.out_sqlda)) == 0) {
                        fb_dsql_outvars(query_info.out_sqlda);
                        if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"\n");
                     }
                     if (fetch_stat != 100L) {
                        fb_print_error(&dbinfo->status_vector[0],"fb_do_query():Error in method(3) Fetching Rows SQLCODE=%ld\n");
                        isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                     } else {
                        ret = 1;
                        isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);
                     }
*********************************/
                     if ( !salir ) query_info.set_time++;
                     fb_end_dsql_vars(query_info.out_sqlda);
                  } // while
                  ret = 1;
               } // error en describe bind
            } // error en sql prepare
            isc_dsql_free_statement(&dbinfo->status_vector[0], query_info.stmt, DSQL_close);
         } // error en allocate statement
         if ( bStartFlag ) { isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);bStartFlag=0; }
         free(query_info.out_sqlda);
         break;
      case 4: // falta control de errores!

		 // asigno memoria para parametros de entrada y salida
         query_info.in_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(input_param));
         if ( query_info.in_sqlda == NULL ) { // error en asignacion de memoria
           isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
           if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA(5)\n");
           rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
           bStartFlag=0;  // se hizo fin start transaction
           break;
         }
         memset(query_info.in_sqlda,0,XSQLDA_LENGTH(input_param));
         query_info.in_sqlda->version = SQLDA_VERSION1;
         query_info.in_sqlda->sqln = input_param;

         query_info.out_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(output_param));
         if ( query_info.out_sqlda == NULL ) { // error en asignacion de memoria
           isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
           if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA(6)\n");
           rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
           bStartFlag=0;  // se hizo fin start transaction
           break;
         }
         memset(query_info.out_sqlda,0,XSQLDA_LENGTH(output_param));
         query_info.out_sqlda->version = SQLDA_VERSION1;
         query_info.out_sqlda->sqln = output_param;

         isc_dsql_allocate_statement(&dbinfo->status_vector[0], &dbinfo->db1, query_info.stmt);
         if ( !fb_error(dbinfo,&query_info) ) {
			 
			 
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"do_query():while!\n");
                     while(!salir && query_info.set_time < query_info.set_maxtimes) {

						 
			 
            isc_dsql_prepare(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 0, sql_stmt, dbinfo->fb_sql_dialect, query_info.out_sqlda);
            if ( !fb_error(dbinfo,&query_info) ) {
               isc_dsql_describe_bind(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.in_sqlda);
               if ( !fb_error(dbinfo,&query_info) ) {
                  // si hay mas de 10 parametros de entrada, debo ajustar el espacio previamete alocado
                  if (query_info.in_sqlda->sqld > query_info.in_sqlda->sqln) {
                     input_param = query_info.in_sqlda->sqld;
                     free(query_info.in_sqlda);
                     query_info.in_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(input_param));
                     if ( query_info.in_sqlda == NULL ) { // error en asignacion de memoria
                       isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                       if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA(7)\n");
                       rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
                       bStartFlag=0;  // se hizo fin start transaction
                       break;
                     }
                     memset(query_info.in_sqlda,0,XSQLDA_LENGTH(input_param));
                     query_info.in_sqlda->sqln = input_param;
                     query_info.in_sqlda->version = SQLDA_VERSION1;
                     isc_dsql_describe_bind(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.in_sqlda);
                  }

                  fb_dsql_setvars(query_info.in_sqlda);
                  isc_dsql_describe(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.out_sqlda);
                  if ( !fb_error(dbinfo,&query_info) ) {
                 
                     // si hay mas de 10 parametros de salida, debo ajustar el espacio previamete alocado
                     if (query_info.out_sqlda->sqld > query_info.out_sqlda->sqln) {
                        output_param = query_info.out_sqlda->sqld;
                        free(query_info.out_sqlda);
                        query_info.out_sqlda = (XSQLDA *) malloc(XSQLDA_LENGTH(output_param));
                        if ( query_info.out_sqlda == NULL ) { // error en asignacion de memoria
                          isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                          if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_query():Error, en Asignacion de memoria para XSQLDA(8)\n");
                          rf = (*onDoQuery)(FB_MEMORY_QUERY_ERROR,&query_info,buffer);
                          bStartFlag=0;  // se hizo fin start transaction
                          break;
                        }
                        memset(query_info.out_sqlda,0,XSQLDA_LENGTH(output_param));
                        query_info.out_sqlda->sqln = output_param;
                        query_info.out_sqlda->version = SQLDA_VERSION1;
                        isc_dsql_describe(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.out_sqlda);
                     }
                     // indicar valores para los parametros de entrada

                        //fb_dsql_setvars(query_info.in_sqlda);
                        rf = (*onDoQuery)(FB_SET_QUERY_INPUT,&query_info,buffer);
                        if ( rf == FB_ABORT_ALL ) salir = 1;
                        if ( rf == FB_ABORT_ALL || rf == FB_ABORT ) {
                           if (query_info.set_time == 0) {isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);bStartFlag=0;} // se hizo fin start transaction
                           if ( !salir ) query_info.set_time++;
                           fb_end_dsql_vars(query_info.in_sqlda);
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"do_query():continue!\n");
                           continue;
                        }
/*
 // parece estar ok el param 0 tiene el valor que pasa la funcion de callback                        
 int ipb;
 memcpy(&ipb,query_info.in_sqlda->sqlvar[0].sqldata,sizeof(int));
 printf("fb_do_query(): param 0 input=[%d]\n",ipb);
*/
                        
/*
                        if (query_info.set_time > 0) { // la primera vez ya hizo describe_bin()
                           isc_dsql_describe_bind(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.in_sqlda);
                        }
*/
                        fb_dsql_setvars(query_info.out_sqlda);
                        
                        //rf = (*onDoQuery)(FB_SET_QUERY_OUTPUT,&query_info,buffer);
                        //if ( rf == FB_ABORT_ALL ) salir = 1;
                        //if ( rf == FB_ABORT_ALL || rf == FB_ABORT ) {
                           //if (query_info.set_time == 0) {isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);bStartFlag=0;}  // se hizo fin start transaction
                           //if ( !salir ) query_info.set_time++;
                           //fb_end_dsql_vars(query_info.out_sqlda);
                           //fb_end_dsql_vars(query_info.in_sqlda);
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"do_query():continue!\n");
                           //continue;
                        //}
/*
                        if (query_info.set_time > 0) { // la primera vez ya hizo describe()
                           isc_dsql_describe(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.out_sqlda);
                        }
*/
                        // la primera vez, ya hizo start transaction
                        if ( query_info.set_time > 0 ) {
                           isc_start_transaction(&dbinfo->status_vector[0],query_info.tr1,1,&dbinfo->db1,0,0);
                        }
 					    // decido que usar? si _execute() o _execute2()
					    //if ( strncasecmp(sql_stmt,"SELECT",6) == 0 ) {
						  isc_dsql_execute(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 1, query_info.in_sqlda);
					    //} else {
//ATENCION!!!							
//BUG EN C API?? ALLI INDICA QUE METHOD 4 DEBE UTILIZAR EXECUTE2 PERO PARECE FUNCIONAR SOLO CON EXECUTE
//REPORTADO EN http://tech.groups.yahoo.com/group/firebird-support/message/4169
						//  isc_dsql_execute2(&dbinfo->status_vector[0], query_info.tr1, query_info.stmt, 1, query_info.in_sqlda, query_info.out_sqlda);
					    //}
                        if (fb_error(dbinfo,&query_info)) {
                           rf = (*onDoQuery)(FB_EXECUTE_QUERY_ERROR,&query_info,buffer);
                        } else {
                           rf = (*onDoQuery)(FB_EXECUTE_QUERY_OK,&query_info,buffer);
                        }
                        if ( rf == FB_ABORT_ALL ) salir = 1;
                        if ( rf == FB_ABORT_ALL || rf == FB_ABORT ) {
                           isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                           if ( !salir ) query_info.set_time++;
                           //fb_end_dsql_vars(query_info.out_sqlda);
                           //fb_end_dsql_vars(query_info.in_sqlda);
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"do_query():continue!\n");
                           bStartFlag=0;  // se hizo fin start transaction
                           continue;
                        }
                        //el analyze query parece no afectar al hecho de no poder recuperar filas
                        isc_dsql_set_cursor_name(&dbinfo->status_vector[0], query_info.stmt,"dyn_cursor", 0); // luego cambiar nombre de cursor s/queryid
                        fb_analyze_query(&dbinfo->status_vector[0],query_info.stmt,&query_info);
                        // fetch records
                        query_info.rows_fetched=0;
                        rf = (*onDoQuery)(FB_FETCH_RECORDS,&query_info,buffer);
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"do_query(): retorno de OnDoQuery(fetch_records)=%d\n",rf);
                        if ( rf == FB_ABORT_ALL ) salir = 1;
                        if ( rf == FB_ABORT_ALL || rf == FB_ABORT ) {
                           isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
                           if ( !salir ) query_info.set_time++;
                           //fb_end_dsql_vars(query_info.out_sqlda);
                           //fb_end_dsql_vars(query_info.in_sqlda);
                           isc_dsql_free_statement(&dbinfo->status_vector[0], query_info.stmt, DSQL_close);
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"do_query():continue!\n");
                           bStartFlag=0;  // se hizo fin start transaction
                           continue;
                        } else {
                           isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);
                           bStartFlag=0;  // se hizo fin start transaction
                        }
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_do_query():close cursor dyn_cursor!\n");
                        isc_dsql_free_statement(&dbinfo->status_vector[0], query_info.stmt, DSQL_close);
/*********************************
         while ((fetch_stat = isc_dsql_fetch(&dbinfo->status_vector[0], query_info.stmt, 1, query_info.out_sqlda)) == 0) {
            fb_dsql_outvars(query_info.out_sqlda);
            if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"\n");
         }
         if (fetch_stat != 100L) {
            // isc_dsql_fetch returns 100 if no more rows remain to be retrieved 
            if ( FB_SHOW_MESSAGES ) fb_print_error(&dbinfo->status_vector[0],"fb_do_query():Error in method(3) Fetching Rows SQLCODE=%ld\n");
            isc_rollback_transaction(&dbinfo->status_vector[0], query_info.tr1);
         } else {
            ret = 1;
            isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);
         }
*********************************/
                  } // error en describe bind .out_sqlda
               } // error en describe bind .in_sqlda
            } // error en sql prepare


                        if ( !salir ) query_info.set_time++;
            
                     } // while
                     ret = 1;
					 fb_end_dsql_vars(query_info.out_sqlda);
					 fb_end_dsql_vars(query_info.in_sqlda);
            
            isc_dsql_free_statement(&dbinfo->status_vector[0], query_info.stmt, DSQL_close);
         } // error en allocate statement
         if ( bStartFlag ) { isc_commit_transaction(&dbinfo->status_vector[0], query_info.tr1);bStartFlag=0; }
         free(query_info.in_sqlda);
         free(query_info.out_sqlda);
         ret = 1;
         break;
   } // switch(method)
   free(query_info.tr1);
   free(query_info.stmt);
   fb_end_query_info(&query_info);
   return ret;
}

/**
 * Ejecuta todo tipo de queries firebird (select,update,insert,delete,etc.) sin parametros,
 * tambien puede hacer referencia al nombre de una vista,select procedure o tabla, solo men
 * cionando su nombre o su nombre sus parametros (en el caso de select procedures), en tal caso,
 * se ejecutara un select * from vista/select procedure/tabla
 * Internamente utiliza funcion de callback  (onDoQuery()) por defecto.
 * Asume query Id 1.
 * Devuelve un puntero de tipo query o NULL en caso de error
 * Utiliza fb_do_query()
 * 
 * @param dbinfo identifica la conexion actual a la base de dato
 * @param sql query SQL a ejecutar (con o sin parametros, que devuelva o no filas)
 * 
 * @author Guillermo Cherencio
 */
query *fb_do_single_query(fb_db_info *dbinfo,char *sql_stmt) {
	query *myquery = (query *) malloc(sizeof(query));
	if ( myquery != NULL) {
		fb_init(myquery);
		if ( !fb_do_query(dbinfo,1,sql_stmt,onDoGenericQuery,myquery) ) {
			fb_free(myquery);
			myquery=NULL;
		}
	}
	return myquery;
}

/**
 * Funcion de uso interno
 *   buffer apunta a un buffer con informacion api con el siguiente formato:
 *   [codigo cmd (1 byte)]
 *   [largo cmd (2 bytes)] indica cuantos bytes tiene el cmd
 *   ...
 *   termina con [codigo cmd (1 byte)] == 1
 *
 *   [tope] indica la cantidad maxima de iteraciones, si tope = 0 implica que no hay limite
 *   [cmd] apunta a un arreglo con espacio suficiente para almacenar cada uno de los comandos parseados
 *   [value] apunta a un arreglo de enteros (int) con espacio suficiente para
 *   almacenar los valores de cada comando
 * 
 * @param buffer que apunta a informacion api 
 * @param tope 
 * @param cmd 
 * @param value
 * 
 * @author Guillermo Cherencio
 */
int fb_parse_cmd(char *buffer,int tope,char *cmd,int *value) {
   int i=0,ret=1,n=0;
   short rec_len;
   while ( (tope == 0 || n < tope) && buffer[i] != 1) {
      *cmd = buffer[i];
      rec_len = (short) *(buffer+i+1);
      if ( rec_len > 0 ) {
         if ( rec_len > sizeof(int) ) {
            *value = 0;
            if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_parse_cmd(): cmd %d retorna %d bytes! en vez de %ld\n",*cmd,rec_len,sizeof(int));
         } else {
            *value = (int) isc_vax_integer(buffer+i+3, rec_len);
         }
      } else { 
         if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_parse_cmd(): cmd %d retorna %d bytes!\n",*cmd,rec_len);
         ret=0; break; 
      }
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"cmd=%d len=%d value=%d\n",*cmd,rec_len,*value);
      i+=2+rec_len+1;
      value++;
      n++;
      cmd++;
   }
   return ret;     
}

/**
 *   Idem int fb_parse_cmd(), permite extraer solo 1 comando que devuelve algo no int y lo almacena en buffer string <value>
 *   [value] tiene suficiente espacio para almacenar el resultado
 *   ej: isc_info_firebird_version
 * 
 * @param buffer que apunta a informacion api 
 * @param cmd 
 * @param value
 * 
 * @author Guillermo Cherencio
 */
int fb_parse_scmd(char *buffer,char *cmd,char *value) {
   int i=0,ret=1;
   *cmd = buffer[i];
   if ( *cmd == isc_info_truncated || *cmd == isc_info_error ) {
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_parse_scmd(): info truncada o info erronea!\n");
      return 0; 
   }
   short rec_len = (short) *(buffer+i+1);
   if ( rec_len > 0 ) {
      memset(value,0,rec_len+1);
      memcpy(value,buffer+i+3,rec_len);
   } else { 
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_parse_scmd(): cmd %d retorna %d bytes!\n",*cmd,rec_len);
      ret=0; 
   }
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"cmd=%d len=%d value=%*s\n",*cmd,rec_len,rec_len,value);
   return ret;
}

/**
 * Funcion creada para ejecutar algunos comandos especiales de la b.d. que no puede ejecutarse con
 * las otras funciones de queries.
 * ej: sql_stmt="CREATE DATABASE ..."
 * 
 * @param dbinfo conexion actual a base de dato
 * @param sql_stmt comando SQL a ejecutar 
 * 
 * @author Guillermo Cherencio
 */
int fb_do_db(fb_db_info *dbinfo,char *sql_stmt) {
   int ret = 0;
   isc_tr_handle tr1 = 0L;
   fb_query_info qi;
   fb_init_query_info(&qi);
   isc_detach_database(&dbinfo->status_vector[0], &dbinfo->db1);
   if (fb_error(dbinfo,&qi)) {
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_db():Error en Detach Database SQLCODE=%ld\n%s",qi.SQLCODE,qi.errmsg);
   } else {
      isc_dsql_execute_immediate(&dbinfo->status_vector[0], &dbinfo->db1, &tr1, 0, sql_stmt, dbinfo->fb_sql_dialect, NULL); // sql dialect 3
      if (fb_error(dbinfo,&qi)) {
         if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_do_db():Error en Execute Immediate SQLCODE=%ld\n%s",qi.SQLCODE,qi.errmsg);
      } else {
         ret = 1;
      }
   }
   return ret;
}

/**
 * Funcion de uso interno, determina el tipo de query a ejecutar acorde con sql_stmt
 * permitido: sql_stmt=SELECT/DELETE/INSERT/UPDATE/ALTER TABLE/CREATE INDEX/... con y sin parametros
 * prohibido: BLOB,ARRAY,CREATE DATABASE,CLOSE,DESCRIBE,EXECUTE,DECLARE CURSOR,FETCH,PREPARE,OPEN
 * Es un query?   Tiene parametros?     Metodo
 * No                    No                1
 * No                    Si                2
 * Si                    No                3
 * Si                    Si                4
 * 
 * @param sql_stmt comando SQL a ejecutar 
 * 
 * @author Guillermo Cherencio
 */
int fb_dsql_method(char *sql_stmt) {
   int ret;
   //|| strncasecmp(sql_stmt,"EXECUTE PROCEDURE",17) == 0
   if ( strncasecmp(sql_stmt,"SELECT",6) == 0 ) {
      if ( strstr(sql_stmt,"?") != NULL ) {
         ret=4;
      } else {
         ret=3;
      }
   } else {
      if ( strstr(sql_stmt,"?") != NULL ) {
         ret=2;
      } else {
         ret=1;
      }
   }
   return ret;
}

/**
 * Luego de ejecutar un query y antes de los eventos FB_SET_QUERY_INPUT / FB_SET_QUERY_OUTPUT se debe asginar memoria
 * para cada una de las columnas del nuevo query.  Los datos de las tuplas se reemplazaran en las areas de memoria previamente
 * asignadas por esta funcion.
 * La desasignacion de memoria la realizad fb_end_dsql_vars()
 * 
 * @param in_sqlda 
 * 
 * @author Guillermo Cherencio
 */
void fb_dsql_setvars(XSQLDA *in_sqlda) {
   XSQLVAR *var = in_sqlda->sqlvar;
   int i;
   short dtype;
   int *pint;
   long *plong;
   short *pshort;
   ISC_QUAD *pblob_id;
/*

 #define SQL_TEXT                           452
 #define SQL_VARYING                        448
 #define SQL_SHORT                          500
 #define SQL_LONG                           496
 #define SQL_FLOAT                          482
 #define SQL_DOUBLE                         480
 #define SQL_D_FLOAT                        530
 #define SQL_TIMESTAMP                      510
 #define SQL_BLOB                           520
 #define SQL_ARRAY                          540
 #define SQL_QUAD                           550
 #define SQL_TYPE_TIME			    560
 #define SQL_TYPE_DATE                      570
 #define SQL_INT64			    580
 #define SQL_DATE			    SQL_TIMESTAMP

*/
         for (i=0; i < in_sqlda->sqld; i++, var++) {
            /* Process each XSQLVAR parameter structure here.
               var points to the parameter structure. */
            dtype = (var->sqltype & ~1); /* drop NULL flag for now */
            switch(dtype) {
               case SQL_TEXT:
                  var->sqldata = (char *) malloc(sizeof(char)*var->sqllen+2);
                  if ( var->sqldata != NULL ) memset(var->sqldata,0,var->sqllen+2);
                  else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_dsql_setvars():Error en asignacion de memoria(0.1)\n");
                  break;
               case SQL_VARYING: /* coerce to SQL_TEXT */
                  var->sqltype = SQL_TEXT;
                  /* allocate local variable storage */
                  var->sqldata = (char *) malloc(sizeof(char)*var->sqllen+2);
                  if ( var->sqldata != NULL ) memset(var->sqldata,0,var->sqllen+2);
                  else if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_dsql_setvars():Error en asignacion de memoria(0.2)\n");
                  break;
               case SQL_SHORT:
                  pint = (int *) malloc(sizeof(int));
                  if ( pint != NULL ) {
                     *pint=0;
                     var->sqldata = (char *) pint;
                  } else {
                     if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_dsql_setvars():Error, en asignacion de memoria!(1)\n");
                  }
                  break;
               case SQL_LONG:
                  plong = (long *) malloc(sizeof(long));
                  if ( plong != NULL ) {
                     *plong=0L;
                     var->sqldata = (char *) plong;
                  } else {
                     if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_dsql_setvars():Error, en asignacion de memoria!(2)\n");
                  }
                  break;
               case SQL_ARRAY:
               case SQL_BLOB:
                  pblob_id = (ISC_QUAD ISC_FAR *) malloc(sizeof(ISC_QUAD));
                  if ( pblob_id != NULL ) {
                     memset(pblob_id,0,sizeof(ISC_QUAD));
                     var->sqldata = (char *) pblob_id;
                  } else {
                     if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_dsql_setvars():Error, en asignacion de memoria!(3)\n");
                  }
                  break;
               default:
                  var->sqldata = ( char * ) malloc ( (sizeof(char) * (var->sqllen+2)) );
                  if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_dsql_setvars():Warning, tipo de dato sql [%d] no implementado!\n",dtype);
            } /* end of switch statement */
            if (var->sqltype & 1) {
               /* allocate variable to hold NULL status */
               pshort = (short *) malloc(sizeof(short));
               if ( pshort != NULL ) {
                  *pshort = 0;
                  var->sqlind = pshort;
               } else {
                  if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_dsql_setvars():Error, en asignacion de memoria!(9)\n");
               }
            }
         } /* end of for loop */
}

/**
 * Permite mostrar por pantalla los valores actuales de cada una de las columnas
 * de la tupla actual
 * 
 * @param out_sqlda 
 * 
 * @author Guillermo Cherencio
 */
void fb_dsql_outvars(XSQLDA *out_sqlda) {
   int i;
   for (i=0; i < out_sqlda->sqld; i++) {
      if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES," [%d]=[%s]",i,get_data(out_sqlda,i));
   }
}


/**
 * Es una version mas "user friendly" que get_data(), permite hacer lo mismo que esta ultima
 * pero con un nivel menor de complejidad
 * 
 * @param qi query actual
 * @param pos columna a devolver
 * @return devuelve el valor de la columna pos en el query actual
 * 
 * @author Guillermo Cherencio
 */
char *fb_getcol(fb_query_info *qi,int pos) {
   return get_data(qi->out_sqlda,pos);
}

/**
 * Funcion de uso interno
 * Devuelve una representacion en string del valor  almacenado en la tupla actual, en la columna pos
 * Funcion escencial para recuperar los valores de las tuplas, luego de la ejecucion de un query
 * 
 * @param out_sqlda query
 * @param pos columna a devolver
 * @return devuelve el valor de la columna pos en el query actual
 * 
 * @author Guillermo Cherencio
 */
char *get_data (XSQLDA *out_sqlda, int pos ) {
   short dtype;
   char data[1024], *p;
   char blob_s[20], date_s[25];
   short len;
   VARY *vary;
   struct tm times;
   ISC_QUAD bid;
   XSQLVAR *var = out_sqlda->sqlvar;

   if ( ( pos + 1 ) > out_sqlda->sqln || pos < 0) {
      if ( FB_SHOW_MESSAGES ) fprintf(stderr,"get_data():Error, %d no es una columna valida\n",pos);
      return NULL;
   }

   var += pos;
   dtype = var->sqltype & ~1;

   if ( ( var->sqltype & 1 ) && ( *var->sqlind < 0 ) ) { // proceso NULL value
      switch ( dtype ) {
         case SQL_TEXT:
         case SQL_VARYING:
            len = var->sqllen;
            break;
         case SQL_SHORT:
            len = 6;
            if ( var->sqlscale > 0 ) len += var->sqlscale;
            break;
         case SQL_LONG:
            len = 11;
            if ( var->sqlscale > 0 ) len += var->sqlscale;
            break;
         case SQL_INT64:
            len = 21;
            if ( var->sqlscale > 0 ) len += var->sqlscale;
            break;
         case SQL_FLOAT:
            len = 15;
            break;
         case SQL_DOUBLE:
            len = 24;
            break;
         case SQL_TIMESTAMP:
            len = 24;
            break;
         case SQL_TYPE_DATE:
            len = 10;
            break;
         case SQL_TYPE_TIME:
            len = 13;
            break;
         case SQL_BLOB:
         case SQL_ARRAY:
         default:
            len = 17;
            break;
      }
      // aseguro un espacio minimo para alvergar a "NULL"
      if ( len < 5 ) len=5;
      p = (char *) malloc(len+2);
      if (p != NULL) {
         memset(p,0,len+2);
         if ( ( dtype == SQL_TEXT ) || ( dtype == SQL_VARYING ) ) snprintf ( p, len+1, "%s", "NULL" );
         else snprintf ( p, len+1, "%s", "NULL" );
      } else {
         if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(1)");
         return NULL;
      }
   } else {
      switch ( dtype ) {
         case SQL_TEXT:
            p = (char *) malloc(var->sqllen+2);
//printf("var->sqllen=%d var->sqldata=[%s]\n",var->sqllen,var->sqldata);            
            if (p != NULL) snprintf ( p, var->sqllen+1, "%s", var->sqldata );
//if (p != NULL) printf("p=[%s]\n",p);            
            else { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(2)");return NULL; }
            break;
         case SQL_VARYING:
            vary = ( VARY * ) var->sqldata;
            vary->vary_string[vary->vary_length] = '\0';
            p = (char *) malloc(var->sqllen+1);
            if (p != NULL) snprintf ( p, var->sqllen+1, "%-*s", var->sqllen, vary->vary_string );
            else { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(3)");return NULL; }
            break;
         case SQL_SHORT:
         case SQL_LONG:
         case SQL_INT64:
            {
               ISC_INT64 value = 0;
               short field_width = 0;
               short dscale;
               switch ( dtype ) {
                  case SQL_SHORT:
                     value = ( ISC_INT64 ) * ( short ISC_FAR * ) var->sqldata;
                     field_width = 6;
                     break;
                  case SQL_LONG:
                     value = ( ISC_INT64 ) * ( long ISC_FAR * ) var->sqldata;
                     field_width = 11;
                     break;
                  case SQL_INT64:
                     value = ( ISC_INT64 ) * ( ISC_INT64 ISC_FAR * ) var->sqldata;
                     field_width = 21;
                     break;
               }
               dscale = var->sqlscale;
               if ( dscale < 0 ) {
                  ISC_INT64 tens;
                  short i;
                  tens = 1;
                  for ( i = 0; i > dscale; i-- ) {
                     tens *= 10;
                     if ( value >= 0 ) {
                        sprintf ( data,"%*" ISC_INT64_FORMAT "d.%0*" ISC_INT64_FORMAT "d",field_width - 1 + dscale,( ISC_INT64 ) ( value / tens ), -dscale,( ISC_INT64 ) ( value % tens ) );
                     } else if ( ( value / tens ) != 0 ) {
                        sprintf ( data,"%*" ISC_INT64_FORMAT "d.%0*" ISC_INT64_FORMAT "d",field_width - 1 + dscale,( ISC_INT64 ) ( value / tens ), -dscale,( ISC_INT64 ) - ( value % tens ) );
                     } else {
                        sprintf ( data, "%*s.%0*" ISC_INT64_FORMAT "d",field_width - 1 + dscale,"-0", -dscale,( ISC_INT64 ) - ( value % tens ) );
                     }
                  }
               } else if ( dscale ) {
                  sprintf ( data, "%*" ISC_INT64_FORMAT "d%0*d",field_width, ( ISC_INT64 ) value, dscale, 0 );
               } else {
                  sprintf ( data, "%*" ISC_INT64_FORMAT "d", field_width, ( ISC_INT64 ) value );
               }
               int tmplen = strlen(data)+1;
               p = (char *) malloc(tmplen);
               if ( p != NULL ) strcpy(p,data);
               else { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(4)");return NULL; }
            };
            break;
         case SQL_FLOAT:
            p = (char *) malloc(16);
            if ( p != NULL ) snprintf ( p, 15, "%15g", *( float ISC_FAR * ) ( var->sqldata ) );
            else { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(5)");return NULL; }
            break;
         case SQL_DOUBLE:
            p = (char *) malloc(25);
            if ( p != NULL ) snprintf ( p, 24, "%24f", *( double ISC_FAR * ) ( var->sqldata ) );
            else { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(6)");return NULL; }
            break;
         case SQL_TIMESTAMP:
            isc_decode_timestamp ( ( ISC_TIMESTAMP ISC_FAR * ) var->sqldata, &times );
            sprintf ( date_s, "%04d-%02d-%02d %02d:%02d:%02d.%04ui",times.tm_year + 1900,times.tm_mon + 1,times.tm_mday,times.tm_hour,times.tm_min,times.tm_sec,( ( ISC_TIMESTAMP * ) var->sqldata )->timestamp_time % 10000 );
            p = (char *) malloc(strlen(date_s)+1);
            if (p != NULL) strcpy(p,date_s);
            else { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(7)");return NULL; }
            break;
         case SQL_TYPE_DATE:
            isc_decode_sql_date ( ( ISC_DATE ISC_FAR * ) var->sqldata, &times );
            sprintf ( date_s, "%04d-%02d-%02d",times.tm_year + 1900,times.tm_mon + 1,times.tm_mday );
            p = (char *) malloc(strlen(date_s)+1);
            if (p != NULL) strcpy(p,date_s);
            else { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(8)");return NULL; }
            break;
         case SQL_TYPE_TIME:
            isc_decode_sql_time ( ( ISC_TIME ISC_FAR * ) var->sqldata, &times );
            sprintf ( date_s, "%02d:%02d:%02d.%04ui",times.tm_hour,times.tm_min,times.tm_sec, ( *( ( ISC_TIME * ) var->sqldata ) ) % 10000 );
            p = (char *) malloc(strlen(date_s)+1);
            if (p != NULL) strcpy(p,date_s);
            else { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(9)");return NULL; }
            break;
         case SQL_BLOB:
         case SQL_ARRAY:
            /* Print the blob id on blobs or arrays */
            bid = *( ISC_QUAD ISC_FAR * ) var->sqldata;
            sprintf ( blob_s, "%08x:%08x", ( unsigned int ) bid.gds_quad_high,( unsigned int ) bid.gds_quad_low );
            p = (char *) malloc(strlen(blob_s)+1);
            if (p != NULL) strcpy(p,blob_s);
            else { if ( FB_SHOW_MESSAGES ) fprintf(stderr,"Error en asignacion de memoria(10)");return NULL; }
            break;
         default:
            break;
      }
   }
   return ( p );
}

/**
 * Imprime mensaje acerca de la conexion actual (incluye usuario y contrase\F1a)
 * no retorna nada
 * 
 * @param dbinfo conexion actual a base de dato 
 * 
 * @author Guillermo Cherencio
 */
void fb_print_db_info( fb_db_info *dbinfo) {
   if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"Database: [%s]\nUser: [%s]\nPassword: [%s]\nRole: [%s]\n"
          "Version: [%s]\nPage Size: %d\nBuffers: %d\nRead Only?: %d\n"
          "SQL Dialect: %d\n",
          dbinfo->dbname,dbinfo->user,dbinfo->passw,dbinfo->role,
          dbinfo->fb_version,dbinfo->fb_page_size,dbinfo->fb_num_buffers,dbinfo->fb_read_only,
          dbinfo->fb_sql_dialect);
}


/**
 * Verifica si hubo error en la ejecucion del ultimo query, asigna hasta un maximo
 * de 20 mensajes de error de 512 bytes cada uno
 * asigna memoria en qi->errmsg, carga error en qi->fb_error
 * devuelve true si hubo error, sino devuelve false
// CONTINUAR CON LIMPIEZA DE MEMORIA, ELIMINACION DE do_cmd() ?? 
 * limite: levanta un maximo de 20 mensajes de 512 bytes cada uno
 *
 * 
 * @param dbinfo conexion actual a base de dato 
 * @param qi query actual a verificar si el mismo produjo algun error
 * 
 * @author Guillermo Cherencio
 */
int fb_error(fb_db_info *dbinfo,fb_query_info *qi) {
   int ret = (dbinfo->status_vector[0] == 1 && dbinfo->status_vector[1] > 0);
   if ( qi != NULL ) {
      qi->fb_error = ret;
      if ( qi->errmsg != NULL ) free(qi->errmsg);
      if ( ret ) { // error!!
         qi->SQLCODE = isc_sqlcode(&dbinfo->status_vector[0]);
         long *pvector = dbinfo->status_vector;
         char msg[20][512];
         unsigned int largo_msg = 512;
         int i=0,w=0,lenmsg=0;
         char *psqlcode;
         //while( i < 20 && isc_interprete(msg[i],&pvector) ) {
		 while( i < 20 && fb_interpret(msg[i],largo_msg,(const ISC_STATUS**) &pvector) ) {
            lenmsg+=strlen(msg[i])+2;
            if ( qi->SQLCODE == 0L && (psqlcode=strcasestr(msg[i],"SQL ERROR CODE = ")) ) {
               qi->SQLCODE = atol(psqlcode+17);
            }
//if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_error():error %d:[%s]\n",i,msg[i]);
            i++;
         }
         isc_sql_interprete(qi->SQLCODE, msg[i], 512);
         lenmsg+=strlen(msg[i])+4;
         qi->errmsg = (char *) malloc(lenmsg);
         if ( qi->errmsg != NULL ) {
            char *p = qi->errmsg;
            for(w=0;w<=i;w++) {
               strcpy(p,msg[w]);
               p+=strlen(msg[w]);
               strcpy(p,"\n");
               p+=strlen("\n");
            }
         } else {
            if ( FB_SHOW_MESSAGES ) fprintf(stderr,"fb_error():Error en asignacion de memoria para buffer de error\n");
         }
      } else {
         qi->SQLCODE = 0L;
         qi->errmsg = NULL;
      }
   }
   return ret;
}

/**
 * Imprime mensajes de error
 *
 * @param status_vector vector de estado API Firebird
 * @param msg mensaje a imprimir por stderr junto con el resto de mensajes de error recuperados 
 * de la API C
 * 
 * @author Guillermo Cherencio
 */
void fb_print_error(ISC_STATUS ISC_FAR *status_vector,const char *msg) {
   isc_print_status(status_vector);
   ISC_LONG SQLCODE = isc_sqlcode(status_vector);
   isc_print_sqlerror(SQLCODE, status_vector);
   if ( FB_SHOW_MESSAGES ) fprintf(stderr,msg,SQLCODE);
}

/**
 * void fb_init* Funciones de inicializacion de memoria
 *
 * @param qi puntero a area de memoria previamente asignada con info de query a ser inicializada
 * 
 * @author Guillermo Cherencio
 */
void fb_init_query_info(fb_query_info *qi) {
   memset(qi,0,sizeof(fb_query_info));
}

/**
 * void fb_end* Funciones de liberacion de memoria
// no libera dbinfo,tr1,stmt,in_sqlda,out_sqlda,sql (usa mem aut. en do_query)
 * @param qi puntero a area de memoria previamente asignada, de la cual liberara el miembro errmsg
 * 
 * @author Guillermo Cherencio
 */
void fb_end_query_info(fb_query_info *qi) {
   if (qi->errmsg != NULL) free(qi->errmsg);
}

/**
 * void fb_end* Funciones de liberacion de memoria
// no libera dbinfo,tr1,stmt,in_sqlda,out_sqlda,sql (usa mem aut. en do_query)
 * @param sqlda 
 * 
 * @author Guillermo Cherencio
 */
void fb_end_dsql_vars(XSQLDA *sqlda) {
   if ( sqlda == NULL ) return;
   int i;
   for(i=0;i<sqlda->sqld;i++) {
      if (sqlda->sqlvar[i].sqldata != NULL) {
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_end_dsql_vars(): free sqlvar %d type %d direccion %p\n",i,sqlda->sqlvar[i].sqltype,sqlda->sqlvar[i].sqldata);
         free(sqlda->sqlvar[i].sqldata);
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_end_dsql_vars(): end free sqlvar %d\n",i);
         sqlda->sqlvar[i].sqldata = NULL;
      }
   }
}

/**
 * Realiza fetch() sobre qi
 * devuelve true si pudo hacerlo, caso contrario devuelve false
 * el status retornado por fetch queda en qi->FETCHCODE
 * @param qi puntero a query actual sobre el cual se hara un fetch
 * 
 * @author Guillermo Cherencio
 */
int fb_fetch(fb_query_info *qi) {
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fetch 1\n");
   ISC_STATUS fetch_stat = isc_dsql_fetch(&qi->dbinfo->status_vector[0], qi->stmt, 1, qi->out_sqlda);
   int ret = (fetch_stat == 0);
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fetch 2\n");
   qi->FETCHCODE = fetch_stat;
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fetch 3\n");
   if ( ret ) {
      qi->rows_fetched++;
   } else if ( fetch_stat != 100L ) { 
      fb_error(qi->dbinfo,qi);
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fetch error:\n%s",qi->errmsg);
   }
//if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fetch 4 fetch_stat=%ld\n",fetch_stat);
   return ret;
}

/**
 * Funcion para demorar la tarea actual [nanosec] nanosegundos
 * @param nanosec nanosegundos a demorar proceso actual sin consumir cpu
 * 
 * @author Guillermo Cherencio
 */
void fb_sleep(int nanosec) {
   struct timespec rqt;
   struct timespec rmt;
   rqt.tv_sec = 0;
   rqt.tv_nsec = nanosec;
   nanosleep(&rqt,&rmt);
}

/**
 * Aplicacion de libreria libfb para dar soporte a queries genericos.
 * Funcion generica para el control de ejecucion de queries
 * @param eventType tipo de evento (asignado por funcion fb_do_query())
 * @param qi query actual
 * @param buffer area de memoria pasada como argumento a la funcion fb_do_query() por el programa
 * que llamo a dicha funcion
 * 
 * @author Guillermo Cherencio
 */
int onDoGenericQuery(int eventType,fb_query_info *qi,void *buffer) {
   int ret;
   struct query *q = (struct query *) buffer;
   switch(eventType) {
      case FB_MEMORY_QUERY_ERROR:
         ret=FB_ABORT_ALL;
         q->fb_error = 1;
         q->errmsg = strdup("Error Asignando Memoria (FB_QUERY_ERROR)");
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Memory Error! (query id=%d)\n",qi->queryId);
         break;
      case FB_EXECUTE_QUERY_OK:
         ret=FB_CONTINUE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Execute Ok (query id=%d)\n",qi->queryId);
         break;
      case FB_EXECUTE_QUERY_ERROR:
         ret=FB_ABORT;
         q->fb_error = 1;
         q->errmsg = strdup(qi->errmsg);
         q->SQLCODE = qi->SQLCODE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Error %ld ejecutando (query id=%d)\n%s",qi->SQLCODE,qi->queryId,qi->errmsg);
         break;
      case FB_FETCH_RECORDS:
//         {
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Comienzo Fetch #%d (query id=%d)\n",qi->set_time,qi->queryId);
/*
         q->cols = qi->out_sqlda->sqld;
         char *cn[q->cols]; // nombre de las columnas del query
         char *cc[q->cols]; // contenido de las columnas
         memset(cn,0,q->cols*sizeof(char *));
         memset(cc,0,q->cols*sizeof(char *));
         q->top = (struct rquery *) malloc(sizeof(struct rquery));
         if ( q->top == NULL ) {ret=FB_ABORT;if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Error de mem.(1)fetching records query id=%d\n",qi->queryId);break;}
         memset(q->top,0,sizeof(struct rquery));
         int f=0,c;
         // cargo los nombres de las columnas del query
         q->colname = calloc(q->cols,sizeof(char *));
         if ( q->colname == NULL )  {ret=FB_ABORT;if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Error de mem.(3)fetching records query id=%d\n",qi->queryId);break;}
         for(c=0;c < q->cols;c++) {
            cn[c] = (char *) malloc(qi->out_sqlda->sqlvar[c].sqlname_length+1);
            if ( cn[c] == NULL ) {ret=FB_ABORT;if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Error de mem.(4)fetching records query id=%d\n",qi->queryId);break;}
            memset(cn[c],0,qi->out_sqlda->sqlvar[c].sqlname_length+1);
            strncpy(cn[c],qi->out_sqlda->sqlvar[c].sqlname,qi->out_sqlda->sqlvar[c].sqlname_length);
if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery():largo cmp %d=%d nombre=[%s] [%s]\n",c,qi->out_sqlda->sqlvar[c].sqlname_length+1,qi->out_sqlda->sqlvar[c].sqlname,cn[c]);
         }
         memcpy(q->colname,cn,q->cols*sizeof(char *));
         // fin cargo nombres de las columnas del query
         struct rquery *qq = q->top;
         struct rquery *pp;
         while(fb_fetch(qi)) {
            qq->col = calloc(q->cols,sizeof(char *));
            if ( qq->col == NULL ) {ret=FB_ABORT;if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Error de mem.(2)fetching records query id=%d\n",qi->queryId);break;}
            for(c=0;c < q->cols;c++) cc[c] = fb_getcol(qi,c);
            memcpy(qq->col,cc,q->cols*sizeof(char *));
            qq->next = (struct rquery *) malloc(sizeof(struct rquery));
            pp = qq;
            qq = qq->next;
            qq->next = NULL;
            qq->prev = pp;
            f++;
         }
         q->fb_error = qi->fb_error;
         if ( qi->errmsg != NULL ) q->errmsg = strdup(qi->errmsg);
         else q->errmsg = NULL;
         q->SQLCODE = qi->SQLCODE;
         q->FETCHCODE = qi->FETCHCODE;
         q->rows_updated = qi->rows_updated;
         q->rows_inserted = qi->rows_inserted;
         q->rows_deleted = qi->rows_deleted;
         q->rows_selected = qi->rows_selected;
         q->rows_fetched = qi->rows_fetched; // count rows fetched for each query execution
         if ( qq->next == NULL && qq->prev != NULL ) { qq->prev->next = NULL;pp=qq->prev;free(qq);qq=pp; }
         q->rows = f;
         q->bottom = qq;
*/
		 if ( fb_load_query(q,qi) ) ret=FB_CONTINUE;
		 else                       ret=FB_ABORT;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Termine fectch #%d (query id=%d)\n",qi->set_time,qi->queryId);
//         ret=FB_CONTINUE;
         //}
         break;
      case FB_SET_QUERY_OUTPUT:
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): SetQueryOutput time #%d  (query id=%d)\n",qi->set_time,qi->queryId);
         ret=FB_CONTINUE;
         break;
      case FB_SET_QUERY_INPUT:
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): SetQueryInput time #%d (query id=%d)\n",qi->set_time,qi->queryId);
         ret=FB_CONTINUE;
         break;
      default:
         q->fb_error = qi->fb_error;
         q->errmsg = strdup(qi->errmsg);
         q->SQLCODE = qi->SQLCODE;
         q->FETCHCODE = qi->FETCHCODE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoGenericQuery(): Error evento %d no implementado (query id=%d)\n",eventType,qi->queryId);
         break;
   }
   return ret;
}

/**
 * Funcion que carga los resultados obtenidos por un query
 * Se la utiliza como una forma standard de cargar los resultados de la ejecucion
 * de un query. Por lo general, es llamada desde la funcion de callback (de manejo de
 * queries) para procesar el evento FB_FETCH_RECORDS
 * @param q estructura query en donde cargar el resultado de un query que devuelve tuplas
 * @param qi estructura fb_query_info pasada a la funcion de callback y requerida por esta 
 * funcion para poder cargar los resultados obtenidos de la ejecucion del query
 * @return 0 si hubo error, 1 si todo Ok
 * @author Guillermo Cherencio
 */
int fb_load_query(query *q,fb_query_info *qi) {
	 q->cols = qi->out_sqlda->sqld;
	 char *cn[q->cols]; // nombre de las columnas del query
	 char *cc[q->cols]; // contenido de las columnas
	 memset(cn,0,q->cols*sizeof(char *));
	 memset(cc,0,q->cols*sizeof(char *));
	 q->top = (struct rquery *) malloc(sizeof(struct rquery));
	 if ( q->top == NULL ) {
		 if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_load_query(): Error de mem.(1)fetching records query id=%d\n",qi->queryId);
		 return 0;
	 }
	 memset(q->top,0,sizeof(struct rquery));
	 int f=0,c;
	 // cargo los nombres de las columnas del query
	 q->colname = calloc(q->cols,sizeof(char *));
	 if ( q->colname == NULL )  {
		 if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_load_query(): Error de mem.(2)fetching records query id=%d\n",qi->queryId);
		 return 0;
	 }
	 for(c=0;c < q->cols;c++) {
		cn[c] = (char *) malloc(qi->out_sqlda->sqlvar[c].sqlname_length+1);
		if ( cn[c] == NULL ) {
			if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_load_query(): Error de mem.(3)fetching records query id=%d\n",qi->queryId);
			return 0;
		}
		memset(cn[c],0,qi->out_sqlda->sqlvar[c].sqlname_length+1);
		strncpy(cn[c],qi->out_sqlda->sqlvar[c].sqlname,qi->out_sqlda->sqlvar[c].sqlname_length);
	 }
	 memcpy(q->colname,cn,q->cols*sizeof(char *));
	 // fin cargo nombres de las columnas del query
	 // cargo tuplas del query
	 struct rquery *qq = q->top;
	 struct rquery *pp;
//printf("fb_load_query(): inicio fetch!\n");			 
	 while(fb_fetch(qi)) {
		qq->col = calloc(q->cols,sizeof(char *));
		if ( qq->col == NULL ) {
			if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_load_query(): Error de mem.(4)fetching records query id=%d\n",qi->queryId);
			return 0;
		}
		for(c=0;c < q->cols;c++) cc[c] = fb_getcol(qi,c);
		memcpy(qq->col,cc,q->cols*sizeof(char *));
		qq->next = (struct rquery *) malloc(sizeof(struct rquery));
		pp = qq;
		qq = qq->next;
		qq->next = NULL;
		qq->prev = pp;
		f++;
//printf("fb_load_query(): fila %d\n",f);		
	 }
	 // fin cargo tuplas del query
	 q->fb_error = qi->fb_error;
	 if ( qi->errmsg != NULL ) q->errmsg = strdup(qi->errmsg);
	 else q->errmsg = NULL;
	 q->SQLCODE = qi->SQLCODE;
	 q->FETCHCODE = qi->FETCHCODE;
	 q->rows_updated = qi->rows_updated;
	 q->rows_inserted = qi->rows_inserted;
	 q->rows_deleted = qi->rows_deleted;
	 q->rows_selected = qi->rows_selected;
	 q->rows_fetched = qi->rows_fetched; // count rows fetched for each query execution
	 if ( qq->next == NULL && qq->prev != NULL ) { 
		 qq->prev->next = NULL;
		 pp=qq->prev;
		 free(qq);
		 qq=pp;
	 }
	 q->rows = f;
	 q->bottom = qq;
	 return 1;
}

/**
 * Inicializo estructura query (lo contrario de fb_free())
 * @param q query a inicializar
 * 
 * @author Guillermo Cherencio
 */
void fb_init(query *q) {
   if ( q != NULL ) memset(q,0,sizeof(struct query));
}

/**
 * Libero toda la memoria ocupada por el resultado del query q
 * @param q query a liberar
 * 
 * @author Guillermo Cherencio
 */
void fb_free(query *q) {
      struct rquery *qq = q->top;
      struct rquery *pp;
      int c;
      //int cnt=0;
      char *cc[q->cols];
      if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_free():init\n");
      while(qq != NULL) {
         if ( qq->col != NULL ) {
            memcpy(cc,qq->col,q->cols*sizeof(char *));
            for(c=0;c<q->cols;c++) {
               if ( cc[c] != NULL ) free(cc[c]);
            }
         }
         pp = qq->next;
         free(qq);
         qq = pp;
      }
      if ( q->errmsg != NULL ) free(q->errmsg);
      q->fb_error = 0; // flag, true->error, false->no error
      if ( q->colname != NULL ) {
         char *cn[q->cols];
         memcpy(cn,q->colname,q->cols*sizeof(char *));
         for(c=0;c<q->cols;c++) {
            if ( cn[c] != NULL ) free(cn[c]);
         }
         free(q->colname);
      }
      q->colname = NULL;
      q->SQLCODE = 0; // if fb_error then sqlcode has the sql error code
      q->FETCHCODE = 0; // last fetch status
      q->errmsg = NULL; // buffer con mensajes de error
      q->rows_updated = 0;
      q->rows_inserted = 0;
      q->rows_deleted = 0;
      q->rows_selected = 0;
      q->rows_fetched = 0; // count rows fetched for each query execution
      if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"fb_free():finit\n");
}

/**
 * Imprime (en el stream indicado) el resultado del query
 * @param f stream sobre el cual se realizara la impresion del query
 * @param q query actual
 * 
 * @author Guillermo Cherencio
 */
void fb_fprintf(FILE *f,query *q) {
      struct rquery *qq = q->top;
      struct rquery *pp;
      int c;
      char *cc[q->cols];
      if ( FB_SHOW_MESSAGES ) fprintf(f,"fb_fprintf():init imprimo query filas=%d columnas=%d\n",q->rows,q->cols);
      while(qq != NULL) {
         if ( qq->col != NULL ) {
            memcpy(cc,qq->col,q->cols*sizeof(char *));
            for(c=0;c<q->cols;c++) {
               if ( FB_SHOW_MESSAGES ) fprintf(f,"[%s]",cc[c]);
            }
            if ( FB_SHOW_MESSAGES ) printf("\n");
         }
         pp = qq->next;
         qq = pp;
      }
      if ( FB_SHOW_MESSAGES ) fprintf(f,"fb_fprintf():finit\n");
}

/**
 * Obtengo determinada fila y coluna de un query previamente ejecutado
 * @param q query actual
 * @param row fila a obtener
 * @param col columna a obtener
 * @return valor asociado a una fila y columna del query actual
 * 
 * @author Guillermo Cherencio
 */
char *fb_get_rowcol(query *q,int row,int col) {
   struct rquery *qq = q->top;
   int r=0;
   if ( !(col >= 0 && col < q->cols) ) return NULL;
   char *cc[q->cols];
   while(qq != NULL && r < row) {
      r++;
      qq = qq->next;
   }
   if ( r == row ) {
      if ( qq->col != NULL  ) {
         memcpy(cc,qq->col,q->cols*sizeof(char *));
         return cc[col];
      }
   }
   return NULL;
}

/**
 * Obtengo la columna col de la fila indicada por rq asociada con el query q
 * @param q query actual
 * @param rq puntero a fila de query almacenado en memoria como lista doblemente enlazada
 * @param col columna a obtener
 * @return valor asociado a la columna col de la fila guardada en rq
 * 
 * @author Guillermo Cherencio
 */
char *fb_get_col(query *q,rquery *rq,int col) {
   if ( !(col >= 0 && col < q->cols) ) return NULL;
   char *cc[q->cols];
   if ( rq->col != NULL  ) {
      memcpy(cc,rq->col,q->cols*sizeof(char *));
      return cc[col];
   }
   return NULL;
}

/**
 * Obtengo la columna colname de la fila indicada por rq asociada con el query q
 * @param q query actual
 * @param rq puntero a fila de query almacenado en memoria como lista doblemente enlazada
 * @param colname nombre de columna a obtener
 * @return valor asociado a la columna col de la fila guardada en rq, si no existe colname,
 * devuelve NULL
 * 
 * @author Guillermo Cherencio
 */
char *fb_get_col_byname(query *q,rquery *rq,char *colname) {
   int c;
   if ( q->colname != NULL  ) {
      for(c=0;c<q->cols;c++) {
         if ( strcasecmp(fb_get_col_name(q,c),colname) == 0 ) return fb_get_col(q,rq,c);
      }
   }
   return NULL;
}

/**
 * Obtengo el largo (strlen()) del string correspondiente a esta columna en esta fila.
 * Retorna -1 si no puede calcular el largo
 * @param q query actual
 * @param rq puntero a fila de query almacenado en memoria como lista doblemente enlazada
 * @param col columna a obtener
 * @return -1 si no pudo calcular largo, sino devuelve el largo de la columna col en la fila rq
 * 
 * @author Guillermo Cherencio
 */
int fb_get_col_len(query *q,rquery *rq,int col) {
   if ( !(col >= 0 && col < q->cols) ) return -1;
   char *cc[q->cols];
   if ( rq->col != NULL  ) {
      memcpy(cc,rq->col,q->cols*sizeof(char *));
      return strlen(cc[col]);
   }
   return -1;
}

/**
 * Similar a fb_get_col_len() pero en este caso hace la sumatoria del largo 
 * de todas las columnas de la fila actual
 * retorna -1 si -al menos- en una columna no pudo calcular el largo
 * @param q query actual
 * @param rq puntero a fila de query almacenado en memoria como lista doblemente enlazada
 * @return retorna -1 si -al menos- en una columna no pudo calcular el largo
 * 
 * @author Guillermo Cherencio
 */
int fb_row_len(query *q,rquery *rq) {
   int largo=0,cl=0,c;
   if ( rq->col != NULL  ) {
      for(c=0;c<q->cols;c++) {
         if ( (cl=fb_get_col_len(q,rq,c)) == -1 ) return -1;
         largo+=cl;
      }
      return largo;
   }
   return -1;
}

/**
 * Obtengo nombre de la columna indicada
 * retorna NULL si no puede obtener el nombre o col es incorrecto
 * @param q query actual
 * @param col numero de columna
 * @return retorna NULL si no puede obtener el nombre o col es incorrecto
 * 
 * @author Guillermo Cherencio
 */
char *fb_get_col_name(query *q,int col) {
   if ( !(col >= 0 && col < q->cols) ) return NULL;
   char *cn[q->cols];
   if ( q->colname != NULL  ) {
      memcpy(cn,q->colname,q->cols*sizeof(char *));
      return cn[col];
   }
   return NULL;
}

/**
 * Obtengo el largo total de todos los nombres de campo del query actual
 * retorna NULL si no puede obtener el nombre -de al menos- un campo
 * @param q query actual
 * @return retorna NULL si no puede obtener el nombre -de al menos- un campo
 * 
 * @author Guillermo Cherencio
 */
int fb_get_col_len_name(query *q) {
   int largo=0,c;
   char *campo;
   if ( q->colname != NULL  ) {
      for(c=0;c<q->cols;c++) {
         if ( (campo=fb_get_col_name(q,c)) == NULL ) return -1;
         largo+=strlen(campo);
      }
      return largo;
   }
   return -1;
}

void fb_set_stream_msg(int file_descriptor,char *mode) {
	FB_STREAM_MESSAGES = fdopen(file_descriptor,mode);
}

void fb_stream_msg_close() {
	fclose(FB_STREAM_MESSAGES);
	FB_STREAM_MESSAGES = NULL;
}

int  fb_sizeof_query()         { return sizeof(query);         }
int  fb_sizeof_rquery()        { return sizeof(rquery);        }
int  fb_sizeof_fb_blob_info()  { return sizeof(fb_blob_info);  }
int  fb_sizeof_fb_query_info() { return sizeof(fb_query_info); }
int  fb_sizeof_fb_db_info()    { return sizeof(fb_db_info);    }

// get query data members
rquery    *fb_get_query_top(query *q)       { return q->top;       }
rquery    *fb_get_query_bottom(query *q)    { return q->bottom;    }
int        fb_get_query_fberror(query *q)   { return q->fb_error;  }
char      *fb_get_query_errmsg(query *q)    { return q->errmsg;    }
int        fb_get_query_rows(query *q)      { return q->rows;      }
int        fb_get_query_cols(query *q)      { return q->cols;      }
long       fb_get_query_sqlcode(query *q)   { return q->SQLCODE;   }
ISC_STATUS fb_get_query_fetchcode(query *q) { return q->FETCHCODE; }

	
rquery *fb_rquery_next(rquery *r)     { return r->next;     }
rquery *fb_rquery_previous(rquery *r) { return r->prev;     }

void fb_pre_connect(fb_db_info *dbinfo,char *dbname,char *user,char *passwd,char *role) {
	strcpy(dbinfo->user,user);
	strcpy(dbinfo->passw,passwd);
	strcpy(dbinfo->dbname,dbname);
	strcpy(dbinfo->role,role);
}


void fb_set_query_fberror(query *q,int fberr)               { q->fb_error = fberr;          }
void fb_set_query_errmsg(query *q,char *errmsg)             { q->errmsg   = strdup(errmsg); }
void fb_set_query_sqlcode(query *q,long sqlcode)            { q->SQLCODE  = sqlcode;        }
void fb_set_query_fetchcode(query *q,ISC_STATUS fetchcode)  { q->FETCHCODE= fetchcode;      }


void fb_log_message(char *errmsg) { if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,errmsg); }


int fb_get_fb_query_info_fberror(fb_query_info *q)           { return q->fb_error;          }
char *fb_get_fb_query_info_errmsg(fb_query_info *q)          { return q->errmsg;            }
int fb_get_fb_query_info_queryId(fb_query_info *q)           { return q->queryId;           }
int fb_get_fb_query_info_settime(fb_query_info *q)           { return q->set_time;          }
char *fb_get_fb_query_info_sql(fb_query_info *q)             { return q->sql;               }
long fb_get_fb_query_info_sqlcode(fb_query_info *q)          { return q->SQLCODE;           }
ISC_STATUS fb_get_fb_query_info_fetchcode(fb_query_info *q)  { return q->FETCHCODE;         }


void fb_set_fb_query_info_fberror(fb_query_info *q,int fberror)            { q->fb_error  = fberror;          }
void fb_set_fb_query_info_errmsg(fb_query_info *q,char *errmsg)            { q->errmsg    = strdup(errmsg);   }
void fb_set_fb_query_info_sqlcode(fb_query_info *q,long sqlcode)           { q->SQLCODE   = sqlcode;          }
void fb_set_fb_query_info_fetchcode(fb_query_info *q,ISC_STATUS fetchcode) { q->FETCHCODE = fetchcode;        }



