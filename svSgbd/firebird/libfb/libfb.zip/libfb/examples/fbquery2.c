/**
 * Programa de ejemplo de uso de libreria libfb
 * Se conecta a la base de datos /var/lib/firebird/2.5/data/isft.fdb
 * del servidor local de firebird, realiza la ejecucion de un store
 * procedure (ignora su retorno) y se desconecta
 * 
 * @author Guillermo Cherencio
 */

#include <libfb.h>
#include <string.h>

extern int FB_SHOW_MESSAGES;         // suprimo los mensajes de libreria FB

int main(int argc, char **argv) {
	FB_SHOW_MESSAGES = 0;            // desactivo mensajes de libreria libfb
	fb_db_info dbinfo;
	strcpy(dbinfo.user,"sysdba");
	strcpy(dbinfo.passw,"masterkey");
	strcpy(dbinfo.dbname,"localhost:/var/lib/firebird/2.5/data/isft.fdb");
	strcpy(dbinfo.role,"sysdb");
	if (fb_do_connect(&dbinfo)) {  // me conecte!
		printf("Me conecte!\n");
		printf("Ejecuto Query que no retorna tuplas!\n");
		char *squery = "EXECUTE PROCEDURE P_ABM_TBL_PLANE('B',6,'12345',\
		          40,500,'Tecnicatura Prueba','Tecnico de Prueba',3)";
		query myquery;
		fb_init(&myquery); // atencion! myquery debe estar inicializado
		if ( fb_do_query(&dbinfo,1,squery,onDoGenericQuery,&myquery) ) {
			printf("query [%s] ejecutado Ok!\n",squery);
			printf("Libero memoria de Query!\n");
			fb_free(&myquery);
		} else {
			printf("query [%s] ejecutado con error!\n",squery);
			printf("Error FB [%d] mensaje [%s] sql code [%ld]\n",myquery.fb_error,myquery.errmsg,myquery.SQLCODE);
		}
		fb_do_disconnect(&dbinfo);
		printf("Me desconecte!\n");
	}
	return 0;
}

