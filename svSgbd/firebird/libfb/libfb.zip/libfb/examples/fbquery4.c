/**
 * Programa de ejemplo de uso de libreria libfb
 * Se conecta a la base de datos /var/lib/firebird/2.5/data/isft.fdb
 * del servidor local de firebird, realiza un query parametrizado, carga los
 * valores de los parametros y muestra su resultado
 * y se desconecta
 * 
 * @author Guillermo Cherencio
 */

#include <libfb.h>
#include <string.h>

extern int FB_SHOW_MESSAGES;         // suprimo los mensajes de libreria FB
extern FILE *FB_STREAM_MESSAGES;     // stream por defecto en donde enviar mensajes libreria libfb

// funcion de callback para ejecucion de query
int onDoMyQuery(int eventType,fb_query_info *qi,void *buffer);

int main(int argc, char **argv) {
	FB_SHOW_MESSAGES = 1;  // activo mensajes de libreria libfb
	fb_db_info dbinfo;
	strcpy(dbinfo.user,"sysdba");
	strcpy(dbinfo.passw,"masterkey");
	strcpy(dbinfo.dbname,"localhost:/var/lib/firebird/2.5/data/isft.fdb");
	strcpy(dbinfo.role,"sysdb");
	if (fb_do_connect(&dbinfo)) {  // me conecte!
		printf("Me conecte!\n");
		query myquery;
		fb_init(&myquery); // atencion! myquery debe estar inicializado
		printf("Ejecuto Query parametrizado!\n");
		char *squery = "SELECT * FROM SP_TBL_PLANE WHERE TITULO > ?";
		if ( fb_do_query(&dbinfo,1,squery,onDoMyQuery,&myquery) ) {
			// query ok
			printf("Recupero %d filas de datos de Query!\n",myquery.rows);
			if ( myquery.rows ) { // si hay tuplas
				rquery *q = myquery.top; // apunto a primer tupla del query
				while (q) {
					char **cols;
					int ncol;
					// q->col arreglo de apuntadores a char *
					// imprimo columnas de esta tupla
					for(cols = (char **) q->col,ncol=0;ncol < myquery.cols;ncol++,cols++) {
						printf("[%s]",*cols);
					}
					printf("\n");
					// apunto a siguiente tupla del query
					q = q->next;  
				}
			}
			printf("Libero memoria de Query!\n");
			fb_free(&myquery);
		} else { // error en ejecucion de query
			printf("Error en ejecucion de Query Parametrizado!\n\
			    Error FB [%d] mensaje [%s] sql code [%ld]\n",myquery.fb_error,myquery.errmsg,myquery.SQLCODE);
		}
		fb_do_disconnect(&dbinfo);
		printf("Me desconecte!\n");
	}
	return 0;
}

/**
 * Aplicacion de libreria libfb para dar soporte a query SELECT ...WHERE ... ? que 
 * devuelve 6 parametros de salida (ver codigo select procedure SP_TBL_PLANE en isft.fdb)
 * 
 * @param eventType tipo de evento (asignado por funcion fb_do_query())
 * @param qi query actual
 * @param buffer area de memoria pasada como argumento a la funcion fb_do_query() por el programa
 * que llamo a esta funcion
 * 
 * @author Guillermo Cherencio
 */
int onDoMyQuery(int eventType,fb_query_info *qi,void *buffer) {
   int ret;
   struct query *q = (struct query *) buffer;
   switch(eventType) {
      case FB_MEMORY_QUERY_ERROR:
         ret=FB_ABORT_ALL;
         q->fb_error = 1;
         q->errmsg = strdup("Error Asignando Memoria (FB_QUERY_ERROR)");
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Memory Error! (query id=%d)\n",qi->queryId);
         break;
      case FB_EXECUTE_QUERY_OK:
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Ejecute Query OK! (query id=%d)\n",qi->queryId);
         ret=FB_CONTINUE;
         break;
      case FB_EXECUTE_QUERY_ERROR:
         ret=FB_ABORT;
         q->fb_error = 1;
         q->errmsg = strdup(qi->errmsg);
         q->SQLCODE = qi->SQLCODE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Error %ld ejecutando (query id=%d)\n%s",qi->SQLCODE,qi->queryId,qi->errmsg);
         break;
      case FB_FETCH_RECORDS:
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Recupero Tuplas! (query id=%d)\n",qi->queryId);
         // copia tuplas a partir de q->top
		 if ( fb_load_query(q,qi) ) ret=FB_CONTINUE;
		 else                       ret=FB_ABORT;
		 if ( ret == FB_ABORT ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Error en Recupero Tuplas! (query id=%d)\n",qi->queryId);
         break;
      case FB_SET_QUERY_OUTPUT:
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): SetQueryOutput time #%d  (query id=%d)\n",qi->set_time,qi->queryId);
         ret=FB_CONTINUE;
         break;
      case FB_SET_QUERY_INPUT:
		 // ejecuto para CODIGO = 1
		 //fb_set_intpar(qi,0,1); // asigno parametro de entrada para clausula WHERE ...
		 fb_set_strpar(qi,0,"Guia");
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): SetQueryInput time #%d (query id=%d)\n",qi->set_time,qi->queryId);
         ret=FB_CONTINUE;
         break;
      default:
		 ret=FB_ABORT_ALL;
         q->fb_error = qi->fb_error;
         q->errmsg = strdup(qi->errmsg);
         q->SQLCODE = qi->SQLCODE;
         q->FETCHCODE = qi->FETCHCODE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Error evento %d no implementado (query id=%d)\n",eventType,qi->queryId);
         break;
   }
   return ret;
}
