/**
 * Programa de ejemplo de uso de libreria libfb
 * Se conecta a la base de datos /var/lib/firebird/2.5/data/isft.fdb
 * del servidor local de firebird, realiza un query, muestra su resultado
 * y se desconecta
 * 
 * @warning ATENCION!! EJEMPLO AUN NO UTILIZABLE, EN CONSTRUCCION
 * 
 * @author Guillermo Cherencio
 */

#include <libfb.h>
#include <string.h>

extern int FB_SHOW_MESSAGES;         // suprimo los mensajes de libreria FB
extern FILE *FB_STREAM_MESSAGES;     // stream por defecto en donde enviar mensajes libreria libfb

// funcion de callback para ejecucion de query
int onDoMyQuery(int eventType,fb_query_info *qi,void *buffer);

int main(int argc, char **argv) {
	FB_SHOW_MESSAGES = 1;  // activo mensajes de libreria libfb
	fb_db_info dbinfo;
	strcpy(dbinfo.user,"sysdba");
	strcpy(dbinfo.passw,"masterkey");
	strcpy(dbinfo.dbname,"localhost:/var/lib/firebird/2.5/data/isft.fdb");
	strcpy(dbinfo.role,"sysdb");
	if (fb_do_connect(&dbinfo)) {  // me conecte!
		printf("Me conecte!\n");
		query myquery;
		fb_init(&myquery); // atencion! myquery debe estar inicializado
		printf("Ejecuto Store Procedure!\n");
		char *squery = "EXECUTE PROCEDURE P_ABM_TBL_PLANE('B',7,'67890',\
		          40,500,'Tecnicatura Prueba2','Tecnico de Prueba2',3)";
		if ( fb_do_exec_query(&dbinfo,squery,0,2,onDoMyQuery,&myquery) ) {
			// query ok
			printf("Libero memoria de Query!\n");
			fb_free(&myquery);
		} else { // error en ejecucion de query
			printf("Error en ejecucion de Store Procedure!\n\
			    Error FB [%d] mensaje [%s] sql code [%ld]\n",myquery.fb_error,myquery.errmsg,myquery.SQLCODE);
		}
		fb_do_disconnect(&dbinfo);
		printf("Me desconecte!\n");
	}
	return 0;
}

/**
 * Aplicacion de libreria libfb para dar soporte a query EXECUTE PROCEDURE ... que 
 * devuelve 2 parametros de salida (el primer parametro es integer y el segundo varchar(50))
 * Ver codigo de procedimiento P_ABM_TBL_PLANE en isft.fdb
 * 
 * @param eventType tipo de evento (asignado por funcion fb_do_query())
 * @param qi query actual
 * @param buffer area de memoria pasada como argumento a la funcion fb_do_query() por el programa
 * que llamo a esta funcion
 * 
 * @author Guillermo Cherencio
 */
int onDoMyQuery(int eventType,fb_query_info *qi,void *buffer) {
   int ret;
   struct query *q = (struct query *) buffer;
   int p_ret;      // primer  parametro output del procedimiento
   char *p_dret;   // segundo parametro output del procedimiento
   switch(eventType) {
      case FB_MEMORY_QUERY_ERROR:
         ret=FB_ABORT_ALL;
         q->fb_error = 1;
         q->errmsg = strdup("Error Asignando Memoria (FB_QUERY_ERROR)");
         q->SQLCODE = qi->SQLCODE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Memory Error!\n");
         break;
      case FB_START_QUERY_ERROR:
         ret=FB_ABORT_ALL;
         q->fb_error = 1;
         q->errmsg = strdup("Error Inciando transaccion (FB_START_QUERY_ERROR)");
         q->SQLCODE = qi->SQLCODE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Error Inciando Transaccion!\n");
		 break;
      case FB_EXECUTE_QUERY_OK:
         printf("onDoMyQuery(): Ejecuto Procedimiento Ok!\n");
         printf("onDoMyQuery(): Obtengo parametros de salida\n");
         p_ret = fb_get_intpar(qi,0);
         printf("obtengo parametro de salida 2\n");
         p_dret = fb_get_strpar(qi,1);
         printf("onDoMyQuery(): Procedure return: [%d] [%s]\n",p_ret,p_dret);
         // libero memoria de parametro de output
         if ( p_dret != NULL ) free(p_dret);
         ret=FB_CONTINUE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Execute Ok\n");
         break;
      case FB_EXECUTE_QUERY_ERROR:
         ret=FB_ABORT;
         q->fb_error = 1;
         q->errmsg = strdup(qi->errmsg);
         q->SQLCODE = qi->SQLCODE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Error %ld ejecutando [%s]\n%s\n",qi->SQLCODE,qi->sql,qi->errmsg);
         break;
      case FB_FETCH_RECORDS:
         ret=FB_CONTINUE;  // no hago nada, continuo
         break;
      case FB_SET_QUERY_OUTPUT:
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): SetQueryOutput\n");
         ret=FB_CONTINUE;
         break;
      case FB_SET_QUERY_INPUT:
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): SetQueryInput\n");
         ret=FB_CONTINUE; // no hago nada, no tengo parametros de entrada
         break;
      default:
		 ret=FB_ABORT_ALL;
         q->fb_error = qi->fb_error;
         q->errmsg = strdup(qi->errmsg);
         q->SQLCODE = qi->SQLCODE;
         q->FETCHCODE = qi->FETCHCODE;
         if ( FB_SHOW_MESSAGES ) fprintf(FB_STREAM_MESSAGES,"onDoMyQuery(): Error evento %d no implementado\n",eventType);
         break;
   }
   return ret;
}
