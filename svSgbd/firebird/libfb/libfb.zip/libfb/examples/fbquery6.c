/**
 * Programa de ejemplo de uso de libreria libfb
 * Se conecta a la base de datos /var/lib/firebird/2.5/data/isft.fdb
 * del servidor local de firebird, realiza un query, muestra su resultado
 * y se desconecta
 * 
 * @author Guillermo Cherencio
 */

#include <libfb.h>
#include <string.h>

extern int FB_SHOW_MESSAGES;         // suprimo los mensajes de libreria FB

int main(int argc, char **argv) {
	FB_SHOW_MESSAGES = 0;            // desactivo mensajes de libreria libfb
	char *sql = "TBL_PLANE";
	query *myquery;
	// me conecte, ejecute query, me desconecte!
	if ((myquery=fb_do_connect_squery("localhost:/var/lib/firebird/2.5/data/isft.fdb",
									"sysdba","masterkey","sysdb",sql)) != NULL) {
		printf("Me conecte! ejecute query! me desconecte!\n");
		printf("Recupero datos de Query!\n");
		rquery *q;
		for(q = myquery->top;q;q=q->next)
			printf("[%s][%s]\n",fb_get_col(myquery,q,0),fb_get_col(myquery,q,1));
		printf("Libero memoria de Query!\n");
		fb_free(myquery);
	} else { // error en ejecucion de query/conexion
		printf("Error en ejecucion de query [%s]!\n",sql);
	}
	return 0;
}
