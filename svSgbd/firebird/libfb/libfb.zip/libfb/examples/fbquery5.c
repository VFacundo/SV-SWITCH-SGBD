/**
 * Programa de ejemplo de uso de libreria libfb
 * Se conecta a la base de datos /var/lib/firebird/2.5/data/isft.fdb
 * del servidor local de firebird, realiza un query, muestra su resultado
 * y se desconecta
 * 
 * @author Guillermo Cherencio
 */

#include <libfb.h>
#include <string.h>

extern int FB_SHOW_MESSAGES;         // suprimo los mensajes de libreria FB

int main(int argc, char **argv) {
	FB_SHOW_MESSAGES = 0;            // desactivo mensajes de libreria libfb
	fb_db_info dbinfo;
	strcpy(dbinfo.user,"sysdba");
	strcpy(dbinfo.passw,"masterkey");
	strcpy(dbinfo.dbname,"localhost:/var/lib/firebird/2.5/data/isft.fdb");
	strcpy(dbinfo.role,"sysdb");
	if (fb_do_connect(&dbinfo)) {  // me conecte!
		printf("Me conecte!\n");
		query *myquery;
		printf("Ejecuto Query!\n");
		char *sql = "TBL_PLANE";
		if ( (myquery=fb_do_single_query(&dbinfo,sql)) != NULL ) {
			printf("Recupero datos de Query!\n");
			rquery *q;
			for(q = myquery->top;q;q=q->next)
				printf("[%s][%s]\n",fb_get_col(myquery,q,0),fb_get_col(myquery,q,1));
			printf("Libero memoria de Query!\n");
			fb_free(myquery);
		} else { // error en ejecucion de query
			printf("Error en ejecucion de [%s]!\n",sql);
		}
		fb_do_disconnect(&dbinfo);
		printf("Me desconecte!\n");
	}
	return 0;
}
