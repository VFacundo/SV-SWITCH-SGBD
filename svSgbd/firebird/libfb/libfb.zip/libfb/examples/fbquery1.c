/**
 * Programa de ejemplo de uso de libreria libfb
 * Se conecta a la base de datos /var/lib/firebird/2.5/data/isft.fdb
 * del servidor local de firebird, realiza un query, muestra su resultado
 * y se desconecta
 * 
 * @author Guillermo Cherencio
 */

#include <libfb.h>
#include <string.h>

extern int FB_SHOW_MESSAGES;         // 1 activa/ 0 desactiva los mensajes de libreria FB

int main(int argc, char **argv) {
	FB_SHOW_MESSAGES = 1;            // desactivo mensajes de libreria libfb
	fb_db_info dbinfo;
	strcpy(dbinfo.user,"sysdba");
	strcpy(dbinfo.passw,"masterkey");
	strcpy(dbinfo.dbname,"localhost:/var/lib/firebird/2.5/data/isft.fdb");
	strcpy(dbinfo.role,"sysdb");
	if (fb_do_connect(&dbinfo)) {  // me conecte!
		printf("Me conecte!\n");
		query myquery;
		fb_init(&myquery); // atencion! myquery debe estar inicializado
		printf("Ejecuto Query!\n");
		if ( fb_do_query(&dbinfo,1,"SELECT CODIGO, DESCR FROM TBL_PLANE ORDER BY DESCR ASC", 
			onDoGenericQuery,&myquery) ) {
			printf("Recupero datos de Query!\n");
			rquery *q = myquery.top; // primer tupla del query
			char **cols;
			while (q) {
				cols = (char **) q->col;  // q->col arreglo de apuntadores a char *
				printf("[%s][%s]\n",*cols,*(cols+1));
				q = q->next;  // siguiente tupla del query
			}
			printf("Libero memoria de Query!\n");
			fb_free(&myquery);
		} else { // error en ejecucion de query
			printf("Error en ejecucion de Store Procedure!\n\
			    Error FB [%d] mensaje [%s] sql code [%ld]\n",myquery.fb_error,myquery.errmsg,myquery.SQLCODE);
		}
		fb_do_disconnect(&dbinfo);
		printf("Me desconecte!\n");
	}
	return 0;
}

