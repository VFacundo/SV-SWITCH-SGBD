/*
 * cgi2.c
 * 
 * Copyright 2012 grchere <grchere@debian2>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
 
#define HTTP_HEADER "HTTP/1.0 200 OK\nContent-Type: text/html\n\n"
#define MAXDATA 200  // tamaño maximo del buffer de recepcion de datos

/*
 * programa que recibe codigo y descripcion via interfase cgi
 * tanto para metodo GET (usando variables query_string) como
 * para metodo POST (leyendo de stdin)
 * basado en codigo propuesto en http://www.cs.tut.fi/~jkorpela/forms/cgic.html
 */

void unencode(char *src, char *last, char *dest);


int main(int argc, char **argv)
{
	int codigo=0;
	char descripcion[60];
	char *largo = getenv("CONTENT_LENGTH");
	int nlargo;
	char *data = getenv("QUERY_STRING");

	char buffer_parsed[MAXDATA];
	
	printf(HTTP_HEADER);
	printf("<html><body>");
	
	//printf("<p>content_length=[%s] query_string=[%s]</p>",largo,data);
	if ( largo == NULL ) { // metodo GET -> query_string
		if ( data == NULL ) {
			printf("<P>Error! No recibi nada, verifique que el metodo de envio sea GET.</P>");
		} else {
			
			if ( strlen(data) > MAXDATA ) {
				printf("<P>Error! Los datos recibidos tienen un largo mayor al esperado.</P>");
			} else {
				//decodificar
				unencode(data, data+strlen(data), buffer_parsed);
				if(sscanf(buffer_parsed,"codigo=%d&descr=%50[0-9a-zA-Z .,;:'\"]s",&codigo,descripcion)!=2)
					printf("<P>Error! No puede obtener los datos en el formato esperado.</P>");
				else
					printf("<P>Codigo leido [%d] descripcion [%s] len=%d(1).</p>",codigo,descripcion,(int) strlen(descripcion));
			}
		}
	} else { // metodo POST -> stdin
		if( sscanf(largo,"%d",&nlargo) != 1 || nlargo > MAXDATA ) {
			printf("<P>Error! los datos recibidos estan en un formato incorrecto.</p>");
		} else {
			char buffer[MAXDATA];
			memset(buffer,0,MAXDATA);
			int n = read(STDIN_FILENO,buffer,MAXDATA);
			//printf("<p>content_length=[%s] stdin=[%s]</p>",largo,buffer);
			if ( n != -1 ) {
				unencode(buffer, buffer+n, buffer_parsed);
				//printf("<p>buffer_parsed=[%s]</p>",buffer_parsed);
				// ojo con el parsing de descripcion, ya que %s termina cuando encuentra el primer espacio dentro
				// de la cadena, para ello se agrego el espacio como un caracter valido para el parsing de la cadena
				if(sscanf(buffer_parsed,"codigo=%d&descr=%50[0-9a-zA-Z .,;:'\"]s",&codigo,descripcion)!=2)
					printf("<P>Error! No puede obtener los datos en el formato esperado (2).</P>");
				else
					printf("<P>Codigo leido [%d] descripcion [%s] len=%d(2).</p>",codigo,descripcion,(int) strlen(descripcion));
			} else {
				printf("<P>Error! los datos recibidos no pudieron ser leidos</p>");
			}
		}
	}
	printf("</body></html>");
	return 0;
}

// decodifica en dest lo codificado en src hasta last (que se supone es la direccion de
// memoria en donde debe terminar esta decodificacion, direccion superior a src, obviamente)
// observe bien el uso y no uso de llaves, donde termina la instruccion for()
void unencode(char *src, char *last, char *dest)
{
 for(; src != last; src++, dest++)
   if(*src == '+')
     *dest = ' ';
   else if(*src == '%') {
     int code;
     if(sscanf(src+1, "%2x", &code) != 1) code = '?';
     *dest = code;
     src +=2; }     
   else
     *dest = *src;
 *dest = '\n';
 *++dest = '\0';
}
