/*
 * cgi1.c
 * 
 * Copyright 2012 grchere <grchere@debian2>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */

/*

Programa cgi ejecutado por mongoose web server
Ejecucion del servidor (en este caso indicando que los programas cgi se 
llaman cgi* y se encuentran en el directorio actual del servidor:
   /home/grchere/mongoose/./mongoose -C "./cgi**"

Compilar y copiar este programa como cgi1 y copiarlo en:
   /home/grchere/mongoose/cgi1
Ejecutar el programa:
   estando en ejecucion el servidor en el puerto 8080
   abrir navegador web y tipear url:  http://localhost:8080/cgi1
   la pagina deberia mostrar Hola Mundo!

Verificar que tenga los permisos de ejecucion activados y ejecutar servidor
como root si fuese necesario

Instalacion del servidor:
   Descargar server de http://code.google.com/p/mongoose/
   Descomprimir archivo .tar.gz
   Como root, en la carpeta en donde se descomprimio servidor, ejecutar:
   $ make linux
   Verificar que se haya creado el ejecutable mongoose
Ejecutar servidor (en este caso para que reconozca al programa cgi1 como un cgi):
   $ ./mongoose -C "./cgi**"


Fuentes de Informacion:
http://www.cs.tut.fi/~jkorpela/forms/cgic.html    
*/

#include <stdio.h>
#include <stdlib.h>

#define HTTP_HEADER "HTTP/1.0 200 OK\nContent-Type: text/html\n\n"

int main(int argc, char **argv)
{
	printf(HTTP_HEADER);
	printf("<html><body>\
<form action=\"/cgi2\" method=\"get\">\
<div><label>Codigo: <input name=\"codigo\" size=\"5\"></label></div>\
<div><label>Descripcion: <input name=\"descr\" size=\"60\"></label></div>\
<div><input type=\"submit\" value=\"Envio!\"></div>\
</form>\
</body></html>");
	return 0;
}

