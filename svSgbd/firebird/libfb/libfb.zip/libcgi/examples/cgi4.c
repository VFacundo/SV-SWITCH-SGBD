/*
 *  cgi4.c
 * 
 * Copyright 2012 grchere <grchere@debian2>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */
/*

Programa cgi ejecutado por mongoose web server
Ejecucion del servidor (en este caso indicando que los programas cgi se 
llaman cgi* y se encuentran en el directorio actual del servidor:
   /home/grchere/mongoose/./mongoose -C "./cgi**"

Compilar y copiar este programa como cgi1 y copiarlo en:
   /home/grchere/mongoose/cgi1
Ejecutar el programa:
   estando en ejecucion el servidor en el puerto 8080
   abrir navegador web y tipear url:  http://localhost:8080/cgi1
   la pagina deberia mostrar Hola Mundo!

Verificar que tenga los permisos de ejecucion activados y ejecutar servidor
como root si fuese necesario

Instalacion del servidor:
   Descargar server de http://code.google.com/p/mongoose/
   Descomprimir archivo .tar.gz
   Como root, en la carpeta en donde se descomprimio servidor, ejecutar:
   $ make linux
   Verificar que se haya creado el ejecutable mongoose
Ejecutar servidor (en este caso para que reconozca al programa cgi1 como un cgi):
   $ ./mongoose -C "./cgi**"


Fuentes de Informacion:
http://www.cs.tut.fi/~jkorpela/forms/cgic.html    
*/

/*
 * cgi3  recibe los datos de un formulario, se conecta a b.d. firebird
 * segun los datos de conexion que recibe del formulario y realiza un
 * query sobre la b.d. y muestra los resultados del mismo
 * Utiliza libfb (observar las propiedades de este proyecto, forma de
 * compilar, linkear y publicar ejecutable en servidor mongoose)
 * 
 * Atte. Guillermo Cherencio.
 * */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <libfb.h>

#define HTTP_HEADER "HTTP/1.0 200 OK\nContent-Type: text/html\n\n"
#define MAXDATA 1024  // tamaño maximo del buffer de recepcion de datos

// funcion para decodificar los datos recibidos via cgi
void unencode(char *src, char *last, char *dest);
// funcion para cargar las variables recibidas via cgi
void get_var(char *src,char *variable,char *dest,int largo);
// funcion callback para procesar queries
int onDoQuery(int eventType,fb_query_info *qi,void *buffer);

int main(int argc, char **argv)
{
	// variables en donde cargar los datos enviados en formulario html
	char conexion[512];
	char usuario[32];
	char rol[32];
	char contrasenia[32];
	
	
	// datos acerca de los datos enviados via metodo http GET o POST
	char *largo = getenv("CONTENT_LENGTH");
	int nlargo;
	char *data = getenv("QUERY_STRING");

	char buffer_parsed[MAXDATA];
	short continuo = 1;  // flag para saber si continuo proceso luego de parsing
	
	printf(HTTP_HEADER);
	printf("<html><body>");
	
	//printf("<p>content_length=[%s] query_string=[%s]</p>",largo,data);
	if ( largo == NULL ) { // metodo GET -> query_string
		if ( data == NULL ) {
			printf("<P>Error! No recibi nada, verifique que el metodo de envio sea GET.</P>");
			continuo=0;
		} else {
			if ( strlen(data) > MAXDATA ) {
				printf("<P>Error! Los datos recibidos tienen un largo mayor al esperado.</P>");
				continuo=0;
			} else {
				//parece estar todo Ok, vamos a decodificar
				unencode(data, data+strlen(data), buffer_parsed);
				get_var(buffer_parsed,"conexion",conexion,512);
				get_var(buffer_parsed,"usuario",usuario,32);
				get_var(buffer_parsed,"rol",rol,32);
				get_var(buffer_parsed,"contrasenia",contrasenia,32);
				
				if( strlen(conexion) == 0 || strlen(usuario) == 0 || strlen(rol) == 0 || strlen(contrasenia) == 0 ) {
					printf("<P>Error! No puede obtener los datos en el formato esperado.</P>");
					continuo=0;
				} else {
					//printf("<P>Conexion [%s] usuario [%s] rol [%s] contrasenia [%s]</p>",conexion,usuario,rol,contrasenia);
				}
			}
		}
	} else { // metodo POST -> stdin
		if( sscanf(largo,"%d",&nlargo) != 1 || nlargo > MAXDATA ) {
			printf("<P>Error! los datos recibidos estan en un formato incorrecto.</p>");
			continuo=0;
		} else {
			char buffer[MAXDATA];
			memset(buffer,0,MAXDATA);
			int n = read(STDIN_FILENO,buffer,MAXDATA);
			//printf("<p>content_length=[%s] stdin=[%s]</p>",largo,buffer);
			if ( n != -1 ) {
				unencode(buffer, buffer+n, buffer_parsed);
				//printf("<p>buffer_parsed=[%s]</p>",buffer_parsed);
				get_var(buffer_parsed,"conexion",conexion,512);
				get_var(buffer_parsed,"usuario",usuario,32);
				get_var(buffer_parsed,"rol",rol,32);
				get_var(buffer_parsed,"contrasenia",contrasenia,32);
				
				if( strlen(conexion) == 0 || strlen(usuario) == 0 || strlen(rol) == 0 || strlen(contrasenia) == 0 ) {
					printf("<P>Error! No puede obtener los datos en el formato esperado (2).</P>");
					continuo=0;
				} else {
					//printf("<P>Conexion [%s] usuario [%s] rol [%s] contrasenia [%s]</p>",conexion,usuario,rol,contrasenia);
				}
			} else {
				printf("<P>Error! los datos recibidos no pudieron ser leidos</p>");
				continuo=0;
			}
		}
	}
	if ( continuo ) {
		// establezco conexion con b.d. firebird usando libfb
	   fb_db_info dbinfo;
	   strcpy(dbinfo.user,usuario);
	   strcpy(dbinfo.passw,contrasenia);
	   strcpy(dbinfo.dbname,conexion);
	   strcpy(dbinfo.role,rol);
	   if (fb_do_connect(&dbinfo)) {  // me conecte!
		   char *buffer_table = (char *) malloc(1024*3);
		   memset(buffer_table,0,1024*3);
		   strcpy(buffer_table,"<table border=1><tr><td colspan=3><center>Tecnicaturas ISFT 189</center></td></tr><tr><td>Codigo</td><td>Descripcion</td><td>Titulo</td></tr>");
		   fb_do_query(&dbinfo,1,"SELECT CODIGO, DESCR, TITULO FROM TBL_PLANE",onDoQuery,buffer_table);
		   fb_do_disconnect(&dbinfo);
		   strcat(buffer_table,"</table>");
		   printf(buffer_table);
		   free(buffer_table);
	   } else { // error en conexion a b.d.
		   printf("<P>Error! no pude conectarme a base de dato</p>");
	   }
	}
	printf("</body></html>");
	return 0;
}


// decodifica en dest lo codificado en src hasta last (que se supone es la direccion de
// memoria en donde debe terminar esta decodificacion, direccion superior a src, obviamente)
// observe bien el uso y no uso de llaves, donde termina la instruccion for()
void unencode(char *src, char *last, char *dest)
{
 for(; src != last; src++, dest++)
   if(*src == '+')
     *dest = ' ';
   else if(*src == '%') {
     int code;
     if(sscanf(src+1, "%2x", &code) != 1) code = '?';
     *dest = code;
     src +=2; }     
   else
     *dest = *src;
 *dest = '\n';
 *++dest = '\0';
}

/* src es un puntero a un string cgi con el siguiente formato:
 
  variable1=valor1&variable2=valor2&....
  
  variable apunta al nombre de la variable (sin & ni =)
  dest es un buffer con suficiente espacio para guardar el contenido
  de la variable
  largo es la cantidad maxima de caracteres a copiar en dest
*/
void get_var(char *src,char *variable,char *dest,int largo) {
	char mivar1[strlen(variable)+5];
	char mivar2[strlen(variable)+5];
	strcpy(mivar1,"&");
	strcat(mivar1,variable);
	strcat(mivar1,"=");
	strcpy(mivar2,variable);
	strcat(mivar2,"=");
	memset(dest,0,largo);
	int desplazo = strlen(mivar1);
	char *pos = strstr(src,mivar1); // busco &variable=
	if ( pos == NULL ) {
		pos = strstr(src,mivar2); // busco variable=
		desplazo = strlen(mivar2);
	}
	if ( pos != NULL ) { // algo encontre!
		int n=0;
		pos+=desplazo;
		// copio el valor de la variable en dest
		while ( n < largo && *pos != '\0' && *pos != '&' ) {
			*dest = *pos;
			n++;dest++;pos++;
		}
	} // si no encuentro nada, no copio nada y dejo dest con nulos
}


/*
onDoQuery()
// funcion local para el control de ejecucion de queries
*/
int onDoQuery(int eventType,fb_query_info *qi,void *buffer) {
   int ret;
   switch(eventType) {
      case FB_MEMORY_QUERY_ERROR:
         ret=FB_ABORT_ALL;
         //printf("onDoQuery(): Memory Error! (query id=%d)\n",qi->queryId);
         break;
      case FB_EXECUTE_QUERY_OK:
         ret=FB_CONTINUE;
         //printf("onDoQuery(): Execute Ok (query id=%d)\n",qi->queryId);
         break;
      case FB_EXECUTE_QUERY_ERROR:
         ret=FB_ABORT;
         //printf("onDoQuery(): Error %ld ejecutando (query id=%d)\n%s",qi->SQLCODE,qi->queryId,qi->errmsg);
         break;
      case FB_FETCH_RECORDS:
		   //printf("onDoQuery(): Comienzo Fetch #%d (query id=%d)\n",qi->set_time,qi->queryId);
		   while(fb_fetch(qi)) {
			  char *codigo      = fb_getcol(qi,0);
			  char *descripcion = fb_getcol(qi,1);
			  char *titulo      = fb_getcol(qi,2);
			  strcat(buffer,"<tr><td>");
			  strcat(buffer,codigo);
			  strcat(buffer,"</td><td>");
			  strcat(buffer,descripcion);
			  strcat(buffer,"</td><td>");
			  strcat(buffer,titulo);
			  strcat(buffer,"</td></tr>");
			  if ( codigo      != NULL) free(codigo);
			  if ( descripcion != NULL) free(descripcion);
			  if ( titulo      != NULL) free(titulo);
		   }
		   //printf("onDoQuery(): Termine fectch #%d (query id=%d)\n",qi->set_time,qi->queryId);
         ret=FB_CONTINUE;
         break;
      case FB_SET_QUERY_OUTPUT:
         //printf("onDoQuery(): SetQueryOutput time #%d  (query id=%d)\n",qi->set_time,qi->queryId);
         ret=FB_CONTINUE;
         break;
      case FB_SET_QUERY_INPUT:
         ret=FB_CONTINUE;
         break;
      default:
         //printf("onDoQuery(): Error evento %d no implementado (query id=%d)\n",eventType,qi->queryId);
         break;
   }
   return ret;
}

