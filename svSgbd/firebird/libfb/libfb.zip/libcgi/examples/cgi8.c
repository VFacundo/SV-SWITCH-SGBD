/*
 * cgi8.c
 *
 * Copyright 2012 grchere <grchere@debian2>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 *
 *
 *
 *
 *  cgi8 recibe en variables cgi los datos de conexion a firebird
 * y los muestra en formulario a traves de variables que sustituye
 * en archivo html. Hace uso del concepto de variable
 * cgi declarada dentro del programa para luego ser sustituida en
 * un archivo html que interpreta este programa
 * Utiliza otras funciones nuevas de la libreria cgi y definiciones
 * para simplificar programas cgi
 */
 
#include <libcgi.h>
#include <libfb.h>

extern int FB_SHOW_MESSAGES;         // suprimo los mensajes de libreria FB

int main(int argc, char **argv)
{
	
	FB_SHOW_MESSAGES=0;  // desactivo mensajes de libreria libfb
	
	char *cgi_buffer = cgi_get_buffer();
	if ( cgi_buffer == NULL ) {
		printf("<html><body><p>Error! no se encontraron variables de entorno</p></body></html>");
		return 1;
	}
    int cgi_n_vars;
    cgi_var *cgi_vars = cgi_get_vars(cgi_buffer,&cgi_n_vars);
    
    cgi_var *v = cgi_get_variable("contrasenia",cgi_vars,cgi_n_vars);
char tmptmp[512];
snprintf(tmptmp,512,"main() 1 contraseña=[%s]",v->value);    
cgi_log("cgi7",tmptmp);
    
    // amplio espacio de variables para agregar dos variables mas al final del pool de variables
    //cgi_var *var1 = cgi_new_variable_type_value("titulo",'S',"TITULO CGI8 v10");
    //cgi_var *var2 = cgi_new_variable_type_value("subtitulo",'S',"SUBTITULO CGI8");
snprintf(tmptmp,512,"main() 2 contraseña=[%s]",v->value);    
cgi_log("cgi7",tmptmp);
    //cgi_vars = cgi_add_new_var(cgi_vars,&cgi_n_vars,var1);
    //cgi_vars = cgi_add_new_var(cgi_vars,&cgi_n_vars,var2);
    
	// devuelvo pagina html
	printf(HTTP_HEADER);
	printf("<html><body>");
	// imprimo tabla html con variables cgi + variables propias agregadas
	//cgi_print_vars(cgi_vars,cgi_n_vars);
	char *otra_tabla = cgi_interpret_file("cgi8.dhtml",&cgi_vars,&cgi_n_vars);
snprintf(tmptmp,512,"main() 3 imprimo tabla con variables sustituidas");    
cgi_log("cgi7",tmptmp);
cgi_log("cgi7","****************************");
cgi_log("cgi7",otra_tabla);
cgi_log("cgi7","****************************");

	// imprimo tabla con sustitucion de variables
	//printf(otra_tabla);
	// imprimo tabla html con variables cgi + variables propias agregadas + agregadas por cgi_interpret_file
	//cgi_print_vars(cgi_vars,cgi_n_vars);
	
	
	fb_db_info dbinfo;
	strcpy(dbinfo.user,cgi_get_variable("usuario",cgi_vars,cgi_n_vars)->value);
	strcpy(dbinfo.passw,cgi_get_variable("contrasenia",cgi_vars,cgi_n_vars)->value);
	strcpy(dbinfo.dbname,cgi_get_variable("conexion",cgi_vars,cgi_n_vars)->value);
	strcpy(dbinfo.role,cgi_get_variable("rol",cgi_vars,cgi_n_vars)->value);
	if (fb_do_connect(&dbinfo)) {  // me conecte!
		cgi_var *vqry = cgi_get_variable("query",cgi_vars,cgi_n_vars);
		query q;
		fb_init(&q);
		fb_do_query(&dbinfo,1,vqry->value,onDoGenericQuery,&q);
		vqry->qry = &q; // asocio query de libfb con variable de libreria libcgi
		
		// recorrer query y generar tabla html!
		//printf("<P>query devolvio %d filas y %d columnas</P>\n",q.rows,q.cols);
		
		int title = 0;
		int footer = 0;
		char *substr = cgi_substring(otra_tabla,"#{foreach query","}");
		char *otra_otra_tabla = NULL;
cgi_log("cgi7",substr);
		if ( substr ) {
			if ( strcasestr(substr," title") ) title=1;
			if ( strcasestr(substr," footer") ) footer=1;
			char *html = NULL;
			if ( strcasestr(substr," html=") ) {
				html = cgi_substring_toend(substr," html=");
			}

			char *tr_generadas_from_query = cgi_create_tr(&cgi_vars,&cgi_n_vars,vqry,title,footer,html);
cgi_log("cgi7",tr_generadas_from_query);			
			
			char tagtmp[16+strlen(substr)+2];
			snprintf(tagtmp,16+strlen(substr)+2,"#{foreach query%s}",substr);
cgi_log("cgi7",tagtmp);			

			otra_otra_tabla = cgi_search_and_replace(otra_tabla,tagtmp,tr_generadas_from_query);

cgi_log("cgi7",otra_otra_tabla);						

			free(substr);
			if (tr_generadas_from_query) free(tr_generadas_from_query);
			if (html) free(html);
		}
	
		printf(otra_otra_tabla);
		
/******************GENERO TABLA MOSTRANDO RESULTADOS DEL QUERY***************************
		int n,i;
		struct rquery *r = q.top;
		printf("<table border=1>");
		char **cols = (char **) q.colname;
		printf("<tr>");
		for(i=0;i<q.cols;i++) {
			printf("<td>%s</td>",*(cols+i));
		}
		printf("</tr>");
		
		for(n=0;n<q.rows;n++) {
			printf("<tr>");
			char **fld = (char **) r->col;
			for(i=0;i<q.cols;i++) {
				printf("<td>%s</td>",*(fld+i));
			}
			r = r->next;
			printf("</tr>");
		}
		printf("</table>");
***************************************************************************************/
		fb_free(&q);
		fb_do_disconnect(&dbinfo);
		if (otra_otra_tabla) free(otra_otra_tabla);
	} else { // error en conexion a b.d.
	   printf("<P>Error! no pude conectarme a base de dato</p>");
	}
			
	// fin de archivo html
	printf("</body></html>\n");
	// libero memoria
	free(otra_tabla);
	cgi_free_variables(cgi_vars,cgi_n_vars);
	return 0;
}
