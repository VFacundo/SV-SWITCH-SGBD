/*
 * cgi5.c
 * 
 * Copyright 2012 grchere <grchere@debian2>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */


/*

Programa cgi ejecutado por mongoose web server
Ejecucion del servidor (en este caso indicando que los programas cgi se 
llaman cgi* y se encuentran en el directorio actual del servidor:
   /home/grchere/mongoose/./mongoose -C "./cgi**"

Compilar y copiar este programa como cgi1 y copiarlo en:
   /home/grchere/mongoose/cgi1
Ejecutar el programa:
   estando en ejecucion el servidor en el puerto 8080
   abrir navegador web y tipear url:  http://localhost:8080/cgi1
   la pagina deberia mostrar Hola Mundo!

Verificar que tenga los permisos de ejecucion activados y ejecutar servidor
como root si fuese necesario

Instalacion del servidor:
   Descargar server de http://code.google.com/p/mongoose/
   Descomprimir archivo .tar.gz
   Como root, en la carpeta en donde se descomprimio servidor, ejecutar:
   $ make linux
   Verificar que se haya creado el ejecutable mongoose
Ejecutar servidor (en este caso para que reconozca al programa cgi1 como un cgi):
   $ ./mongoose -C "./cgi**"


Fuentes de Informacion:
http://www.cs.tut.fi/~jkorpela/forms/cgic.html    
*/

/*
 * cgi5 es igual que cgi4 pero en este caso es una version mas modular 
 * Mejora la lectura de las variables cgi, no asume un largo maximo del
 * buffer, trabaja con memoria dinamica
 * 
 * Atte. Guillermo Cherencio.
 * */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <libfb.h>
#include <libcgi.h>

#define HTTP_HEADER "HTTP/1.0 200 OK\nContent-Type: text/html\n\n"

int fb_onDoQuery(int eventType,fb_query_info *qi,void *buffer);
// tipo de dato que representa un buffer a ser llenado con una consulta de datos
// proveniente de la base de datos. Lleva la cuenta de la cantidad de bytes asignados
// en forma dinamica que tiene este buffer y de la cantidad de bytes usados, a fin de
// poder ampliar el buffer si es necesario
typedef struct {
	unsigned long total_len;
	unsigned long total_used;
	char *buffer;
} buffer_query;

extern int FB_SHOW_MESSAGES;         // suprimo los mensajes de libreria FB

int main(int argc, char **argv)
{

	FB_SHOW_MESSAGES=0;  // desactivo mensajes de libreria libfb

	// variables en donde cargar los datos enviados en formulario html
	char conexion[512];
	char usuario[32];
	char rol[32];
	char contrasenia[32];
	
	printf(HTTP_HEADER);
	printf("<html><body>");
	
	char *buffer_cgi = cgi_get_buffer();
	if ( buffer_cgi != NULL ) {
		cgi_get_var(buffer_cgi,"conexion",conexion,512);
		cgi_get_var(buffer_cgi,"usuario",usuario,32);
		cgi_get_var(buffer_cgi,"rol",rol,32);
		cgi_get_var(buffer_cgi,"contrasenia",contrasenia,32);
		// establezco conexion con b.d. firebird usando libfb
		fb_db_info dbinfo;
		strcpy(dbinfo.user,usuario);
		strcpy(dbinfo.passw,contrasenia);
		strcpy(dbinfo.dbname,conexion);
		strcpy(dbinfo.role,rol);
		if (fb_do_connect(&dbinfo)) {  // me conecte!
			char *buffer_table = (char *) malloc(1024);
			if ( buffer_table != NULL ) {
				buffer_query qbuffer;
				strcpy(buffer_table,"<table border=1><tr><td colspan=3><center>Tecnicaturas ISFT 189</center></td></tr><tr><td>Codigo</td><td>Descripcion</td><td>Titulo</td></tr>");
				qbuffer.total_len = 1024;
				qbuffer.total_used = strlen(buffer_table);
				qbuffer.buffer = buffer_table;
				fb_do_query(&dbinfo,1,"SELECT CODIGO, DESCR, TITULO FROM TBL_PLANE",fb_onDoQuery,&qbuffer);
				fb_do_disconnect(&dbinfo);
				strcat(qbuffer.buffer,"</table>");
				// envio tabla html 
				printf(qbuffer.buffer);
				// libero buffer para tabla html
				free(qbuffer.buffer);
			} else {
				printf("<P>Error! en asignacion de memoria</p>");
			}
		} else { // error en conexion a b.d.
		   printf("<P>Error! no pude conectarme a base de dato</p>");
		}
		// libero buffer cgi
		free(buffer_cgi);
	} else {
		printf("<P>Error! No pude procesar formulario!</P>");
	}
	// cierro pagina html y termino consulta
	printf("</body></html>");
	return 0;
}
//============================================================================================
//============================================================================================
//============================================================================================


/*
onDoQuery()
// funcion local para el control de ejecucion de queries
*/
int fb_onDoQuery(int eventType,fb_query_info *qi,void *buffer) {
   int ret;
   switch(eventType) {
      case FB_MEMORY_QUERY_ERROR:
         ret=FB_ABORT_ALL;
         //printf("onDoQuery(): Memory Error! (query id=%d)\n",qi->queryId);
         break;
      case FB_EXECUTE_QUERY_OK:
         ret=FB_CONTINUE;
         //printf("onDoQuery(): Execute Ok (query id=%d)\n",qi->queryId);
         break;
      case FB_EXECUTE_QUERY_ERROR:
         ret=FB_ABORT;
         //printf("onDoQuery(): Error %ld ejecutando (query id=%d)\n%s",qi->SQLCODE,qi->queryId,qi->errmsg);
         break;
      case FB_FETCH_RECORDS:
  			//printf("onDoQuery(): Comienzo Fetch #%d (query id=%d)\n",qi->set_time,qi->queryId);
		   ret=FB_CONTINUE;
		   buffer_query *q = (buffer_query *) buffer;
		   while(fb_fetch(qi)) {
			  // recupero datos de la base de datos
  			  //printf("onDoQuery(): recupero datos de b.d.\n");
			  char *codigo      = fb_getcol(qi,0);
			  char *descripcion = fb_getcol(qi,1);
			  char *titulo      = fb_getcol(qi,2);
			  if ( q != NULL && codigo != NULL && descripcion != NULL && titulo != NULL ) {
  				  //printf("onDoQuery(): cuanto necesito para guardar estos datos?\n");
				  // cuanto necesito (aprox) para guardar estos datos en el buffer ?
				  int largo = strlen(codigo)+strlen(descripcion)+strlen(titulo)+50;
				  if ( (q->total_used + largo + 10) > q->total_len ) { // necesito mas memoria para guardar este query!
						q->buffer = (char *) realloc(q->buffer,q->total_len+1024);
						if ( q->buffer != NULL ) {
							q->total_len +=1024;
						} else { // error en re-asignacion de memoria
							ret=FB_ABORT;
							break;
						}
				  }
				  strcat(q->buffer,"<tr><td>");
				  strcat(q->buffer,codigo);
				  strcat(q->buffer,"</td><td>");
				  strcat(q->buffer,descripcion);
				  strcat(q->buffer,"</td><td>");
				  strcat(q->buffer,titulo);
				  strcat(q->buffer,"</td></tr>");
				  q->total_used +=largo;
				  free(codigo);
				  free(descripcion);
				  free(titulo);
			  } else { // error en asignacion de memoria
				  ret=FB_ABORT;
				  break;
			  }
		   }
		   //printf("onDoQuery(): Termine fectch #%d (query id=%d)\n",qi->set_time,qi->queryId);
         break;
      case FB_SET_QUERY_OUTPUT:
         //printf("onDoQuery(): SetQueryOutput time #%d  (query id=%d)\n",qi->set_time,qi->queryId);
         ret=FB_CONTINUE;
         break;
      case FB_SET_QUERY_INPUT:
         ret=FB_CONTINUE;
         break;
      default:
         //printf("onDoQuery(): Error evento %d no implementado (query id=%d)\n",eventType,qi->queryId);
         break;
   }
   return ret;
}

