/*
 * cgi7.c
 * 
 * Copyright 2012 grchere <grchere@debian2>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */

/* 
 *  cgi7 recibe en variables cgi los datos de conexion a firebird
 * y los muestra en formulario a traves de variables que sustituye
 * en archivo html. Hace uso del concepto de variable
 * cgi declarada dentro del programa para luego ser sustituida en
 * un archivo html que interpreta este programa
 */

#include <libcgi.h>

int main(int argc, char *argv[])
{
	int nvars = 6;
	cgi_var variables[nvars],*pvars;
	memset(&variables[0],0,sizeof(cgi_var)*nvars);
	variables[0].name = strdup("conexion");
	variables[1].name = strdup("usuario");
	variables[2].name = strdup("rol");
	variables[3].name = strdup("contrasenia");
	variables[4].name = strdup("titulo");
	variables[5].name = strdup("subtitulo");

	cgi_log(argv[0],"cero");

	// cargo buffer cgi
	char *buffer_cgi = cgi_get_buffer();
	if ( buffer_cgi == NULL ) {
		printf("<html><body><p>Error! no se encontraron variables de entorno</p></body></html>");
		return 1;
	}
	
	cgi_log(argv[0],"uno");

	char tmp[512];
	snprintf(tmp,512,"request_method=[%s]",getenv("REQUEST_METHOD"));
	cgi_log(argv[0],tmp);
	snprintf(tmp,512,"query_string=[%s]",getenv("QUERY_STRING"));
	cgi_log(argv[0],tmp);
	snprintf(tmp,512,"content_length=[%s]",getenv("CONTENT_LENGTH"));
	cgi_log(argv[0],tmp);

	// cargo los valores de las variables desde cgi
	cgi_get_var_cgi(buffer_cgi,&variables[0]);	
	
	cgi_log(argv[0],"dos");
	
	cgi_get_var_cgi(buffer_cgi,&variables[1]);	
cgi_log(argv[0],"tres");
	cgi_get_var_cgi(buffer_cgi,&variables[2]);	
	cgi_get_var_cgi(buffer_cgi,&variables[3]);	
	// pongo otros valores a variables que no vienen desde cgi
cgi_log(argv[0],"cuatro");
	cgi_set_variable(&variables[4],"PRUEBA DE VARIABLES CGI & PROGRAMA");
	cgi_set_variable(&variables[5],"DATOS DE LA CONEXION:");

cgi_log(argv[0],"cuatro.5");
	pvars = &variables[0];
	char *pagina = cgi_interpret_file("cgi7.dhtml",&pvars,&nvars);

cgi_log(argv[0],"cinco");
	// devuelvo pagina html
	printf(HTTP_HEADER);
	printf(pagina);
	
	// libero memoria
cgi_log(argv[0],"seis");
	free(buffer_cgi);
	free(pagina);
	cgi_free_variables(&variables[0],nvars);
	
	return 0;
}

