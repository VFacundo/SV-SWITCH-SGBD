var searchData=
[
  ['qry',['qry',['../structcgi__var.html#a8f092a9ed2ed209e6bba26d2a00b610e',1,'cgi_var']]]
];
