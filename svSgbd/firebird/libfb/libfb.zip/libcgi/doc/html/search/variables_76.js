var searchData=
[
  ['value',['value',['../structcgi__var__value.html#a2c8aeea4f642b018b08b0ee1c8400a8e',1,'cgi_var_value::value()'],['../structcgi__var.html#a93ce97f1788874c6adb8ca86925cd71e',1,'cgi_var::value()']]]
];
