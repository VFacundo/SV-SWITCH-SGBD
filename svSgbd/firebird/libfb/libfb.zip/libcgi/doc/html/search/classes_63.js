var searchData=
[
  ['cgi_5fvar',['cgi_var',['../structcgi__var.html',1,'']]],
  ['cgi_5fvar_5fvalue',['cgi_var_value',['../structcgi__var__value.html',1,'']]]
];
