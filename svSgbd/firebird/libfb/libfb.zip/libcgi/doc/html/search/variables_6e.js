var searchData=
[
  ['name',['name',['../structcgi__var.html#a66dd74aadaf2babd6eb6495b4b23404f',1,'cgi_var']]],
  ['next',['next',['../structcgi__var__value.html#a2c28e690fd184deaee91b6e8103857c6',1,'cgi_var_value']]]
];
