/**
 * @file libcgi.c
 * Archivo de implementacion de libreria libcgi
 * 
 * 
 * Copyright 2012 grchere 
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * @author Guillermo Cherencio 
 * 
 * @example ./examples/cgi1.c
 * @example ./examples/cgi2.c
 * @example ./examples/cgi3.c
 * @example ./examples/cgi4.c
 * @example ./examples/cgi5.c
 * @example ./examples/cgi6.c
 * @example ./examples/cgi7.c
 * @example ./examples/cgi7.dhtml
 * @example ./examples/cgi8.c
 * @example ./examples/cgi8.dhtml
*/


#include <libcgi.h>

/** Carga archivo de texto en memoria y lo devuelve como cadena de caracteres */
char *cgi_load_file(char *filename);

//============================================================================================
//============================================================================================
//============================================================================================

/**
 * Obtiene buffer cgi decodificado para su posterior tratamiento en programa
 * 
 * Luego de obtener este buffer, del mismo puede obtenerse las variables cgi recibidas
 * <br>Ejemplo de uso: @code {.c}
	char *buffer = *cgi_get_buffer();
	...
	if ( buffer ) free(buffer);
 * @endcode
 * @return devuelve buffer cgi decodificado en forma dinamica (luego utilice free() para liberar esta memoria)
 * @warning el buffer se devuelve decodificado (@see cgi_unencode()). Verifica automaticamente el tipo
 * de metodo http utilizado para enviar datos a este programa cgi (POST o GET)
 * @author Guillermo Cherencio
 **/
char *cgi_get_buffer() {
//	char tmptmp[512];	
	// datos acerca de los datos enviados via metodo http GET o POST
	char *req_met = getenv("REQUEST_METHOD");
	if ( req_met != NULL ) {
	 if(strcmp(req_met,"GET") == 0) { // metodo GET -> query_string
		char *data = getenv("QUERY_STRING");
		if ( data != NULL ) {
			int nlargo = strlen(data)+1;
			char *buffer_parsed = (char *) malloc(nlargo);
			if ( buffer_parsed != NULL ) {
				memset(buffer_parsed,0,nlargo);
//snprintf(tmptmp,512,"cgi_get_buffer() 1 buffer=[%s]",data);    
//cgi_log("cgi7",tmptmp);
				cgi_unencode(data, data+(nlargo-1), buffer_parsed);
				return buffer_parsed;  // todo OK!
			} else {
				return NULL; // error en asignacion de memoria
			}
		} else {
			return NULL; // error en obtener variable de entorno cgi
		}
	 } else { // metodo POST -> stdin
		char *strlargo = getenv("CONTENT_LENGTH");
		if ( strlargo != NULL ) {
			int largo = atoi(strlargo);
			if ( largo > 0 ) {
				char *data = (char *) malloc(largo+1);
				if ( data != NULL ) {
					memset(data,0,largo+1);
					int n = read(STDIN_FILENO,data,largo+1);
					if ( n != -1 ) {
						char *buffer_parsed = (char *) malloc(n+1);
						if ( buffer_parsed != NULL ) {
							memset(buffer_parsed,0,n+1);
//snprintf(tmptmp,512,"cgi_get_buffer() 2 buffer=[%s]",data);    
//cgi_log("cgi7",tmptmp);
							cgi_unencode(data, data+n, buffer_parsed);
							return buffer_parsed; // todo Ok!
						} else {
							return NULL; // error en asignacion de memoria
						}
					} else {
						return NULL; // error en lectura de datos  via stdin
					}
				} else {
					return NULL; // error en asignacion de memoria
				}
			} else return NULL; // largo 0 o menor que cero, dato incorrecto
		} else {
			return NULL; // error en obtener el largo de la entrada via stdin
		}
	 }
	} else {
		return NULL; // error en obtener variable de entorno cgi
	}
}

/**
 * Decodifica en dest lo codificado en src hasta last
 * 
 * dest se supone es la direccion de memoria en donde debe terminar esta 
 * decodificacion, direccion superior a src
 * observe bien el uso y no uso de llaves, donde termina la instruccion for()
 * 
 * @param src puntero al comienzo del buffer cgi a decodificar
 * @param last puntero al final del buffer cgi a decodificar
 * @param dest puntero al comienzo del buffer en donde quedara el buffer cgi decodificado, dest 
 *        tiene que contar con suficiente espacio pre-asignado
 * @author Guillermo Cherencio
 * @return none
*/
void cgi_unencode(char *src, char *last, char *dest)
{
 for(; src != last; src++, dest++)
   if(*src == '+')
     *dest = ' ';
   else if(*src == '%') {
     int code;
     if(sscanf(src+1, "%2x", &code) != 1) code = '?';
     *dest = code;
     src +=2; }     
   else
     *dest = *src;
 *dest = '\0';
}

/**
 * Obtiene el valor de una variable cgi recibida
 * 
 * <br>src es un puntero a un string cgi con el siguiente formato:<br> @code 
 
  variable1=valor1&variable2=valor2&....
  
  @endcode
  variable apunta al nombre de la variable (sin & ni =)
  dest es un buffer con suficiente espacio para guardar el contenido
  de la variable
  largo es la cantidad maxima de caracteres a copiar en dest
 * 
 * @param src puntero al comienzo del buffer cgi
 * @param variable nombre de la variable cgi a buscar
 * @param dest puntero al comienzo del buffer en donde quedara almacenado el valor de la variable
 * @param largo largo maximo en bytes de dest
 * @warning se asume que dest tiene espacio suficiente para guardar alli el valor de la variable
 * espacio de memoria previamente asignado
 * @return none. En caso de que no se encuentre la variable, dest quedara con valores nulos en su interior
 * @author Guillermo Cherencio
*/
void cgi_get_var(char *src,char *variable,char *dest,int largo) {
	char mivar1[strlen(variable)+5];
	char mivar2[strlen(variable)+5];
	strcpy(mivar1,"&");
	strcat(mivar1,variable);
	strcat(mivar1,"=");
	strcpy(mivar2,variable);
	strcat(mivar2,"=");
	memset(dest,0,largo);
	int desplazo = strlen(mivar1);
	char *pos = strcasestr(src,mivar1); // busco &variable=
	if ( pos == NULL ) {
		pos = strcasestr(src,mivar2); // busco variable=
		desplazo = strlen(mivar2);
	}
	if ( pos != NULL ) { // algo encontre!
		int n=0;
		pos+=desplazo;
		// copio el valor de la variable en dest
		while ( n < largo && *pos != '\0' && *pos != '&' ) {
			*dest = *pos;
			n++;dest++;pos++;
		}
	} // si no encuentro nada, no copio nada y dejo dest con nulos
}

/**
 * Permite loggear la ejecucion de programa cgi
 * 
 * Hay que tener en cuenta que se dificulta el debug de un programa cgi, por lo tanto,
 * esta funcion es importante para saber que lineas del codigo se estan ejecutando con que 
 * valores.
 * <br>Ejemplo de uso: @code {.c}
 
  cgi_log(argv[0],"inicio programa");
  
  @endcode
  Ejemplo Formato de linea archivo log:<br> @code
	[dd/mm/yyyy hh:mn:ss] ip[ip cliente] browser[descripcion browser cliente] 
	user[nombre de usuario] prog[nombre programa] msg[mensaje enviado via cgi_log()]\n
  
  @endcode
 * 
 * @param progname generalmente se indica el mismo nombre del programa (argv[0])
 *        tener en cuenta que si el nombre es "miprog" se grabara el archivo miprog.log
 * @param msg mensaje a grabar dentro del archivo log, junto con otros datos mas que se guardan en el mismo
 * @warning no dejar llamadas a esta funcion innecesarias para evitar que crezcan desmezuradamente
 *          los archivos .log en el servidor
 * @return none.
 * @author Guillermo Cherencio
*/
void cgi_log(char *progname,char *msg) {
	int largo=strlen(progname)+5;
	if ( largo > 5 ) {
		char s[30];
		struct tm tim;
		time_t now = time(NULL);
		tim = *(localtime(&now));
		strftime(s,30,"%d/%m/%Y %H:%M:%S",&tim);
		char filename[largo];
		snprintf(filename,largo,"%s.log",progname);
		FILE *fp = fopen(filename,"a+");
		if ( fp != NULL ) {
			fprintf(fp,"[%s] ip[%s] browser[%s] user[%s] prog[%s] msg[%s]\n",s,
				getenv("REMOTE_ADDR"),getenv("HTTP_USER_AGENT"),
				getenv("REMOTE_USER"),progname,msg);
			fclose(fp);
		}
	}
}

/**
 * Funcion que toma un archivo y lo evalua, reemplazando los valores de las variables escalares
 * 
 * Sustituye en el archivo las referencias a variables por sus valores. Realiza las asignaciones de variables
 * que se indican en el archivo. No sustituye, ignora toda referencia de tipo #{foreach <variable query> [title] [footer] [html=html tags]}
 * la referencia foreach queda para ser procesada desde el interior del programa cgi (@see cgi_create_tr())
 * 
 * 
 * <br>Ejemplo de uso en programa cgi: @code {.c}
 * 
  char *cgi_buffer = cgi_get_buffer();
  int cgi_n_vars;
  cgi_var *cgi_vars = cgi_get_vars(cgi_buffer,&cgi_n_vars);
  char *otra_tabla = cgi_interpret_file("cgi8.dhtml",&cgi_vars,&cgi_n_vars);
  
  @endcode
  <br>Ejemplo de pagina .dhtml: @code {.html}
...  
	#{query=SELECT CODIGO, DESCR, TITULO FROM TBL_PLANE order by descr asc}
	#{titulo=Listado de Carreras}
	#{subtitulo=Prueba SGANS CGI API v1.0}

	<table border=1>
		<tr><td colspan=4><center>#{titulo}</center></td></tr>
		<tr><td colspan=4><center>#{subtitulo}</center></td></tr>
		<tr><td>Nro</td><td>Carrera</td><td>Titulo</td><td>Accion</td></tr>
		#{foreach query footer html=<td>
			<form method="post" action="cgi9">
			<input type="hidden" id="pk"          name="pk"          value="$codigo"/>
			<input type="hidden" id="row"         name="row"         value="$row"/>
			<input type="hidden" id="usuario"     name="usuario"     value="$usuario"/>
			<input type="hidden" id="rol"         name="rol"         value="$rol"/>
			<input type="hidden" id="contrasenia" name="contrasenia" value="$contrasenia"/>
			<input type="hidden" id="conexion"    name="conexion"    value="$conexion"/>
		    <input type="submit" value="borrar" />
		    </form></td>}
	</table>
 ...
  @endcode
  <br>Aqui se puden apreciar distintas expresiones que puede evaluar esta funcion:<br> @code

  #{<variable cgi>}  
  #{<variable cgi>=<valor>}
  
  @endcode
  <br>Luego de interpretar este archivo el programa cgi puede tomar el valor de la variable query, r
  realizar un query en la base de datos y luego reemplazar la expresion #{foreach ... } por el resultado
  de la ejecucion del query, y en cada fila de la tabla agregara lo indicado en html= (en este caso, puede
  apreciarse que se agregara un formulario con el boton "borrar" para permitir eliminar esta tupla de la
  base de datos).<br>
 * 
 * @param filename indica el nombre del archivo a interpretar (generalmente un archivo con extension .dhtml
 * pero ello no es obligatorio, puede ser cualquier archivo de texto que contenga parte de codigo html,
 * el codigo html puede ser incompleto o con errores, el mismo no es evaluado)
 * @param **vars apunta a un apuntador en donde se encuentra el pool de variables cgi que actualmente tienen
 * este programa. Se utiliza un puntero debido a que este programa puede ampliar (si es necesario) el pool 
 * de variables para agregar nuevas variables cuando se produce una asignacion de la misma)
 * @warning no olvidar de liberar el buffer de memoria devuelto por esta funcion, pues puede ser grande.
 * Recuerde que el pool de variables y la cantidad de variables puede variar luego de una llamada a esta
 * funcion. Recuerde que no interpreta las referencias de tipo #{foreach ...}
 * @return buffer de memoria conteniendo la pagina .dhtml interpretada. Devuelve NULL en caso de error en
 * memoria.
 * @author Guillermo Cherencio
*/
char *cgi_interpret_file(char *filename,cgi_var **vars,int *nvars) {
	char *buffer = cgi_load_file(filename);
	if ( buffer != NULL ) {
		long largo = strlen(buffer)*1.5,gasto=0L;
		char *newbuffer = (char *) malloc(largo);
		int n;
		if ( newbuffer ) {
			strcpy(newbuffer,"");
			char *p = buffer-1;
			char *pdesde = buffer;
			while((p=strcasestr(p+1,"#{"))) {
				n=p-pdesde;
				gasto+=n;
				if ( gasto > largo ) { 
					largo+=1024;newbuffer = (char *) realloc(newbuffer,largo);
					if (!newbuffer) return NULL;
				}
				strncat(newbuffer,pdesde,n);
				char *tag = cgi_substring(p,"#{","}");
				if ( strncasecmp(tag,"foreach ",8) != 0 && strcasestr(tag,"=") ) { // asignacion
					char *varname = cgi_substring_upto(tag,"=");
					if ( varname ) {
						char *value = cgi_substring_toend(tag,"=");
						if ( value ) {
							
							if ( cgi_exists_var(varname,*vars,*nvars) ) {
								cgi_var *v = cgi_get_variable(varname,*vars,*nvars);
								if ( v ) { // asigno variable
									cgi_set_variable(v,value);
								}
							} else { // creo una nueva variable
								cgi_var *v = cgi_new_variable(varname);
								if ( v ) {
									cgi_set_variable(v,value);
									*vars = cgi_add_new_var(*vars,nvars,v);
								}
							}
							// libero value
							free(value);
						}
						// libero varname
						free(varname);
					}
					// no agrego nada en newbuffer
					// fin asignacion
				} else if ( strncasecmp(tag,"foreach ",8) == 0 ) { // foreach
					// agrego este tag a newbuffer porque sera tratado nuevamente mas tarde, 
					// en una segunda pasada
					gasto+=2;
					strcat(newbuffer,"#{");
					gasto+=strlen(tag);
					if ( gasto > largo ) { 
						largo+=1024;newbuffer = (char *) realloc(newbuffer,largo);
						if (!newbuffer) return NULL;
					}
					strcat(newbuffer,tag);
					gasto+=1;
					strcat(newbuffer,"}");
					// fin foreach
				} else if ( cgi_exists_var(tag,*vars,*nvars) ) { // sustitucion de variable
					cgi_var *v = cgi_get_variable(tag,*vars,*nvars);
					if ( v ) { // asigno variable
						// agrego valor de esta variable en newbuffer
						gasto+=strlen(v->value);
						if ( gasto > largo ) { 
							largo+=1024;newbuffer = (char *) realloc(newbuffer,largo);
							if (!newbuffer) return NULL;
						}
						strcat(newbuffer,v->value);
					}
				}

				// preparo variables para continuar ciclo
				pdesde=p+2+1+strlen(tag); // sumo 2 por #{ y 1 por }
				
				// libero tag
				if ( tag ) free(tag);
			}
			// agrego la ultima parte de buffer en newbuffer
			n=strlen(pdesde); // cantidad de bytes desde pdesde hasta el final de buffer
			gasto+=n;
			if ( gasto > largo ) { 
				largo+=1024;newbuffer = (char *) realloc(newbuffer,largo);
				if (!newbuffer) return NULL;
			}
			strcat(newbuffer,pdesde);
			
			free(buffer);
			
			return newbuffer;
		} // no pude asignar memoria newbuffer
		
		free(buffer);
	} // error en carga de archivo / asignacion de memoria
	return NULL; 
}


/** 
 * Carga archivo de texto en memoria y lo devuelve como cadena de caracteres 
 * 
 * 
 * <br>Ejemplo de uso: @code {.c}
	char *buffer = *cgi_load_file("/tmp/myfile");
	...
	if ( buffer ) free(buffer);
 * @endcode
 * 
 * @return devuelve contenido de archivo en forma de cadena de caracteres
 *         devuelve NULL en caso de error en la asignacion dinamica de memoria o
 *         en apertura o lectura del archivo
 * @warning se asume que filename es un archivo de texto (no binario)
 * @author Guillermo Cherencio
 **/
char *cgi_load_file(char *filename) {
	long largo;
	char *buffer;
	FILE *fp = fopen(filename,"r");
	if ( fp != NULL ) {
		fseek(fp,0L,SEEK_END);
		largo = ftell(fp);
		buffer = (char *) malloc(largo+1);
		if ( buffer != NULL ) {
			memset(buffer,0,largo+1);
			fseek(fp,0L,SEEK_SET);
			fread(buffer,1,largo,fp);
			fclose(fp);
			return buffer;
		}
		fclose(fp);
	}
	return NULL;
}



// =====================================================================
// funciones para el manejo de variables cgi de programa
// =====================================================================


// 
// sin valor
/** 
 * Crea nueva variable, asigna dinamicamente nombre y estructura,
 * devuelve un puntero a su estructura
 * 
 * Luego de llamar a esta funcion, que, en definitiva, crea una nuevo
 * nodo (@see cgi_var )de variable, se puede utilizar la funcion cgi_add_new_var()
 * para agregarla al pool de variables del programa
 * 
 * <br>Ejemplo de uso: @code {.c}
...
  char *cgi_buffer = cgi_get_buffer();
  int cgi_n_vars;
  cgi_var *cgi_vars = cgi_get_vars(cgi_buffer,&cgi_n_vars); 
  
  // creo variable escalar cgi llamada "titulo"
  cgi_var *var1 = cgi_new_variable_type("titulo",'S');
  cgi_vars = cgi_add_new_var(cgi_vars,&cgi_n_vars,var1);
 
  // ahora titulo ya esta agregada al conjunto de variables cgi del programa y puede
  // ser sustituida dentro de un archivo .dhtml utilizando cgi_interpret_file()
... 
   @endcode
 * 
 * @param name nombre de variable cgi, que luego puede ser liberado de memoria (el mismo se
 * copia dentro del nodo variable). Si name es NULL, no hace nada y retorna NULL.
 * @param type tipo de variable ('S' escalar, 'A' no escalar)
 * @return devuelve nuevo nodo de variable cgi. El nuevo nodo se inicializa a nulos y luego
 * se carga el nombre y el tipo de la variable.
 *         devuelve NULL en caso de error en la asignacion dinamica de memoria o
 *         en apertura o lectura del archivo
 * @warning tanto la estructura como el nombre de la variable se asignan dinamicamente, con lo 
 * cual, luego habra que hacer el free() correspondiente
 * @author Guillermo Cherencio
 **/
cgi_var *cgi_new_variable_type(const char *name,char type) {
	if (name == NULL) return NULL;
	cgi_var *newvar = (cgi_var *) malloc(sizeof(cgi_var));
	if ( newvar != NULL ) {
		memset(newvar,0,sizeof(cgi_var));
		newvar->name = strdup(name);
		newvar->type = type;
		return newvar;
	}
	return NULL;
}

/** 
 * Crea nueva variable, asigna dinamicamente nombre, estructura y valor de la variable,
 * devuelve un puntero a su estructura
 * 
 * Luego de llamar a esta funcion, que, en definitiva, crea una nuevo
 * nodo (@see cgi_var )de variable, se puede utilizar la funcion cgi_add_new_var()
 * para agregarla al pool de variables del programa
 * 
 * <br>Ejemplo de uso: @code {.c}
...
  char *cgi_buffer = cgi_get_buffer();
  int cgi_n_vars;
  cgi_var *cgi_vars = cgi_get_vars(cgi_buffer,&cgi_n_vars); 
  
  // creo variable escalar cgi llamada "titulo"
  cgi_var *var1 = cgi_new_variable_type_value("titulo",'S',"Prueba Libcgi v1.0");
  cgi_vars = cgi_add_new_var(cgi_vars,&cgi_n_vars,var1);
 
  // ahora titulo ya esta agregada al conjunto de variables cgi del programa y puede
  // ser sustituida dentro de un archivo .dhtml utilizando cgi_interpret_file()
... 
   @endcode
 * 
 * @param name nombre de variable cgi, que luego puede ser liberado de memoria (el mismo se
 * copia dentro del nodo variable). Si name es NULL, no hace nada y retorna NULL.
 * @param type tipo de variable ('S' escalar, 'A' no escalar)
 * @param value valor de la variable (siempre es una cadena de caracteres)
 * @return devuelve nuevo nodo de variable cgi. El nuevo nodo se inicializa a nulos y luego
 * se carga el nombre y el tipo de la variable.
 *         devuelve NULL en caso de error en la asignacion dinamica de memoria o
 *         en apertura o lectura del archivo
 * @warning tanto la estructura como el nombre de la variable y su valor se asignan dinamicamente, con lo 
 * cual, luego habra que hacer el free() correspondiente
 * @author Guillermo Cherencio
 **/
cgi_var *cgi_new_variable_type_value(const char *name,char type,const char *value) {
	cgi_var *newvar = (cgi_var *) malloc(sizeof(cgi_var));
	if ( newvar != NULL ) {
		memset(newvar,0,sizeof(cgi_var));
		newvar->name = strdup(name);
		newvar->type = type;
		newvar->value = strdup(value);
		return newvar;
	}
	return NULL;
}

/** 
 * Crea nueva variable, asigna dinamicamente nombre y estructura ,
 * devuelve un puntero a su estructura
 * 
 * Luego de llamar a esta funcion, que, en definitiva, crea una nuevo
 * nodo (@see cgi_var )de variable, se puede utilizar la funcion cgi_add_new_var()
 * para agregarla al pool de variables del programa
 * 
 * <br>Ejemplo de uso: @code {.c}
...
  char *cgi_buffer = cgi_get_buffer();
  int cgi_n_vars;
  cgi_var *cgi_vars = cgi_get_vars(cgi_buffer,&cgi_n_vars); 
  
  // creo variable escalar cgi llamada "titulo"
  cgi_var *var1 = cgi_new_variable("titulo");
  cgi_vars = cgi_add_new_var(cgi_vars,&cgi_n_vars,var1);
 
  // ahora titulo ya esta agregada al conjunto de variables cgi del programa y puede
  // ser sustituida dentro de un archivo .dhtml utilizando cgi_interpret_file()
... 
   @endcode
 * 
 * @param name nombre de variable cgi, que luego puede ser liberado de memoria (el mismo se
 * copia dentro del nodo variable). Si name es NULL, no hace nada y retorna NULL. Se asume 
 * que la variable es de tipo escalar (type = 'S') y sin valor (value = NULL )
 * @return devuelve nuevo nodo de variable cgi. El nuevo nodo se inicializa a nulos y luego
 * se carga el nombre y el tipo de la variable.
 *         devuelve NULL en caso de error en la asignacion dinamica de memoria o
 *         en apertura o lectura del archivo
 * @warning tanto la estructura como el nombre de la variable se asignan dinamicamente, con lo 
 * cual, luego habra que hacer el free() correspondiente
 * @author Guillermo Cherencio
 **/
cgi_var *cgi_new_variable(const char *name) {
	return cgi_new_variable_type(name,'S');
}

/** 
 * Establece el valor de una variable previamente creada
 * 
 * Luego de llamar a esta funcion, la variable representada por el nodo que se pasa
 * como argumento, queda con el valor indicado en el segundo argumento
 * 
 * <br>Ejemplo de uso: @code {.c}
...
  char *cgi_buffer = cgi_get_buffer();
  int cgi_n_vars;
  cgi_var *cgi_vars = cgi_get_vars(cgi_buffer,&cgi_n_vars); 
  
  // creo variable escalar cgi llamada "titulo"
  cgi_var *var1 = cgi_new_variable("titulo");
  cgi_set_variable(var1,"Prueba Libcgi v1.0");
  cgi_vars = cgi_add_new_var(cgi_vars,&cgi_n_vars,var1);
 
  // ahora titulo ya esta agregada al conjunto de variables cgi del programa y puede
  // ser sustituida dentro de un archivo .dhtml utilizando cgi_interpret_file()
... 
   @endcode
 * 
 * @param name nombre de variable cgi, que luego puede ser liberado de memoria (el mismo se
 * copia dentro del nodo variable). Si name es NULL, no hace nada y retorna NULL. Se asume 
 * que la variable es de tipo escalar (type = 'S') y sin valor (value = NULL )
 * @param value valor de la variable. Recuerde que se asigna dicho valor en forma dinamica, con lo
 * cual luego requerira el free() correspondiente.
 * @return none
 * @warning el valor de la variable se asignan dinamicamente, con lo 
 * cual, luego habra que hacer el free() correspondiente
 * @author Guillermo Cherencio
 **/
void cgi_set_variable(cgi_var *var,char *value) {
	if ( var != NULL ) {
		if ( var->value != NULL ) free(var->value);
		var->value = strdup(value);
		var->type = 'S';
	}
}

/** 
 * Agrega un nuevo valor a una variable no escalar
 * 
 * Luego de llamar a esta funcion, la variable representada por el nodo que se pasa
 * como argumento, quedara asociada con este valor (ademas de los otros valores que
 * previamente tuviera asociado). Actualmente no se estan usando las variables no escalares. 
 * No obstante, la libreria cgi cuenta con funciones para manipular variables no escalares.
 * 
 * 
 * @param var puntero a nodo que describre una variable no escalar (variable que tiene asociado
 * multiples valores)
 * @param value valor de la variable. Recuerde que se asigna dicho valor en forma dinamica, con lo
 * cual luego requerira el free() correspondiente.
 * @return none
 * @warning el valor de la variable se asignan dinamicamente, con lo 
 * cual, luego habra que hacer el free() correspondiente.
 * @author Guillermo Cherencio
 **/
void cgi_add_value(cgi_var *var,const char *value) {
	if ( var != NULL ) {
		cgi_var_value *v = (cgi_var_value *) malloc(sizeof(cgi_var_value));
		if ( v != NULL ) {
			memset(v,0,sizeof(cgi_var_value));
			v->value = strdup(value);
			var->type = 'A';
			if ( var->first_value == NULL ) { // primer valor aun no cargado
				var->first_value = v;
				var->last_value = v;
			} else { // hay al menos un valor cargado
				var->last_value->next = v;
				var->last_value = v;
			}
		}
	}
}

/** 
 * Libera memoria asociada a una variable (ya sea escalar o no escalar)
 * 
 * Luego de llamar a esta funcion, se libera la memoria que se asigno previamente
 * en forma dinamica asociado con esta variable (ya sea escalar o no escalar)
 * 
 * 
 * @param var puntero a nodo que describre una variable escalar o no escalar
 * @return none
 * @warning el valor de la variable se libera y queda con valor = NULL. El nodo variable
 * continua teniendo su memoria asignada (el nodo en si no se libera, solo libera sus valores).
 * @author Guillermo Cherencio
 **/
void cgi_free_variable(cgi_var *var) {
	if ( var != NULL ) {
		if ( var->name  != NULL ) free(var->name);
		var->name = NULL;
		if ( var->type == 'S' ) { // libero escalar
			if ( var->value != NULL ) free(var->value);
			var->value = NULL;
		} else { // libero no escalar
			cgi_var_value *v = var->first_value;
			cgi_var_value *tmp;
			while(v) {
				if ( v->value != NULL ) free(v->value);
				tmp = v->next;
				free(v);
				v = tmp;
			}
			if ( var->value != NULL ) free(var->value);
			var->value = NULL;
			var->first_value = NULL;
			var->last_value = NULL;
		}
		var->type = ' ';
	}
}

/** 
 * Libera memoria asociada a n variables (ya sea escalar o no escalar)
 * 
 * Luego de llamar a esta funcion, se libera la memoria que se asigno previamente
 * en forma dinamica asociado con estas variables (ya sea escalar o no escalar)
 * 
 * 
 * @param var puntero a nodo que describre nvars variables escalares o no escalares, apunta a un area
 * de memoria contigua en donde se encuentran nvars nodos de tipo cgi_var
 * @param nvars numero entero que indica la cantidad de nodos variables apuntados a partir de var
 * @return none
 * @warning el valor de la variable se libera y queda con valor = NULL. Los nodos variables
 * continuan teniendo su memoria asignada (el nodo en si no se libera, solo libera sus valores).
 * @author Guillermo Cherencio
 **/
void cgi_free_variables(cgi_var *var,int nvars) {
	int n;
	for(n=0;n<nvars;n++,var++) cgi_free_variable(var);
}


/** 
 * Asigna una variable a partir de un buffer de memoria que contiene una serie de variables cgi
 * 
 * src es un puntero a un area de memoria que contiene una serie de variables cgi, esta funcion
 * lo que hace es analizar dicho buffer y asignar a la variable var el valor que se encuentra en el
 * buffer (en forma dinamica)
 * en forma dinamica asociado con estas variables (ya sea escalar o no escalar)
 * 
 * @param src puntero a un area de memoria que contiene una serie de variables cgi
 * con el formato:<br>@code
 * 
 *    variable1=valor1&variable2=valor2&....
 * 
 * @endcode
 * @param var puntero a nodo que describre una variable, la cual, de ser posible, sera asignada con
 * el valor contenido en buffer src
 * @return none
 * @author Guillermo Cherencio
 **/
void cgi_get_var_cgi(char *src,cgi_var *var) {
	if ( var != NULL ) {
		if ( var->name != NULL ) {
			char mivar1[strlen(var->name)+5];
			char mivar2[strlen(var->name)+5];
			strcpy(mivar1,"&");
			strcat(mivar1,var->name);
			strcat(mivar1,"=");
			strcpy(mivar2,var->name);
			strcat(mivar2,"=");
			int largo = 128;
			char *dest = (char *) malloc(largo);
			if ( dest != NULL ) {
				memset(dest,0,largo);
				int desplazo = strlen(mivar1);
				char *pos = strcasestr(src,mivar1); // busco &variable=
				if ( pos == NULL ) {
					pos = strcasestr(src,mivar2); // busco variable=
					desplazo = strlen(mivar2);
				}
				if ( pos != NULL ) { // algo encontre!
					int n=0;
					pos+=desplazo;
					char *odest = dest; // guardo direccion original destino
					// copio el valor de la variable en dest
					while ( *pos != '\0' && *pos != '&' ) {
						*dest = *pos;
						n++;dest++;pos++;
						if ( n >= largo ) { // se lleno buffer
							largo+=128;
							odest = (char *) realloc(odest,largo); // asume que reasigna Ok!
							if ( odest != NULL ) {
								memset(odest+n,0,largo-n);
								dest = odest+n;
							} else break;
						}
					}
					var->value = odest;
					var->type = 'S';
					var->first_value = NULL;
					var->last_value = NULL;
				} // si no encuentro nada, no copio nada
			} // error en asignacion de memoria, no hago nada
		}
	}
}


/** 
 * Cuenta la cantidad de variables que hay en un buffer de memoria que contiene una serie de variables cgi
 * 
 * src es un puntero a un area de memoria que contiene una serie de variables cgi, esta funcion
 * lo que hace es analizar dicho buffer y determinar la cantidad de variables cgi que hay en dicho buffer
 * 
 * @param src puntero a un area de memoria que contiene una serie de variables cgi
 * con el formato:<br>@code
 * 
 *    variable1=valor1&variable2=valor2&....
 * 
 * @endcode
 * @return int que indica la cantidad de variables que hay en el buffer
 * @author Guillermo Cherencio
 **/
int cgi_count_var(char *src) {
	int n=0;
	while(*src) { if ( *src == '=' ) n++; src++; }
	return n;
}

/** 
 * Obtiene el nombre de la i-esima variable dentro de src
 * 
 * src es un puntero a un area de memoria que contiene una serie de variables cgi, esta funcion
 * lo que hace es analizar dicho buffer y devolver (en forma dinamica) el nombre de la i-esima variable
 * contenida en el buffer src
 * 
 * @param src puntero a un area de memoria que contiene una serie de variables cgi
 * con el formato:<br>@code
 * 
 *    variable1=valor1&variable2=valor2&....
 * 
 * @endcode
 * @param nvar numero que indica la i-esima variable (0 .. n-1) dentro del buffer src de la
 * cual se pretende obtener el nombre
 * @return nombre de la i-esima variable dentro de src o NULL en caso de que no se encuentre o bien
 * ocurra algun error
 * @author Guillermo Cherencio
 **/
char *cgi_get_var_name(char *src,int nvar) {
	int n = cgi_count_var(src);
	if ( nvar >= 0 && nvar < n ) { // numero correcto de variable
		char *desde = src, *hasta = src;
		n=-1;
		while(*src && n < nvar) { // busco comienzo y fin de la variable
			if ( *src == '=' ) { hasta = src;n++; }
			if ( *src == '&' ) desde = src;
			src++;
		}
		if ( n == nvar ) { // encontre variable nvar
			int largo = hasta - desde;
			char *varname = (char *) malloc(largo+1);
			if ( varname != NULL ) {
				memset(varname,0,largo+1);
				if ( *desde == '&' ) strncpy(varname,desde+1,largo-1);
				else                 strncpy(varname,desde,largo);
				return varname;
			}
		}
	}
	return NULL;
}

/** 
 * Obtiene el valor de la i-esima variable dentro de src
 * 
 * src es un puntero a un area de memoria que contiene una serie de variables cgi, esta funcion
 * lo que hace es analizar dicho buffer y devolver (en forma dinamica) el valor de la i-esima variable
 * contenida en el buffer src
 * 
 * @param src puntero a un area de memoria que contiene una serie de variables cgi
 * con el formato:<br>@code
 * 
 *    variable1=valor1&variable2=valor2&....
 * 
 * @endcode
 * @param nvar numero que indica la i-esima variable (0 .. n-1) dentro del buffer src de la
 * cual se pretende obtener el valor
 * @return valor de la i-esima variable dentro de src o NULL en caso de que no se encuentre o bien
 * ocurra algun error
 * @author Guillermo Cherencio
 **/
char *cgi_get_var_value(char *src,int nvar) {
	int n = cgi_count_var(src);
	if ( nvar >= 0 && nvar < n ) { // numero correcto de variable
		char *desde = src, *hasta = src;
		n=-1;
		while(*src && n <= nvar) { // busco comienzo y fin del valor de la variable
			if ( *src == '=' ) { desde = src;n++; }
			if ( *src == '&' ) { hasta = src; if ( n == nvar ) break; }
			src++;
		}
		if ( *src == '\0' ) hasta = src;
		if ( n == nvar ) { // encontre variable nvar
			int largo = hasta - desde - 1;
			char *varvalue = (char *) malloc(largo+1);
			if ( varvalue != NULL ) {
				memset(varvalue,0,largo+1);
				strncpy(varvalue,desde+1,largo);
				return varvalue;
			}
		}
	}
	return NULL;
}

/** 
 * Obtiene un conjunto de variables a partir del buffer de variables cgi src
 * 
 * src es un puntero a un area de memoria que contiene una serie de variables cgi, esta funcion
 * lo que hace es analizar dicho buffer y devolver (en forma dinamica) un puntero a un conjunto 
 * de nodos de variables
 * 
 * @param src puntero a un area de memoria que contiene una serie de variables cgi
 * con el formato:<br>@code
 * 
 *    variable1=valor1&variable2=valor2&....
 * 
 * @endcode
 * @param nvars puntero a int en donde se almacena la cantidad de variables que se encontraron
 * y se asignaron acorde con el contenido de src
 * @return puntero de tipo cgi_var * de memoria contigua de arreglo de nvars variables
 * @author Guillermo Cherencio
 **/
cgi_var *cgi_get_vars(char *src,int *nvars) {
	*nvars = cgi_count_var(src);
	if ( *nvars > 0 ) {
		cgi_var *p = (cgi_var *) malloc(sizeof(cgi_var)*(*nvars));
		if ( p != NULL ) {
			cgi_var *op = p;
			memset(p,0,sizeof(cgi_var)*(*nvars));
			int n;
			for(n=0;n<(*nvars);n++,p++) {
				p->name = cgi_get_var_name(src,n);
				p->type = 'S';
				p->value = cgi_get_var_value(src,n);
			}
			return op;
		}
	}
	return NULL;
}

/** 
 * Imprime (por stdout) una tabla html con todas las variables y sus valores apuntados por var
 * 
 * Imprime (por stdout) una tabla html con todas las variables y sus valores apuntados por var
 * 
 * @param vars puntero a nvars nodos variables que seran impresos en tabla html
 * @param nvars numero que indica la cantidad de variables apuntadas a partir de vars
 * @return none
 * @author Guillermo Cherencio
 **/
void cgi_print_vars(cgi_var *var,int nvars) {
	if ( var != NULL && nvars > 0 ) {
		int table_size = 1024,gasto=0,n;
		char *table = (char *) malloc(table_size);
		if ( table != NULL ) {
			strcpy(table,"<table border=1>\n<tr><td colspan=2><center>Variables</center></td></tr>\n<tr><td>Nombre</td><td>Valor</td></tr>\n");
			gasto+=120;
			for(n=0;n<nvars;n++,var++) {
				strcat(table,"<tr><td>");
				gasto+=8;
				if ( var->name != NULL ) strcat(table,var->name);
				if ( var->name != NULL ) gasto+=strlen(var->name);
				strcat(table,"</td><td>");
				gasto+=9;
				if ( var->value != NULL ) strcat(table,var->value);
				if ( var->value != NULL ) gasto+=strlen(var->value);
				strcat(table,"</td></tr>\n");
				gasto+=11;
				if ( (gasto+128) > table_size ) {
					table_size+=1024;
					table = (char *) realloc(table,table_size);
					if ( table == NULL ) return;
				}
			}
			strcat(table,"</table>\n");
			printf(table);
			free(table);
		}
	}
}

/** 
 * Esta funcion agrega una nueva variable a un pool de variables cgi contiguas
 * apuntadas a partir de vars
 * 
 * Esta funcion agrega una nueva variable a un pool de variables
 * que se encuentra en forma contigua en la memoria
 * Actualiza el valor del total de variables y devuelve el puntero
 * a la nueva ubicacion del pool de variables que incluye a la nueva
 * variable al final del mismo
 * En caso de error de asignacion de memoria, devuelve el pool original
 * y no actualiza nada
 * 
 * @param vars puntero a nvars nodos de variables cgi
 * @param nvars puntero a int en donde se almacena la cantidad de variables que contiene
 * el pool de variables
 * @param newvar puntero a nuevo nodo var a ser agregado al pool de variables contiguas
 * @return puntero de tipo cgi_var * de memoria contigua de arreglo de nvars variables, con la nueva
 * variable agregada al final del mismo
 * @warning Libera el espacio de memoria de la variable agregada newvar la cual se encontrara 
 * al final del pool de variables
 * @author Guillermo Cherencio
 **/
cgi_var *cgi_add_new_var(cgi_var *vars,int *nvars,cgi_var *newvar) {
	if ( vars != NULL && *nvars > 0 ) {
		cgi_var *ovars = vars;
		vars = (cgi_var *) realloc(vars,sizeof(cgi_var)*((*nvars)+1));
		if ( vars != NULL ) {
			*nvars=(*nvars)+1;
			memcpy(vars+((*nvars)-1),newvar,sizeof(cgi_var));
			free(newvar);
			return vars;
		} else return ovars;
	}
	return vars;
}

/** 
 * Esta funcion verifica si existe una variable
 * 
 * Esta funcion devuelve verdad si varname existe dentro del pool de
 * variables apuntado por vars y de nvars nodos
 * 
 * @param varname nombre de la variable a buscar
 * @param vars puntero a nvars nodos de variables cgi
 * @param nvars puntero a int en donde se almacena la cantidad de variables que contiene
 * el pool de variables
 * @return true si la variable existe, caso contrario, false
 * @author Guillermo Cherencio
 **/
int cgi_exists_var(char *varname,cgi_var *vars,int nvars) {
	if ( vars != NULL && nvars > 0 ) {
		int n;
		for(n=0;n<nvars;n++,vars++) {
			if ( strcasecmp(vars->name,varname) == 0 ) return 1;
		}
	}
	return 0;
}

/** 
 * Esta funcion devuelve un puntero a un nodo de variable cgi a partir de su nombre
 * 
 * Esta funcion devuelve un puntero al nodo de la variable varname en caso de que la misma
 * exista dentro del pool de variables vars, caso contrario devuelve NULL
 * 
 * @param varname nombre de la variable a buscar
 * @param vars puntero a nvars nodos de variables cgi
 * @param nvars cantidad de variables que contiene
 * el pool de variables
 * @return puntero al nodo i-esimo en donde se encuentra varname, caso contrario,
 * devuelve NULL
 * @author Guillermo Cherencio
 **/
cgi_var *cgi_get_variable(char *varname,cgi_var *vars,int nvars) {
	if ( cgi_exists_var(varname,vars,nvars) ) {
		int n;
		for(n=0;n<nvars;n++,vars++) {
			if ( strcasecmp(vars->name,varname) == 0 ) return vars;
		}
	}
	return NULL;
}

/** 
 * Esta funcion reasigna memoria, ampliando orig en CGI_MIN_BUFFER_SIZE bytes mas
 *  
 * Esta funcion devuelve un puntero a la nueva area de memoria asignada o bien al area de 
 * memoria original si hubo algun error de asignacion. El nuevo espacio ampliado del buffer
 * se inicializa a nulos.
 * 
 * @param orig comienzo de area de memoria actual
 * @param current_position posicion actual dentro del buffer (a partir del cual, el nuevo
 * buffer se inicializa con nulos)
 * @param current_size tamaño actual del buffer apuntado por orig y que se pretende ampliar
 * @param ret puntero a int que almacenara un codigo de retorno (0 o 1) dependiendo como se realizo
 * la operacion de reasignacion
 * @return puntero a la nueva area de memoria reasignada. 
 * ret vale 0 si hubo error en asignacion de memoria y se devuelve buffer original
 * ret vale 1 si todo ok y se devuelve el nuevo buffer
 * @author Guillermo Cherencio
 **/
char    *cgi_realloc(char *orig,long current_position,long current_size,int *ret) {
	return cgi_realloc_size(orig,current_position,current_size,current_size+CGI_MIN_BUFFER_SIZE,ret);
}

/** 
 * Esta funcion reasigna memoria, ampliando orig a new_size bytes
 *  
 * Esta funcion devuelve un puntero a la nueva area de memoria asignada o bien al area de 
 * memoria original si hubo algun error de asignacion. El nuevo espacio ampliado del buffer
 * se inicializa a nulos.
 * 
 * @param orig comienzo de area de memoria actual
 * @param current_position posicion actual dentro del buffer (a partir del cual, el nuevo
 * buffer se inicializa con nulos)
 * @param current_size tamaño actual del buffer apuntado por orig y que se pretende ampliar
 * @param new_size nuevo tamaño del buffer apuntado por orig
 * @param ret puntero a int que almacenara un codigo de retorno (0 o 1) dependiendo como se realizo
 * la operacion de reasignacion
 * @return puntero a la nueva area de memoria reasignada. 
 * ret vale 0 si hubo error en asignacion de memoria y se devuelve buffer original
 * ret vale 1 si todo ok y se devuelve el nuevo buffer
 * @author Guillermo Cherencio
 **/
char    *cgi_realloc_size(char *orig,long current_position,long current_size,long newsize,int *ret) {
	char *neworig = (char *) realloc(orig,newsize);
	if ( neworig == NULL ) { // error en re-asignacion
		// devuelvo buffer original
		*ret=0;
		return orig;
	} else { // re-asigno buffer ok
		*ret=1;
		memset(neworig,0,newsize-current_position);
		return neworig;
	}
}

/** 
 * Esta funcion busca search dentro de buffer y lo reemplaza por replace
 *  
 * Esta funcion busca search dentro de buffer y lo reemplaza por replace,
 * devuelve un nuevo buffer asignado dinamicamente, si hay error en la asignacion
 *  de memoria devuelve NULL,si no existe search devuelve una copia de buffer
 * 
 * @param buffer comienzo de area de memoria a partir de la cual inicia la busqueda
 * @param search cadena de caracteres a buscar dentro de buffer
 * @param replace cadena de caracteres por la cual se reemplaza 
 * @return nueva area de memoria (copia de buffer) en donde se hizo la busqueda y reemplazo.
 * @warning la busqueda es case-insensitive, solo busca y reemplaza la primera ocurrencia de 
 * search dentro de buffer
 * @author Guillermo Cherencio
 **/
char *cgi_search_and_replace(char *buffer, char *search, char *replace)
{
  char *p;
  if(!(p = strcasestr(buffer, search))) return strdup(buffer);
  char *newbuffer = (char *) malloc(strlen(buffer)-strlen(search)+strlen(replace)+5);
  if ( newbuffer != NULL ) {
	  strncpy(newbuffer, buffer, p-buffer); 
	  sprintf(newbuffer+(p-buffer), "%s%s", replace, p+strlen(search));
  }
  return newbuffer;
}

/** 
 * Esta funcion genera una serie de table rows (html, tag tr) a partir del resultado
 * de un query asociado con la variable var (var->query)
 *  
 * Esta funcion tiene cierta complejidad, pues a partir de un query (var-query) genera
 * un table row por cada tupla del query, tambien realiza sustitucion de variables ($variable) y
 * sustitucion de $row por el numero de fila correspondiente del query que se esta procesando.
 * Los flags create_title (true -> crear fila con los nombres de las columnas del query, false ->
 * no crear fila adicional de titulos), create_footer (true -> crear fila adicional con la cantidad
 * de filas y columnas procesadas, false -> no agrega fila al final) permiten cambiar el comportamiento
 * de este generador de filas de tabla html.
 * El buffer html apunta a un codigo html que se agregara a cada fila table html generada justo antes de
 * cerrar el tag tr, se permite hacer sustitucion de variables dentro del mismo.
 * 
 *  
 * @param vars puntero a puntero de pool de variables cgi
 * @param nvars puntero a la cantidad de variables apuntadas por vars
 * @param var variable que tiene un query sql asociado y ya resuelto, cargo en var->query, a partir
 * del cual se van a recuperar todas sus filas y columnas y se va a generar las filas de la tabla html
 * @param create_title flag que indica si se agrega titulo de columnas o no
 * @param create_footer flag que indica si se agrega fila al final de la tabla indicando la cantidad
 * de filas y columnas procesadas 
 * @param html buffer html que apunta a codigo html a ser agregado al final de cada fila, permite hacer
 * sustitucion dentro de dicho buffer (que sera de solo lectura para esta funcion), su sustitucion se 
 * copia en el nuevo buffer que retorna la funcion
 * @return nuevo buffer asignado dinamicamente con una serie de table row html generadas o bien NULL si 
 * hay algun error
 * @author Guillermo Cherencio
 **/
char    *cgi_create_tr(cgi_var **vars,int *nvars,cgi_var *var,int create_title,int create_footer,char *html) {
	if ( var->qry ) {
		int n,i;
		query *q = (query *) var->qry;
		struct rquery *r = q->top;
		char **cols = (char **) q->colname;
		long largo=4096L;
		char *buffer = (char *) malloc(largo);
		long gasto=0L;
		if ( buffer ) {
			memset(buffer,0,largo);
			if ( create_title ) {
				strcat(buffer,"<tr>");
				gasto+=4;
				for(i=0;i<q->cols;i++) {
					strcat(buffer,"<td>");
					strcat(buffer,*(cols+i));
					strcat(buffer,"</td>");
					gasto+=10+strlen(*(cols+i));
				}
				strcat(buffer,"</tr>");
				gasto+=5;
			}
			for(n=0;n<q->rows;n++) {
				strcat(buffer,"<tr>");
				gasto+=4;
				char **fld = (char **) r->col;
				for(i=0;i<q->cols;i++) {
					strcat(buffer,"<td>");
					strcat(buffer,*(fld+i));
					strcat(buffer,"</td>");
					gasto+=10+strlen(*(fld+i));
				}
				if ( html ) {
					char *h;
					int sustituyo=0;
					if ( strstr(html,"$") ) { // hay sustitucion
						sustituyo=1;
						char *oldhtml,*newhtml;
						newhtml = strdup(html);
						// sustituyo valores de la fila actual del query
						for(i=0;i<q->cols && strstr(newhtml,"$");i++) {
							char campo[strlen(*(cols+i))+5];
							snprintf(campo,strlen(*(cols+i))+5,"$%s",*(cols+i));
							oldhtml = cgi_search_and_replace(newhtml,campo,*(fld+i));
							if ( newhtml ) free(newhtml);
							newhtml = oldhtml;
						}
						// sustituyo variable especial $row (contador de 0..nrows-1)
						if ( strcasestr(newhtml,"$row") ) {
							char nro[100];
							snprintf(nro,100,"%d",n);
							oldhtml = cgi_search_and_replace(newhtml,"$row",nro);
							if ( newhtml ) free(newhtml);
							newhtml = oldhtml;
						}
						// sustituyo variables cgi
						if ( strstr(newhtml,"$") ) { //aun quedan sustituciones, pueden ser variables cgi
							cgi_var *v = *vars;
							for(i=0;i<*nvars && strstr(newhtml,"$");i++,v++) {
								char campo[strlen(v->name)+5];
								snprintf(campo,strlen(v->name)+5,"$%s",v->name);
								oldhtml = cgi_search_and_replace(newhtml,campo,v->value);
								if ( newhtml ) free(newhtml);
								newhtml = oldhtml;
							}
						}
						gasto+=strlen(newhtml);
						h = newhtml;
					} else {
						gasto+=strlen(html);
						h = html;
					}
					if ( (gasto+150) > largo ) { // necesito mas memoria
						char *obuffer = buffer;
						largo+=1024;
						buffer = (char *) realloc(buffer,largo);
						if (!buffer) return obuffer;
					}
					strcat(buffer,h);
					if ( sustituyo ) if ( h ) free(h);
				}
				r = r->next;
				strcat(buffer,"</tr>");
				gasto+=5;
				if ( (gasto+150) > largo ) { // necesito mas memoria
					char *obuffer = buffer;
					largo+=1024;
					buffer = (char *) realloc(buffer,largo);
					if (!buffer) return obuffer;
				}
			}
			if ( create_footer ) {
				char tmp[150];
				snprintf(tmp,150,"<tr><td colspan=%d>%d filas y %d columnas impresas</td></tr>",q->cols,q->rows,q->cols);
				strcat(buffer,tmp);
				gasto+=strlen(tmp);
			}
			return buffer;
		}
	}
	return NULL;
}

/** 
 * Esta funcion devuelve un substring de buffer que se ubica entre search1 y search2
 *  
 * Esta funcion devuelve un substring de buffer que se ubica entre search1 y search2
 * si no existe search1 devuelve NULL
 * si no existe search2 devuelve NULL
 * si search1 no esta antes que search2 devuelve NULL
 * si no puedo asignar memoria devuelvo NULL
 * sino devuelve substring asignado dinamicamente
 * 
 * @param buffer comienzo de area de memoria a partir de la cual inicia la busqueda
 * @param search1 cadena de caracteres a buscar dentro de buffer
 * @param search2 segunda cadena de caracteres a partir de la cual se busca en buffer y que 
 * se supone, la misma se encuentra luego de search1 
 * @return nueva area de memoria (copia de buffer) que se encuentra entre search1 y search2.
 * O bien NULL si hubo algun error
 * @warning la busqueda es case-insensitive
 * @author Guillermo Cherencio
 **/
char *cgi_substring(char *buffer,char *search1,char *search2) {
	char *p1,*p2;
	if ( (p1=strcasestr(buffer,search1)) && (p2=strcasestr(p1,search2)) ) {
		long size = p2-p1-strlen(search1)+1;
		char *newbuffer = (char *) malloc(size);
		if ( newbuffer ) {
			memset(newbuffer,0,size);
			if ( size > 1 ) strncpy(newbuffer,p1+strlen(search1),size-1);
//char tmp[4096];
//snprintf(tmp,4096,"cgi_substring buffer=[%s] s1=[%s] s2=[%s] substr=[%s]",buffer,search1,search2,newbuffer);
//cgi_log("cgi7",tmp);			
			return newbuffer;
		}
	}
	return NULL;
}

/** 
 * Esta funcion es similar a cgi_substring() pero solo retorna substring desde el comienzo de buffer
 * hasta encontrar search1
 * 
 * Esta funcion es similar a cgi_substring() pero solo retorna substring desde el comienzo de buffer
 * hasta encontrar search1
 * devuelvo un substring de buffer que se ubica desde el comienzo de buffer hasta search1
 * si no existe search1 devuelve NULL
 * si no puedo asignar memoria devuelvo NULL
 * sino devuelve substring asignado dinamicamente
 * 
 * @param buffer comienzo de area de memoria a partir de la cual inicia la busqueda
 * @param search1 cadena de caracteres a buscar dentro de buffer
 * @return nueva area de memoria (copia de buffer) que se encuentra entre buffer y search1.
 * O bien NULL si hubo algun error
 * @warning la busqueda es case-insensitive
 * @author Guillermo Cherencio
 **/
char    *cgi_substring_upto(char *buffer,char *search1) {
	char *p1;
	if ( (p1=strcasestr(buffer,search1)) ) {
		long size = p1-buffer+1;
		char *newbuffer = (char *) malloc(size);
		if ( newbuffer ) {
			memset(newbuffer,0,size);
			if ( size > 1 ) strncpy(newbuffer,buffer,size-1);
//char tmp[4096];
//snprintf(tmp,4096,"cgi_substring_upto str=[%s] search=[%s] substr=[%s]",buffer,search1,newbuffer);
//cgi_log("cgi7",tmp);			
			return newbuffer;
		}
	}
	return NULL;
}

/** 
 * Esta funcion es similar a cgi_substring() pero solo retorna substring desde el comienzo de search1
 * hasta encontrar el final de buffer
 * 
 * Esta funcion es similar a cgi_substring() pero solo retorna substring desde el comienzo de search1
 * hasta encontrar el final de buffer
 * devuelvo un substring de buffer que se ubica desde el comienzo de search1 hasta el final de buffer
 * si no existe search1 devuelve NULL
 * si no puedo asignar memoria devuelvo NULL
 * sino devuelve substring asignado dinamicamente
 * 
 * @param buffer comienzo de area de memoria a partir de la cual inicia la busqueda
 * @param search1 cadena de caracteres a buscar dentro de buffer
 * @return nueva area de memoria (copia de buffer) que se encuentra entre search1 y el final de buffer.
 * O bien NULL si hubo algun error
 * @warning la busqueda es case-insensitive
 * @author Guillermo Cherencio
 **/
char    *cgi_substring_toend(char *buffer,char *search1) {
	char *p1;
	if ( (p1=strcasestr(buffer,search1)) ) {
		long size = strlen(p1+strlen(search1))+1;
		char *newbuffer = (char *) malloc(size);
		if ( newbuffer ) {
			memset(newbuffer,0,size);
			if ( size > 1 ) strncpy(newbuffer,p1+strlen(search1),size-1);
//char tmp[4096];
//snprintf(tmp,4096,"cgi_substring_toend str=[%s] search=[%s] substr=[%s]",buffer,search1,newbuffer);
//cgi_log("cgi7",tmp);			
			return newbuffer;
		}
	}
	return NULL;
}
