/**
 * @file libcgi.h
 * Archivo de cabecera de libreria libcgi para la implementar programas
 * cgi
 *
 * Copyright 2012 grchere 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 * 
 * @author Guillermo Cherencio
 */
 /**
  *@mainpage 
  * <p>Bienvenidos a la documentacion de libcgi.
  * El objetivo de esta libreria es hacer su programacion cgi mas sencilla.
  * Esta libreria es dependiente de la libreria libfb que permite utilizar una 
  * base de datos Firebird SQL desde C en Linux.</p>
  * <p>La siguiente guia (para Linux Debian) le permitira armar un ambiente de trabajo posible para esta libreria.</p>
  *<ul> 
  * <li>1. Instalar/Verificar que cuenta con el software basico para trabajar<br>
  *       1. Tiene que tener instalado el paquete gcc, gcc-doc, build-essential, make<br>
  * @code
  * $ aptitude install gcc
  * $ aptitude install gcc-doc
  * $ aptitude install build-essential
  * $ aptitude install make
  * @endcode
  * </li>
  * <li>2. Instalar Firebird y FlameRobin<br>
  *  Seguir la guia <a href="http://www.grch.com.ar/docs/bd/tutorial/firebird/instalacion.firebird.2.5.pdf">Instalar Firebird 2.5</a><br>
  * NOTA: Si Ud. va a utilizar un servidor Firebird fuera de su maquina, simplemente puede instalar la libreria fbclient<br>
  * para poder conectarse a un servidor Firebird (esta libreria se instala automaticamente cuando instala el servidor)<br>
  * tambien asegurese de tener instalado el paquete firebirdX.X-dev (reemplace las X por la version firebird,<br>
  * este paquete instala ibase.h necesario para compilar libfb)<br>
  * @code
  * $ aptitude install fbclient
  * @endcode
  * </li>
  * <li>3. Instalar Base de Datos ISFT (o cualquier otra con la cual quiera trabajar)<br>
  *    1. Obtener la ultima version del archivo isft.fdb (hay una copia dentro de la
  * carpeta /libfb/examples) <br>
  *    2. Estando logeado como root, copiar isft.fdb a carpeta /var/lib/firebird/2.5/data<br>
  *    3. Cambiar el owner del archivo isft.fdb:<br>
  * @code
  *  $ chown firebird:firebird /var/lib/firebird/2.5/data/isft.fdb
  * @endcode
  *    4. Utilizar FlameRobin y conectar la base de datos, utilizando el usuario sysdba clave masterkey<br>
  *  rol sysdb server localhost (si esta instalado en su maquina, sino indicar nombre o direccion ip<br>
  * del mismo). Navegar por los distintos objetos de la base de datos y probar que funcione Ok.<br>
  *   </li>
  * <li>4. Instalar Mongoose<br>
   1. Descargar server de http://code.google.com/p/mongoose/<br>
   2. Descomprimir archivo .tar.gz descargado<br>
   3. Como root, en la carpeta en donde se descomprimio servidor, ejecutar:<br>
   * @code
   $ make linux
   * @endcode
   4. Verificar que se haya creado el ejecutable mongoose<br>
Ejecutar servidor (en este caso para que reconozca al programa cgi1 como un cgi):<br>
* @code
   $ ./mongoose -C "./cgi**"* 
  @endcode
Deberia ver un mensaje similar a este:<br>
* @code
$ ./mongoose -C "./cgi**"
* @endcode
Mongoose web server v. 3.1 started on port(s) 8080 with web root [.]<br>
  * </li>
  * <li>5. Obtener libfb<br>
  *   1. descargar los archivos *.c *.h Makefile desde https://sourceforge.net/projects/libfb/files  <br>
  * o bien descargar archivo libfb.zip y descomprimirlo (crea carpetas libfb y libcgi con todos los archivos)  <br>
  * </li>
  * <li>6. Compilar librerias<br>
  *    1. En directorio libfb (o bien en donde haya descargado los archivos *.c *.h Makefile)<br>
  * tipee el siguiente comando (utilizando usuario root):<br>
  * @code
  * $ make
  * @endcode
  * Luego compruebe que los archivos libfb.a y libcgi.a hayan sido creados, ahora esta listo para utilizar<br>
  * estas librerias.<br>
  * </li>
  * <li>7. Hacer programa de prueba<br>
  * </li>
  * <li>8. Verificar que todos los servidores estan ejecutandose:<br>
  * @code
$ ps ax | grep "mong"
 5562 pts/3    Sl+    0:00 ./mongoose -C ./cgi**
 5581 pts/1    S+     0:00 grep mong
$ ps ax | grep "fb"
 5596 ?        S      0:00 /usr/sbin/fbguard -daemon -forever -pidfile /var/run/firebird/2.5/fbserver.pid
 5597 ?        Sl     0:00 /usr/sbin/fbserver
 5615 pts/1    S+     0:00 grep fb
 * @endcode
<br>
Abra su navegador internet preferido y tipee: http://localhost:8080<br>
deberia obtener alguna respuesta del servidor mongoose que esta ejecutandose<br>
NOTA: para arrancar Firebird, como usuario root ejecute $ /etc/init.d/firebird2.5-super start<br>
  * </li>
  * <li>9. Correr programa<br>
  * </li>
  * <li>10. Chequear archivo log<br>
  * </li>
  * 
  *</ul> 
  * 
  * 
  * 
  * Atte. Guillermo Cherencio.
  */
 
/**
 * Todo list:
 *     1.terminar documentacion / manual con codigo de ejemplo
 *     2.publicar
 *     
 * Temas de investigacion: 
 *     1.conexiones persistentes a firebird 
 *     2.soporte para cookies, sesiones y autenticacion
 *     3.desarrollo de server tcp local para canalizar a traves de el las
 *     peticiones a firebird e independizar programas cgi de libfb
 *     4.encriptacion de contenidos de cookies / variables cgi
 *     5.uso de https en mongoose
 * 
 */ 
 
 /**
  * Doxygen tags
  * 
  * 
\struct to document a C-struct.
\union to document a union.
\enum to document an enumeration type.
\fn to document a function.
\var to document a variable or typedef or enum value.
\def to document a #define.
\typedef to document a type definition.
\file to document a file.
\namespace to document a namespace.
\package to document a Java package.
\interface to document an IDL interface.
  * 
  * 
  * 
  */
 
#if !defined(MODLIBCGI)
   #define MODLIBCGI

// para incluir funciones tales como strcasestr
// este define debe estar antes que cualquier include !
#define _GNU_SOURCE

/* prototipo de funciones cgi_* a ser reusadas en programas cgi */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <libfb.h>

/** cabecera http que requiere el web server */
#define HTTP_HEADER "HTTP/1.0 200 OK\nContent-Type: text/html\n\n"

/** tamaño minimo de asginacion de memoria en bytes */
#define CGI_MIN_BUFFER_SIZE 256

/**  
 * @brief Estructura que representa un conjunto de valores de una variable cgi
 * 
 * Estos valores se asignan dinamicamente, por lo tanto, luego hay que liberar esta memoria
 *  cgi_var_value representa una list simplemente enlazada de valores asociados
 *  a una variable cgi
 *  
 * @warning name, value, etc. son asignados dinamicamente, luego liberar usando free()
 * @see cgi_var_value
 * @see cgi_free_variable()
 * @see cgi_free_variables()
 * @see cgi_var
 */
typedef struct cgi_var_value_s {
	/** valor i-esimo de variable no escalar */
	char *value;                  
	/** puntero a siguiente valor de variable */
	struct cgi_var_value_s *next; 
} cgi_var_value;

/** 
 *  @brief Estructura que representa una variable cgi de programa
 * 
 *  la cual puede ser escalar (contener un unico valor, type='S') o bien puede
 *  contener multiples valores (no escalar, type='A', no utilizado) dichos valores
 *  se representan como una lista simplemente enlazada  que se
 *  asigna dinamicamente, por lo tanto, luego hay que liberar esta memoria
 *  cgi_var_value representa una list simplemente enlazada de valores asociados
 *  a una variable cgi 
 * @warning name, value, etc. son asignados dinamicamente, luego liberar usando free()
 * @see cgi_var_value
 * @see cgi_free_variable()
 * @see cgi_free_variables()
 */
typedef struct cgi_var_s {
	/** nombre de la variable cgi */
	char *name;                   
	/** valor de la variable cgi */
	char *value;                  
	/** tipo de variable ('S' escalar, 'A' arreglo,no escalar) */
	char type;                    
	/** primer valor de variable no escalar */
	cgi_var_value *first_value;   
	/** ultimo valor de variable no escalar */
	cgi_var_value *last_value;    
	/** query (libfb) asociado a esta variable */
	void *qry;                    
} cgi_var;

/** Agrega una nueva variable a un pool de variables */
cgi_var *cgi_add_new_var(cgi_var *vars,int *nvars,cgi_var *newvar);
/** Agrega valor a una variable no escalar */
void     cgi_add_value(cgi_var *var,const char *value);
/** Cuenta la cantidad de variables cgi recibidas en src */
int      cgi_count_var(char *src);
/** Genera un buffer que contiene una serie de table rows con datos provenientes de un query */
char    *cgi_create_tr(cgi_var **vars,int *nvars,cgi_var *var,int create_title,int create_footer,char *html);
/** Verifica si existe o no la variable varname */
int      cgi_exists_var(char *varname,cgi_var *vars,int nvars);
/** Libera la memoria asociada con la variable var */
void     cgi_free_variable(cgi_var *var);
/** Libera la memoria asociada con el conjunto de variables var */
void     cgi_free_variables(cgi_var *var,int nvars);
/** Obtiene el buffer cgi de variables recibidas (ya sea que fueran enviadas mediante metodo POST o GET) */
char    *cgi_get_buffer();
/** Obtiene el valor de una variable cgi recibida en src con nombre variable y copia su valor en dest */
void     cgi_get_var(char *src,char *variable,char *dest,int largo);
/** Obtiene una referencia a una variable a partir de su nombre */
cgi_var *cgi_get_variable(char *varname,cgi_var *vars,int nvars);
/** Guarda en var->value el valor de la variable var->name que se encuentra en buffer cgi src */
void     cgi_get_var_cgi(char *src,cgi_var *var);
/** Devuelve el nombre de una variable cgi a partir del buffer cgi src y de su posicion en el mismo (0.n-1) */
char    *cgi_get_var_name(char *src,int nvar);
/** Devuelve el valor de una variable cgi a partir del buffer cgi src y de su posicion en el mismo (0..n-1) */
char    *cgi_get_var_value(char *src,int nvar);
/** Obtiene todas las variables cgi del buffer cgi src en forma dinamica contigua, actualiza nvars */
cgi_var *cgi_get_vars(char *src,int *nvars);
/** Evalua/Interpreta la pagina .dhtml llamada filename, realiza sustituciones y asignaciones de variables escalares */
char    *cgi_interpret_file(char *filename,cgi_var **vars,int *nvars);
/** Permite loggear la ejecucion de un programa cgi */
void     cgi_log(char *progname,char *msg);
/** Agrega una nueva variable a un pool de variables, asume tipo 'S' (escalar) */
cgi_var *cgi_new_variable(const char *name);
/** Agrega una nueva variable a un pool de variables, indica el tipo de la variable */
cgi_var *cgi_new_variable_type(const char *name,char type);
/** Agrega una nueva variable a un pool de variables, indica el tipo y el valor de la variable */
cgi_var *cgi_new_variable_type_value(const char *name,char type,const char *value);
/** Imprime una tabla html con los nombres y valor de las actuales variables cgi */
void     cgi_print_vars(cgi_var *var,int nvars);
/** Establece el valor de una variable escalar */
void     cgi_set_variable(cgi_var *var,char *value);
/** Decodifica el buffer cgi src recibido en dest */
void     cgi_unencode(char *src, char *last, char *dest);
/** Reasigno memoria, ampliando buffer orig a current_size + CGI_MIN_BUFFER_SIZE bytes */
char    *cgi_realloc(char *orig,long current_position,long current_size,int *ret);
/** Reasigno memoria, ampliando buffer orig a new_size bytes */
char    *cgi_realloc_size(char *orig,long current_position,long current_size,long newsize,int *ret);
/** Busca search en buffer y lo reemplaza por replace */
char    *cgi_search_and_replace(char *buffer,char *search,char *replace);
/** Devuelve el substring de buffer que se encuentra entre search1 y search2 */
char    *cgi_substring(char *buffer,char *search1,char *search2);
/** Devuelve el substring de buffer que se encuentra desde el comienzo de buffer hasta search1 */
char    *cgi_substring_toend(char *buffer,char *search1);
/** Devuelve el substring de buffer que se encuentra luego de search1 y a partir de alli hasta el final de buffer */
char    *cgi_substring_upto(char *buffer,char *search1);

#endif
